package au.gov.dva.digitize.service;

import java.util.ArrayList;
import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import au.gov.dva.digitize.dao.ContainerRepository;
import au.gov.dva.digitize.dao.document.DocumentRepository;
import au.gov.dva.digitize.jpa.Container;
import au.gov.dva.digitize.service.model.MailBox;


/**
 * 
 * @author znairm
 *
 */
@Service
public class MailBoxService {

	protected ContainerRepository containerRepository;
	

	protected DocumentRepository documentRepository; 
	
	
	public ContainerRepository getContainerRepository() {
		return containerRepository;
	}
	@Autowired
	public void setContainerRepository(ContainerRepository containerRepository) {
		this.containerRepository = containerRepository;
	}
	public DocumentRepository getDocumentRepository() {
		return documentRepository;
	}
	@Autowired
	public void setDocumentRepository(DocumentRepository documentRepository) {
		this.documentRepository = documentRepository;
	}
	
	/**
	 * 
	 * @return mail room and trim mailboxes
	 */
	public List<MailBox> getAllMailBoxes(){
		List<Container> allContainers = containerRepository.findAllMailRoomAndTrimContainers();
		List<MailBox> mailBoxes = new ArrayList<MailBox>();
		for (Container container : allContainers) {
			MailBox mailBox = new MailBox();
			mailBox.setId(container.getId());
			mailBox.setName(container.getLabel());
			mailBox.setType(container.getType());
			mailBoxes.add(mailBox);
		}
		
		return mailBoxes;
	}
	
	public Boolean redirectToMailBox(Integer fromContainerId, Integer toContainerlId, Integer documentId , String comments) {
	
		/*int docId = 43;
		int targetContainerId = 33;
		int sourceContainerId = 34;*/
		
/*		ContainedDocPK containedDocPK = new ContainedDocPK();
		containedDocPK.setContId(fromContainerId);
		containedDocPK.setDocId(documentId);
		ContainedDoc containedDoc = containedDocRepository.findOne(containedDocPK);
		containedDocRepository.delete(containedDoc);
		containedDoc.getId().setContId(toContainerlId);
		containedDoc.getId().setDocId(documentId);
		containedDocRepository.save(containedDoc);*/
		
		return true;
	}
}
