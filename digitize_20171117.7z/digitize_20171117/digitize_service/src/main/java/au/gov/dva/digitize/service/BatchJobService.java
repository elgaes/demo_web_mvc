package au.gov.dva.digitize.service;

import java.util.Properties;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;
import javax.transaction.Transactional.TxType;

import org.springframework.stereotype.Service;

import au.gov.dva.digitize.batch.BatchJobNames;
//import au.gov.dva.digitize.batch.LoadMailData;
import au.gov.dva.digitize.batch.schedule.SchedulingRemote;

/**
 * This simple serivce class intent to provide all Person related infomation 
 * management. It access backend data access layer and provide other logical functions.
 * It should return an intermediate business model object and mapping back end forth between
 * backend model and business model. However this is a simple app with read only let cut the 
 * middleman off.
 * 
 * 
 * @author 		Haibang Mai
 * @version    1.0
 * 
 */

@Service
public class BatchJobService 
{
	@PersistenceContext(unitName="digitizePU")
	protected EntityManager entityMgr;
	
	@Inject 
	SchedulingRemote batchScheduler;
	
	@Transactional(TxType.REQUIRED)
	public void startDocumentImportBatch()
	{
		try {
//			LoadMailData mailLoader=new LoadMailData();
//			mailLoader.setEntityMgr(entityMgr);
//			mailLoader.process();
			Properties params=new Properties();
			batchScheduler.runJob(BatchJobNames.LOAD_SCANNED_MAIL_JOB, params);
		}catch(Throwable e) {
			
		}
	}
}
