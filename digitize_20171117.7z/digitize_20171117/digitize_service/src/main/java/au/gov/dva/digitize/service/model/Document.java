package au.gov.dva.digitize.service.model;

import java.util.Date;

public class Document {

	private boolean processingStatus;
	private boolean alreadyRead;
	private String documentTitle;
	private String documentName;
	private String thesaurusLevel1;
	private String thesaurusLevel2;
	private String thesaurusLevel3;
	private String bagId;
	private String envelopeId;
	private String mailBox;
	private String documentSubject;
	private int docId;
	private byte[] fileBlob;
	private String fileType;
	private boolean pendingInTrim;
	private Date loadDate;
	private int lastDocIdInPage;
	private int startDocIdInPage;
	
	public int getStartDocIdInPage() {
		return startDocIdInPage;
	}
	public void setStartDocIdInPage(int startDocIdInPage) {
		this.startDocIdInPage = startDocIdInPage;
	}
	public boolean isAlreadyRead() {
		return alreadyRead;
	}
	public int getLastDocIdInPage() {
		return lastDocIdInPage;
	}
	public void setAlreadyRead(boolean alreadyRead) {
		this.alreadyRead = alreadyRead;
	}
	public void setLastDocIdInPage(int lastDocIdInPage) {
		this.lastDocIdInPage = lastDocIdInPage;
	}
	public boolean isProcessingStatus() {
		return processingStatus;
	}
	public void setProcessingStatus(boolean processingStatus) {
		this.processingStatus = processingStatus;
	}
	public boolean getReadStatus() {
		return alreadyRead;
	}
	public void setReadStatus(boolean readStatus) {
		this.alreadyRead = readStatus;
	}
	public String getTitle() {
		return documentTitle;
	}
	public void setTitle(String title) {
		this.documentTitle = title;
	}
	public String getThesaurusLevel1() {
		return thesaurusLevel1;
	}
	public void setThesaurusLevel1(String thesaurusLevel1) {
		this.thesaurusLevel1 = thesaurusLevel1;
	}
	public String getThesaurusLevel2() {
		return thesaurusLevel2;
	}
	public void setThesaurusLevel2(String thesaurusLevel2) {
		this.thesaurusLevel2 = thesaurusLevel2;
	}
	public String getThesaurusLevel3() {
		return thesaurusLevel3;
	}
	public void setThesaurusLevel3(String thesaurusLevel3) {
		this.thesaurusLevel3 = thesaurusLevel3;
	}
	public String getBagId() {
		return bagId;
	}
	public void setBagId(String bagId) {
		this.bagId = bagId;
	}
	public int getDocId() {
		return docId;
	}
	public void setDocId(int docId) {
		this.docId = docId;
	}
	public byte[] getFileBlob() {
		return fileBlob;
	}
	public void setFileBlob(byte[] fileBlob) {
		this.fileBlob = fileBlob;
	}
	public String getFileType() {
		return fileType;
	}
	public void setFileType(String fileType) {
		this.fileType = fileType;
	}
	public String getDocumentTitle() {
		return documentTitle;
	}
	
	public String getDocumentName() {
		return documentName;
	}
	public void setDocumentName(String documentName) {
		this.documentName = documentName;
	}
	public void setDocumentTitle(String documentTitle) {
		this.documentTitle = documentTitle;
	}
	
	public boolean isPendingInTrim() {
		return pendingInTrim;
	}
	public void setPendingInTrim(boolean pendingInTrim) {
		this.pendingInTrim = pendingInTrim;
	}
	public Date getLoadDate() {
		return loadDate;
	}
	public void setLoadDate(Date loadDate) {
		this.loadDate = loadDate;
	}
	public String getEnvelopeId() {
		return envelopeId;
	}
	public void setEnvelopeId(String envelopeId) {
		this.envelopeId = envelopeId;
	}
	public String getMailBox() {
		return mailBox;
	}
	public void setMailBox(String mailBox) {
		this.mailBox = mailBox;
	}
	public String getDocumentSubject() {
		return documentSubject;
	}
	public void setDocumentSubject(String documentSubject) {
		this.documentSubject = documentSubject;
	}
	
	
	
}
