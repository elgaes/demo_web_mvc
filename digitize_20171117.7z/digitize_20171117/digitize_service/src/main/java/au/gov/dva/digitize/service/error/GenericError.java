package au.gov.dva.digitize.service.error;

import java.util.List;

public class GenericError {
	
	private String code;
	private String message;/*class of error this might*/
	private List<ValidationErrors> validationErrors;
	public List<ValidationErrors> getValidationErrors() {
		return validationErrors;
	}
	public void setValidationErrors(List<ValidationErrors> validationErrors) {
		this.validationErrors = validationErrors;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	

}
