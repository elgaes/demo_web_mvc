package au.gov.dva.digitize.batch.schedule;

import java.util.Properties;

import javax.annotation.Resource;
import javax.batch.operations.JobOperator;
import javax.batch.runtime.BatchRuntime;
import javax.ejb.Local;
import javax.ejb.Remote;

/**
 * This session bean class responsible to provide interface to schedule timer and fire off batch jobs on schedule
 * 
 * 
 * @author 		Haibang Mai
 * @version    1.0
 * 
 */

import javax.ejb.Schedule;
import javax.ejb.ScheduleExpression;
import javax.ejb.Singleton;
import javax.ejb.Startup;
import javax.ejb.Timeout;
//import javax.ejb.Stateless;
import javax.ejb.Timer;
import javax.ejb.TimerConfig;
import javax.ejb.TimerService;

import au.gov.dva.digitize.batch.schedule.SchedulingLocal;
import au.gov.dva.digitize.batch.schedule.SchedulingRemote;

//@Stateless
@Singleton
@Startup
@Local(SchedulingLocal.class)
@Remote(SchedulingRemote.class)  
public class JobScheduler implements SchedulingRemote, SchedulingLocal
{
	@Resource
	protected TimerService timeService; 
	
    /**
     * Default constructor. 
     */
    public JobScheduler() 
    {

    }
    
    public Timer runJobAt(String jobName, Properties params, ScheduleExpression schedule)
    {
    	TimerConfig config=new TimerConfig(jobName,true);     	
    	Timer timer=timeService.createCalendarTimer(schedule,config);     
    	return timer;
    }
    public long runJob(String jobName, Properties params) 
    {
		System.err.println("Starting job "+jobName);
		JobOperator op=BatchRuntime.getJobOperator();
		long jobId=op.start(jobName,params);
		System.err.println("Job "+jobName+"("+jobId+") started");
		return jobId;
    }

	@Schedule(hour="*/4", info="LoadMailData")
    private void scheduledRun(final Timer jobTimer) 
	{
		runJob(jobTimer);
    }
	
	@Timeout
	private void runJob(Timer jobTimer)
	{
		Properties params=new Properties();
		runJob(jobTimer.getInfo().toString(), params);
	}
}