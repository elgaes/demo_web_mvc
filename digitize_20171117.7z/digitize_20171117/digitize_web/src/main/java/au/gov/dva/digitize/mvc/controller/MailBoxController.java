package au.gov.dva.digitize.mvc.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import au.gov.dva.digitize.common.AppConstants;
import au.gov.dva.digitize.jpa.ContainedDoc;
import au.gov.dva.digitize.jpa.ContainedDocPK;
import au.gov.dva.digitize.service.BatchJobService;
import au.gov.dva.digitize.service.ContainerService;
import au.gov.dva.digitize.service.MailBoxService;
import org.springframework.web.bind.annotation.RequestParam;
import au.gov.dva.digitize.service.model.MailBox;

/**
 * This simple controller class will handle all request to MailBox record 
 * management. It s light in functionality at the moment since most of 
 * data access delegated to the ContainerService class
 * 
 * 
 * @author 		Haibang Mai
 * @version    1.0
 * 
 */
@Controller
@RequestMapping("/views/mailbox/*")
public class MailBoxController extends AbstractController{
	
	@Autowired
	private ContainerService containerService;
	@Autowired
	private BatchJobService batchJobService;
	@Autowired
	private MailBoxService mailBoxService;

	@ResponseBody
	@RequestMapping(path="getAllMailBoxes", produces="application/json")
	public List<MailBox>getAllMailBoxes(Model model, HttpServletRequest request){
		return mailBoxService.getAllMailBoxes();
	}
	@ResponseBody
	@RequestMapping(path="redirectToMailBox", produces="application/json")
	public void  redirectToMailBox(@RequestParam(value="fromMailBoxId", required=false) Integer fromMailBoxId,
			@RequestParam(value="toMailBoxId", required=false) Integer toMailBoxId) {
		mailBoxService.redirectToMailBox(1, 2, 3, "MM");
	}
	
	@GetMapping("mymailbox")
	public String listMyMailbox(Model model, HttpServletRequest request){
		
		model.addAttribute("mailboxList", containerService.getUserAccessibleContainers(request.getUserPrincipal()));
		
		return AppConstants.TEMPLATE_MY_MAILBOXES;
		
	}
	
	@GetMapping("startbatch")
	public void startBatchJob(Model model, HttpServletRequest request)	{
		
		//listMyMailbox(model, request);	
		batchJobService.startDocumentImportBatch();
	}
}
