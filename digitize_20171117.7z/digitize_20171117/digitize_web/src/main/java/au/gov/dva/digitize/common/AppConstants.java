package au.gov.dva.digitize.common;

/**
 * This class is an application wide utility class defining all 
 * application constants here
 * 
 * 
 * @author 	Haibang Mai
 * @date 	14/09/2017
 */

public class AppConstants
{
	public static final String TEMPLATE_ADMIN="adminTemp";
	public static final String TEMPLATE_DEFAULT_ERROR="errorTemp";
	public static final String TEMPLATE_PERSON_CLAIMS="personClaimsTemp";
	public static final String TEMPLATE_PERSON_LIST="personListTemp";
	public static final String TEMPLATE_CLAIM_LIST="claimListTemp";
	public static final String TEMPLATE_MY_MAILBOXES="myMailBoxesTemp";	
	/* error codes Start*/
	public static final String ERRORCODE_101="101";
	public static final String ERRORCODE_101_MESSAGE = "MailBox Id not passed with this request";
	public static final String ERRORCODE_102="102";
	public static final String ERRORCODE_102_MESSAGE = "User Id not passed with this request";
	/* error codes end*/
	

}
