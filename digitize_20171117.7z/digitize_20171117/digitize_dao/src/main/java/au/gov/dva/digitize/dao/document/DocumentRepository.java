package au.gov.dva.digitize.dao.document;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import au.gov.dva.digitize.jpa.Document;
 
@Repository
public interface DocumentRepository extends CrudRepository<Document, String> {
	
	public List<Document> findByEnvelopeId( @Param ("envelopeId") String envelopeId);

	public Document findDocumentById(@Param ("envelopeId") Integer docId);
}
