package au.gov.dva.digitize.dao.containeddoc;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;

import au.gov.dva.digitize.jpa.ContainedDoc;
import au.gov.dva.digitize.jpa.ContainedDocPK;

public interface ContainedDocRepository extends CrudRepository<ContainedDoc, ContainedDocPK> {

	//public ContainedDoc findById(ContainedDocPK containedDocPK);

	
}
