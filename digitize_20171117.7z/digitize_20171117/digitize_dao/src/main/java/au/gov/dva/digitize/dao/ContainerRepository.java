package au.gov.dva.digitize.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
//import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import au.gov.dva.digitize.jpa.Container;
import au.gov.dva.digitize.jpa.custom.ContainerWithCount;



@Repository
public interface ContainerRepository extends JpaRepository<Container, Integer>
{
	public List<Container> findByType(String type);
	public List<Container> findByParentContainerId(Integer parentId);	
	public List<Container> findByRoleAndPermission(@Param("role") String role, @Param("permission") String permission);
	
	@Query(value="select new au.gov.dva.digitize.jpa.custom.ContainerWithCount (c.id,c.label, count(d.id)) from Container c inner join c.documents d WHERE c.id IN  (SELECT a.id.objId FROM SecAccess a, SecSubject s, SecPermission p" + 
			"			WHERE a.id.permId=p.id AND a.id.subjId=s.id AND s.label = :role AND p.label = :permission AND a.id.objType='MAILROOM') group by c.id, c.label")
	public List<ContainerWithCount> findMailBoxesWithCountByPermission(@Param("role") String role, @Param("permission") String permission);
	
	public List<Container>findAllMailRoomAndTrimContainers();
	
	
}
