package au.gov.dva.digitize.dao.document;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import au.gov.dva.digitize.jpa.Document;
 
@Repository
public interface DocumentPaginationRepository extends JpaRepository<Document, String> {
	
	@Query("Select  d  from Document d inner join d.containers c where c.id=:mailBoxID and d.procSta=:processStatus and d.id > :lastDocId order by d.id, d.scanDate" )
	public List<Document> findDocumentsByPageAndStausAndMailBox( @Param ("mailBoxID") Integer mailBoxId, 
			@Param ("lastDocId") Integer lastDocId, @Param ("processStatus") String processStatus, Pageable pageable);
}
