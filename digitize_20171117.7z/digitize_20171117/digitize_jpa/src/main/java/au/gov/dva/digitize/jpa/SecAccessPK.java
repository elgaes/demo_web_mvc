package au.gov.dva.digitize.jpa;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the SEC_ACCESS database table.
 * 
 */
@Embeddable
public class SecAccessPK implements Serializable {

	private static final long serialVersionUID = -5433614635775219768L;
	private int objId;
	private String objType;
	private int permId;
	private int subjId;

	public SecAccessPK() {
	}

	@Column(name="OBJ_ID")
	public int getObjId() {
		return this.objId;
	}
	public void setObjId(int objId) {
		this.objId = objId;
	}

	@Column(name="OBJ_TYPE")
	public String getObjType() {
		return this.objType;
	}
	public void setObjType(String objType) {
		this.objType = objType;
	}

	@Column(name="PERM_ID", insertable=false, updatable=false)
	public int getPermId() {
		return this.permId;
	}
	public void setPermId(int permId) {
		this.permId = permId;
	}

	@Column(name="SUBJ_ID", insertable=false, updatable=false)
	public int getSubjId() {
		return this.subjId;
	}
	public void setSubjId(int subjId) {
		this.subjId = subjId;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof SecAccessPK)) {
			return false;
		}
		SecAccessPK castOther = (SecAccessPK)other;
		return 
			(this.objId == castOther.objId)
			&& this.objType.equals(castOther.objType)
			&& (this.permId == castOther.permId)
			&& (this.subjId == castOther.subjId);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.objId;
		hash = hash * prime + this.objType.hashCode();
		hash = hash * prime + this.permId;
		hash = hash * prime + this.subjId;
		
		return hash;
	}
}