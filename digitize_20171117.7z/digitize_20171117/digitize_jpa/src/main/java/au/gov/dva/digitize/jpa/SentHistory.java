package au.gov.dva.digitize.jpa;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the SENT_HIST database table.
 * 
 */
@Entity
@Table(name="SENT_HIST")
@NamedQuery(name="SentHistory.findAll", query="SELECT s FROM SentHistory s")
public class SentHistory implements Serializable {
	private static final long serialVersionUID = 1L;
	private int id;
	private String comment;
	private Timestamp createTs;
	private String sentType;
	private String userid;
	private Container toContainer;
	private Container fromContainer;
	private Document document;

	public SentHistory() {
	}


	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}


	public String getComment() {
		return this.comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}


	@Column(name="CREATE_TS")
	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}


	@Column(name="SENT_TYPE")
	public String getSentType() {
		return this.sentType;
	}

	public void setSentType(String sentType) {
		this.sentType = sentType;
	}


	public String getUserid() {
		return this.userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}


	//uni-directional many-to-one association to Container
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="TO_CONT")
	public Container getToContainer() {
		return this.toContainer;
	}

	public void setToContainer(Container toContainer) {
		this.toContainer = toContainer;
	}


	//uni-directional many-to-one association to Container
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="FROM_CONT")
	public Container getFromContainer() {
		return this.fromContainer;
	}

	public void setFromContainer(Container fromContainer) {
		this.fromContainer = fromContainer;
	}


	//bi-directional many-to-one association to Document
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="DOC_ID")
	public Document getDocument() {
		return this.document;
	}

	public void setDocument(Document document) {
		this.document = document;
	}

}