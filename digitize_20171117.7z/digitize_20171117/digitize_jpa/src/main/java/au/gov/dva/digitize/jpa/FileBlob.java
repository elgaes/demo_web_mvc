package au.gov.dva.digitize.jpa;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the FILE_BLOB database table.
 * 
 */
@Entity
@Table(name="FILE_BLOB")
@NamedQuery(name="FileBlob.findAll", query="SELECT f FROM FileBlob f")
public class FileBlob implements Serializable 
{
	private static final long serialVersionUID = 1L;
	private int docId;
	private byte[] fblob;
	private int fsize;
	private String ftype;
	private Document document;

	public FileBlob() {
	}


	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="DOC_ID")
	public int getDocId() {
		return this.docId;
	}

	public void setDocId(int docId) {
		this.docId = docId;
	}


	@Lob
	public byte[] getFblob() {
		return this.fblob;
	}

	public void setFblob(byte[] fblob) {
		this.fblob = fblob;
	}


	public int getFsize() {
		return this.fsize;
	}

	public void setFsize(int fsize) {
		this.fsize = fsize;
	}


	public String getFtype() {
		return this.ftype;
	}

	public void setFtype(String ftype) {
		this.ftype = ftype;
	}


	//bi-directional one-to-one association to Document
	@OneToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="DOC_ID")
	public Document getDocument() {
		return this.document;
	}

	public void setDocument(Document document) {
		this.document = document;
	}
}