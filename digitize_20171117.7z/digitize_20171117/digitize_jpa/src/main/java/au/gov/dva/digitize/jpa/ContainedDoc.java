package au.gov.dva.digitize.jpa;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the CONTAINED_DOC database table.
 * 
 */
@Entity
@Table(name="CONTAINED_DOC")
@NamedQuery(name="ContainedDoc.findAll", query="SELECT c FROM ContainedDoc c")
public class ContainedDoc implements Serializable {
	private static final long serialVersionUID = 1L;
	private ContainedDocPK id;

	public ContainedDoc() {
	}


	@EmbeddedId
	public ContainedDocPK getId() {
		return this.id;
	}

	public void setId(ContainedDocPK id) {
		this.id = id;
	}

}