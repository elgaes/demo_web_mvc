package au.gov.dva.digitize.jpa;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the DOCUMENT database table.
 * 
 */
@Entity

@NamedQueries({
	@NamedQuery(name="Document.findAll", query="SELECT d FROM Document d"),
	@NamedQuery(name="Document.findByEnvelopeId", query="SELECT d FROM Document d where d.envelId=:envelopeId"),
	@NamedQuery(name="Document.findById", query="SELECT d FROM Document d where d.id=:docId"),
	@NamedQuery(name="Document.findContainer", query="SELECT d FROM Document d where d.id=:docId")
	})


public class Document implements Serializable {
	
	private static final long serialVersionUID = 1L;
	private int id;
	private String archBox;
	private String bagId;
	private String claimId;
	private String claimSys;
	private String cliUin;
	private String envelId;
	private String procSta;
	private String readSta;
	private Date scanDate;
	private String scanId;
	private String scanName;
	private String therL1;
	private String therL2;
	private String therL3;
	private String title;
	private String trimCont;
	private String trimRec;
	private List<Container> containers;
	private FileBlob fileBlob;
	private List<SentHistory> sentHistoryRecords;

	public Document() {
	}


	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}


	@Column(name="ARCH_BOX")
	public String getArchBox() {
		return this.archBox;
	}

	public void setArchBox(String archBox) {
		this.archBox = archBox;
	}


	@Column(name="BAG_ID")
	public String getBagId() {
		return this.bagId;
	}

	public void setBagId(String bagId) {
		this.bagId = bagId;
	}


	@Column(name="CLAIM_ID")
	public String getClaimId() {
		return this.claimId;
	}

	public void setClaimId(String claimId) {
		this.claimId = claimId;
	}


	@Column(name="CLAIM_SYS")
	public String getClaimSys() {
		return this.claimSys;
	}

	public void setClaimSys(String claimSys) {
		this.claimSys = claimSys;
	}


	@Column(name="CLI_UIN")
	public String getCliUin() {
		return this.cliUin;
	}

	public void setCliUin(String cliUin) {
		this.cliUin = cliUin;
	}


	@Column(name="ENVEL_ID")
	public String getEnvelId() {
		return this.envelId;
	}

	public void setEnvelId(String envelId) {
		this.envelId = envelId;
	}


	@Column(name="PROC_STA")
	public String getProcSta() {
		return this.procSta;
	}

	public void setProcSta(String procSta) {
		this.procSta = procSta;
	}


	@Column(name="READ_STA")
	public String getReadSta() {
		return this.readSta;
	}

	public void setReadSta(String readSta) {
		this.readSta = readSta;
	}


	@Temporal(TemporalType.DATE)
	@Column(name="SCAN_DATE")
	public Date getScanDate() {
		return this.scanDate;
	}

	public void setScanDate(Date scanDate) {
		this.scanDate = scanDate;
	}


	@Column(name="SCAN_ID")
	public String getScanId() {
		return this.scanId;
	}

	public void setScanId(String scanId) {
		this.scanId = scanId;
	}


	@Column(name="SCAN_NAME")
	public String getScanName() {
		return this.scanName;
	}

	public void setScanName(String scanName) {
		this.scanName = scanName;
	}


	@Column(name="THER_L1")
	public String getTherL1() {
		return this.therL1;
	}

	public void setTherL1(String therL1) {
		this.therL1 = therL1;
	}


	@Column(name="THER_L2")
	public String getTherL2() {
		return this.therL2;
	}

	public void setTherL2(String therL2) {
		this.therL2 = therL2;
	}


	@Column(name="THER_L3")
	public String getTherL3() {
		return this.therL3;
	}

	public void setTherL3(String therL3) {
		this.therL3 = therL3;
	}


	public String getTitle() {
		return this.title;
	}

	public void setTitle(String title) {
		this.title = title;
	}


	@Column(name="TRIM_CONT")
	public String getTrimCont() {
		return this.trimCont;
	}

	public void setTrimCont(String trimCont) {
		this.trimCont = trimCont;
	}


	@Column(name="TRIM_REC")
	public String getTrimRec() {
		return this.trimRec;
	}

	public void setTrimRec(String trimRec) {
		this.trimRec = trimRec;
	}


	//bi-directional many-to-many association to Container
	@ManyToMany
	@JoinTable(
		name="CONTAINED_DOC"
		, joinColumns={
			@JoinColumn(name="DOC_ID")
			}
		, inverseJoinColumns={
			@JoinColumn(name="CONT_ID")
			}
		)
	public List<Container> getContainers() {
		return this.containers;
	}

	public void setContainers(List<Container> containers) {
		this.containers = containers;
	}


	//bi-directional one-to-one association to FileBlob
	@OneToOne(mappedBy="document", fetch=FetchType.LAZY)
	public FileBlob getFileBlob() {
		return this.fileBlob;
	}

	public void setFileBlob(FileBlob fileBlob) {
		this.fileBlob = fileBlob;
	}


	//bi-directional many-to-one association to SentHistory
	@OneToMany(mappedBy="document")
	public List<SentHistory> getSentHistoryRecords() {
		return this.sentHistoryRecords;
	}

	public void setSentHistoryRecords(List<SentHistory> sentHistoryRecords) {
		this.sentHistoryRecords = sentHistoryRecords;
	}

	public SentHistory addSentHistoryRecord(SentHistory sentHistoryRecord) {
		getSentHistoryRecords().add(sentHistoryRecord);
		sentHistoryRecord.setDocument(this);

		return sentHistoryRecord;
	}

	public SentHistory removeSentHistoryRecord(SentHistory sentHistoryRecord) {
		getSentHistoryRecords().remove(sentHistoryRecord);
		sentHistoryRecord.setDocument(null);

		return sentHistoryRecord;
	}

}