package au.gov.dva.digitize.jpa;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the SEC_ACCESS database table.
 * 
 */
@Entity
@Table(name="SEC_ACCESS")
@NamedQuery(name="SecAccess.findAll", query="SELECT s FROM SecAccess s")
public class SecAccess implements Serializable {
	private static final long serialVersionUID = 1L;
	private SecAccessPK id;
	private SecPermission secPermission;
	private SecSubject secSubject;

	public SecAccess() {
	}


	@EmbeddedId
	public SecAccessPK getId() {
		return this.id;
	}

	public void setId(SecAccessPK id) {
		this.id = id;
	}


	//bi-directional many-to-one association to SecPermission
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="PERM_ID", insertable=false, updatable=false)
	public SecPermission getSecPermission() {
		return this.secPermission;
	}

	public void setSecPermission(SecPermission secPermission) {
		this.secPermission = secPermission;
	}


	//bi-directional many-to-one association to SecSubject
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="SUBJ_ID", insertable=false, updatable=false)
	public SecSubject getSecSubject() {
		return this.secSubject;
	}

	public void setSecSubject(SecSubject secSubject) {
		this.secSubject = secSubject;
	}

}