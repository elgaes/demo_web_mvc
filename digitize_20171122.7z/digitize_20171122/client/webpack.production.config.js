var Webpack = require('webpack');
var path = require('path');
var nodeModulesPath = path.resolve(__dirname, 'node_modules');
var buildPath = path.resolve(__dirname, 'public', 'build');
var appPath = path.resolve(__dirname, 'src');


var config = {
    context: __dirname,
    devtool: 'nosources-source-map',
    entry: {
        'bundle': [path.resolve(appPath, 'prod.js'), 'babel-polyfill', path.resolve(appPath, 'shim.js'), path.resolve(appPath, 'main.js')]
    },
    resolve: {
        modules: [path.resolve(__dirname), nodeModulesPath],
        alias: {
            'src': path.resolve(__dirname, 'src'),
        }
    },
    output: {
        path: buildPath,
        filename: '[name].js',
        publicPath: 'build/'
    },
    module: {
        rules: [

            // babel-loader gives you ES6/7 syntax and JSX transpiling
            {
                test: /\.js$/,
                loader: 'babel-loader',
                exclude: [],
                query: {
                    cacheDirectory: true,
                    presets: ['react', 'es2015', 'stage-0']
                }
            },

            // Let us also add the style-loader and css-loader
            {
                test: /\.css$/,
                use: [
                        "style-loader",
                        "css-loader"
                     ]
            },
            // As well as the style-loader and less-loader
            {
                test: /\.scss$/,
                use: [
                        "style-loader",
                        "css-loader",
                        "sass-loader"
                     ]
            }, {
                test: /\.(png|gif|jpg|svg|woff|woff2|eot|ttf)$/,
                loader: 'url-loader?limit=25000'
            }
        ]
    },
    plugins: [
        (new Webpack.optimize.UglifyJsPlugin({
            sourceMap: false,
            compressor: {
                warnings: false,
                screw_ie8: true,
                drop_console: true
            },
            output: {
                comments: false
            }
        }))
    ]
};

module.exports = config;
