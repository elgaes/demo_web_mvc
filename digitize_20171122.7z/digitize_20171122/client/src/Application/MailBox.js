import Bus from 'src/Infrastructure/Bus'

export default class MailBox {

    static _state = {
    };
    static _validation = {};

    // commands (async - return via optional callback when done)
    static command = {
      // addRating: (callback, data) => {
      //
      //   Bus.command('rating.add', data).done((res) => {
      //     console.log(res.service, res.data);
      //
      //     if (callback != null)
      //       callback(res.data);
      //   });
      // },
      //
      // updateRating: (callback, data) => {
      //
      //   Bus.command('rating.update', data).done((res) => {
      //     console.log(res.service, res.data);
      //
      //     //return to caller
      //     if (callback != null)
      //       callback(res.data);
      //   });
      // },
      mailRedirection: ()=>{

      }
    }

    // query (async - return via callback)
    static query = {
      userMailboxes: (callback) => {
        Bus.query('views/document/listAllMailBoxes').done((res) => {
          console.log('mailBoxList:');
          console.log(res);
          callback(res);
        })
      },

      doumentsByMailbox: (mailboxId, docId, callback)=>{

        Bus.query('views/document/getAllDocumentsByMailBoxIdAndPage', {mailBoxId: mailboxId, documentId: docId}).done((res) => {
          console.log('documentList:');
          console.log(res);
          callback(res);

        })
      },

      documentsByEnvelope:(envelopeId_param, representativeDocId_param, callback)=>{
        Bus.query('views/document/getAllDocumentsByEnvelopeId', {envelopeId: envelopeId_param, representativeDocId: representativeDocId_param}).done((res) => {
          console.log('envelopeList:');
          console.log(res);
          callback(res);
        })
      },

      allMailBoxList: (callback)=>{
        const res = [{text:'My MailBox 11', value:'m1'}, {text:'Your MailBox 1', value:'y1'}, {text:'Their MailBox 1', value:'t1'},
                      {text:'My MailBox 12', value: 'm2'}, {text:'Your MailBox 2', value:'y2'}, {text:'Their MailBox 2', value: 't2'},
                      {text:'My MailBox 13', value: 'm3'}, {text:'Your MailBox 3', value: 'y3'}, {text:'Their MailBox 3', value:'t3'},
                      {text:'My MailBox 14', value: 'm4'}, {text:'Your MailBox 4', value: 'y4'}, {text:'Their MailBox 4', value: 't4'}];
        callback(res);

      }
    }
};
