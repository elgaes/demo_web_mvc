// staff application entry point

import React from 'react';
import ReactDOM from 'react-dom';
import AppComponent from 'src/Interface/App';

//import Bus from './Infrastructure/Bus';

ReactDOM.render(<AppComponent />, document.getElementById('content'));
