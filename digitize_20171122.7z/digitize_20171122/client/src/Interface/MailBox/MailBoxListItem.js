// libs
import React from 'react';
import PropTypes from 'prop-types';
import ClassNames from 'classnames';


// styles
import './MailBoxListItem.scss';

export default class MailBoxListItem extends React.Component {

    // prop types and default values
    static propTypes = {
      id: PropTypes.number.isRequired,
      name: PropTypes.string.isRequired,
      selected: PropTypes.bool,
      count: PropTypes.number,
      index: PropTypes.number.isRequired,
      onItemSelect: PropTypes.func
    };

    onItemSelect = () => {
      if(this.props.onItemSelect) {
        this.props.onItemSelect(this.props.id, this.props.name, this.props.index, this.props.count);        
      }
    }

    render() {

        let classes = ClassNames('mail-mailbox-item', {selected: this.props.selected});

        return (
          <li className={classes} onClick={this.onItemSelect}>
            <span className="text">{this.props.name}</span>
            {this.props.count ? <span className="number">{this.props.count}</span> : null}
          </li>
        );
    }
}
