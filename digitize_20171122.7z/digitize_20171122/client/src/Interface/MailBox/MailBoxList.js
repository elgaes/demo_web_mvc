// libs
import React from 'react';
import PropTypes from 'prop-types';

// application
import MailBox from 'src/Application/MailBox'

// components
import Warn from 'src/Interface/Common/Warn'
import MailBoxListItem from './MailBoxListItem'
import Loader from 'src/Interface/Common/Loader'

// styles
import './MailBoxList.scss';

export default class MailBoxList extends React.Component {

    // prop types and default values
    static propTypes = {
      onSelect: PropTypes.func
    };

    constructor() {
      super();
      this.state = {
        selectedIndex: null,
        items: null,
      };
    }

    componentDidMount(){
      MailBox.query.userMailboxes((res) => {
        this.setState({items: res});
     });
    }

    mailboxSelected = (id, name, index, count) =>  {
      // has the selection changed?
      if(index != this.state.selectedIndex) {
        // yes
        this.setState({selectedIndex: index});
        
        if(this.props.onSelect) {
          this.props.onSelect(id, name, count);
        }
      }
    }

    render() {

        let component = this;
        return (
          <div>
            <Loader size = '7'  visible={this.state.items==null}>
              {(this.state.items == null || this.state.items.length == 0) ?
                <Warn>You are not authorised to see any mailboxes - Please see your mailbox administrator.</Warn> :
                <ul className="mail-mailbox-list">
                  {component.state.items && component.state.items.map(function(item, index){
                    return (
                              <MailBoxListItem
                                  id={item.id}
                                  name={item.name}
                                  count={item.count}
                                  selected={component.state.selectedIndex == index}
                                  key={index}
                                  index={index}
                                  onItemSelect={component.mailboxSelected}
                              />);
                  })}
                </ul>
              }
            </Loader>
          </div>
        );
    }
}
