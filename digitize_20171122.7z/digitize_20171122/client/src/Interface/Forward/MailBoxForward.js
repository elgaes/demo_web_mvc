// libs
import React from 'react';
import PropTypes from 'prop-types';

// application
import MailBox from 'src/Application/MailBox'

//components
import Modal from 'src/Interface/Common/Modal/Modal';
import Button from 'src/Interface/Common/Button';
import SimpleTypeahead from 'src/Interface/Common/SimpleTypeahead';
import TextArea from 'src/Interface/Common/TextArea';


export default class MailBoxForward extends React.Component {

    constructor() {
        super();
        this.state = {
            mailBoxList: null, 
            defaultMailBox: null,
            selectedMailBox: null,
            forwardMailBoxSelected:false, 
            textAreaValue: null,
        };
      }
   
    // prop types and default values
    static propTypes = {
       modalShow: PropTypes.bool.isRequired,
       onClose: PropTypes.func.isRequired,
       selectedDoumentId: PropTypes.string,
       currentMailBox: PropTypes.object,
    }; 

    componentWillMount=()=>{
        MailBox.query.allMailBoxList((res)=>{
            this.setState({mailBoxList: res});
        });
    }

    componentWillReceiveProps=(nextProps)=>{
        this.setState({defaultMailBox: nextProps.currentMailBox})
    }
   
    _onValueChange=(value)=>{
        this.setState({textAreaValue:value})
    }
       
    _onChangeMailBox=(e)=>{
        console.log('value: ',e.target.value.value)
        if(e.target.value.trim().length > 0)
        {
            this.setState({selectedMailBox: e.target.value, forwardMailBoxSelected:true})            
        }
        else{
            this.setState({forwardMailBoxSelected:false})                        
        }
    }

    _onRedirect=()=>{
        if(this.state.forwardMailBoxSelected )
        {
            console.log('onRedirect clicked!!')
            let toMailBox;
            this.state.mailBoxList.forEach((item)=>{
                if(item.text == this.state.selectedMailBox)
                {
                    toMailBox= item.value;
                }});
            console.log('selected mail:', toMailBox)
            console.log('comment:', this.state.textAreaValue)

        }
    }
     
    render() {
        console.log('this.state.mailBoxList',this.state.mailBoxList)
        let buttonGroups = this.state.forwardMailBoxSelected?
                            <Modal.Footer>
                                <Button right primary empty onClick={this._onRedirect}>Redirect</Button>
                                <Button right secondary empty onClick={this.props.onClose}>Cancel</Button>
                            </Modal.Footer>
                            :
                            <Modal.Footer>
                                <Button disable right primary empty>Redirect</Button>
                                <Button right secondary empty onClick={this.props.onClose}>Cancel</Button>
                            </Modal.Footer>;
        return (

          <div className = 'mail-redirection-modal'>
            <Modal small show = {this.props.modalShow} onClose={this.props.onClose}>
                <Modal.Header>
                    <h2>Forward Mail</h2>
                    <p>Forwarding allows you to forward a mail within MailRoom to notify other officers regarding the mail.</p>
                </Modal.Header>
                <Modal.Content>
                    <p className = 'content-input-title'> Mail Box (To)</p>
                    <SimpleTypeahead
                        options={this.state.mailBoxList}
                        onOptionSelected={this._onChangeMailBox}
                       // defaultValue={this.props.currentMailBox.text}
                        name='mailbox list'
                        //maxOptionsCount={10}
                        minSearchLength={2}
                    />
                    <TextArea title = 'Comment' onValueChange={this._onValueChange}/> 
                </Modal.Content>
                {buttonGroups}
            </Modal>
          </div>
        );
    }
}
