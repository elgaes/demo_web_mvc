// libs
import React from 'react';
import PropTypes from 'prop-types';
import ClassNames from 'classnames';

// application
import MailBox from 'src/Application/MailBox'

// components
import Icon from 'src/Interface/Common/Icon'

// styles
import './EnvelopeListItem.scss';

export default class EnvelopeListItem extends React.Component {

    // prop types and default values
    static propTypes = {
        pending: PropTypes.bool,
        actioned: PropTypes.bool,
        unread: PropTypes.bool,
        externalRedirection: PropTypes.bool,
        internalRedirection: PropTypes.bool,
        id: PropTypes.number.isRequired,
        name: PropTypes.string.isRequired,
        documentSubject:PropTypes.string,
        mailBox: PropTypes.string.isRequired,
        selected: PropTypes.bool,
        index: PropTypes.number.isRequired,
        onItemSelect: PropTypes.func,
    };


    onItemSelect = () => {
      if(this.props.onItemSelect) {
        this.props.onItemSelect(this.props.id, this.props.index);
      }
    }


    render() {

        let classes = ClassNames('mail-envelope-item',
                                    {view:this.props.selected},
                                    {pending:this.props.pending},
                                    {actioned:this.props.actioned},
                                    {unread: this.props.unread},
                                    {externalRedirection:this.props.externalRedirection},
                                    {internalRedirection:this.props.internalRedirection}
                                );
        //let envelopeList = <EnvelopeList items={this.props.envelope}/>

        return (
            <li className={classes} onClick={this.onItemSelect}>
              <div className="name">{this.props.name}</div>
              <div className="subject">{this.props.documentSubject}</div>
              <div className="mailbox">{this.props.mailBox}</div>
            </li>
        );
    }
}
