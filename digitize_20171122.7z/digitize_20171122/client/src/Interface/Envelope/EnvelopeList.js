// libs
import React from 'react';
import PropTypes from 'prop-types';

// application
import MailBox from 'src/Application/MailBox'

// components
import Icon from 'src/Interface/Common/Icon'
import EnvelopeListItem from 'src/Interface/Envelope/EnvelopeListItem'
import Loader from 'src/Interface/Common/Loader'



// styles
import './EnvelopeList.scss';

export default class EnvelopeList extends React.Component {

      // prop types and default values
      static propTypes = {
        onSelect: PropTypes.func,
        items: PropTypes.object
      };

      constructor() {
        super();
        this.state = {
          items: null
        };
      }

      componentDidMount(){    
         
        MailBox.query.documentsByEnvelope(this.props.envelopeId, this.props.representativeDocId ,(res)=>{
          this.setState({items: res});
        });
      }

      onItemSelect=(id, index)=>{

        // call parent callback
        if(this.props.envelopeItemSelected) {
          this.props.envelopeItemSelected(id, index);
        }
      }

      createEnvelope=()=>{
        let component = this;
        return(
          <div>
          <Loader size = '7'  visible={this.state.items==null}>
            {component.state.items != null && component.state.items.length > 0 ?
              <ul className="mail-envelope-list">
                {this.state.items.map(function(item, index){
                  return (
                    <EnvelopeListItem
                        key = {component.props.envelopeId}
                        pending = {item.isPendingToBeInTrim}
                        actioned = {item.isActioned}
                        unread = {item.isUnread}
                        externalRedirection= {item.isExternalRedirected}
                        internalRedirection = {item.isInternalRedirected}
                        id = {item.docId}
                        name={item.documentName}
                        documentSubject = {item.documentSubject}
                        mailBox={item.mailBox}
                        selected={component.props.selectedIndex == index}
                        key={index}
                        index={index}
                        onItemSelect={component.onItemSelect}
                    />);
                })}
              </ul>
              :
              <p>There is nothing to display</p>
            }
          </Loader>
          </div>
        );
      }

      render() {
        return (
          <div>
            {this.createEnvelope()}
          </div>
        );
      }
}
