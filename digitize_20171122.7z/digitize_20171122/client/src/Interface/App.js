// libs
import React from 'react';

//Infrastructure
//import Utils from 'src/Infrastructure/Utils';
//import Bus from 'src/Infrastructure/Bus';

// components
// import Template from 'src/Interface/Template/Template';
import Mail from './Mail';

// screens

// system screens

// styles
import 'src/Interface/Styles/font-awesome.css';
import 'src/Interface/Styles/Reset.scss';

export default class App extends React.Component {

    render() {
        return (
          <div id="react-app">
            {/* <Template/> */}
            <Mail/>
          </div>
        );
    }
}
