// libs
import React from 'react';

// components
import Logo from 'src/Interface/Common/Logo'
import MailBoxList from 'src/Interface/MailBox/MailBoxList';
import DocumentList from 'src/Interface/Document/DocumentList';
import DocumentListController from 'src/Interface/Document/DocumentListController';
import Icon from 'src/Interface/Common/Icon'
import ToolBar from 'src/Interface/Action/ToolBar';
import PdfViewer from 'src/Interface/Viewer/PdfViewer';
import MailBoxRedirection from 'src/Interface/Redirection/MailBoxRedirection';
import MailBoxForward from 'src/Interface/Forward/MailBoxForward';
import Button from 'src/Interface/Common/Button'
import ToastList from 'src/Interface/Common/ToastNotification/ToastList'


// styles
import './Mail.scss';

export default class Mail extends React.Component {

  constructor() {
    super();
    this.state = {
      mailboxIdSelected: null,
      mailboxNameSelected: null, 
      mailboxCount: null,
      doucumentIdSelected: null,
      mailRedirctionOpen: false,
      mailForwardOpen: false,
    };
  }

  mailboxSelected = (id, name, count) =>  {
    this.setState({mailboxIdSelected: id, mailboxNameSelected: name, mailboxCount: count, doucumentIdSelected: null});
  }

  documentSelected = (id) => {
    console.log('D-selected', id)
    this.setState({doucumentIdSelected: id});
  }

  envelopeItemSelected = (id) => {
    console.log('E-selected', id)
    this.setState({doucumentIdSelected: id});
  }

  _openRedirect=()=>{
    console.log('click open or close')
    this.setState({mailRedirctionOpen: !this.state.mailRedirctionOpen});
   }

  _onRedirection=(fromMailBox, toMailBox, toastMessage)=>{
    this.setState({showToastMessage: show});
    if(toastMessage.toLowerCase()== 'success')
    {
      
    }
    else if(toastMessage.toLowerCase()=='error')
    {
      
    }
  }
   _openForward=()=>{
    console.log('click open or close')
    this.setState({mailForwardOpen: !this.state.mailForwardOpen});
   } 


  render() {
    let show = this.state.showToastMessage;
    let currentMailBoxObject = {text:this.state.mailboxNameSelected, value: this.state.mailboxIdSelected };
    return (
      <div className="mail">
        <ToastList show small toastList = {}/>
        <MailBoxForward
            modalShow = {this.state.mailForwardOpen} 
            onClose = {this._openForward}
            selectedDoumentId = {this.state.doucumentIdSelected}
            currentMailBox = {currentMailBoxObject}
        />
        <MailBoxRedirection 
            modalShow = {this.state.mailRedirctionOpen} 
            onClose = {this._openRedirect}
            selectedDoumentId = {this.state.doucumentIdSelected}
            currentMailBox = {currentMailBoxObject}
            onRedirection = {this._onRedirection}
        />
        <section className="mail-left">
          <Logo/>
          <MailBoxList onSelect={this.mailboxSelected}/>
        </section>
        <section className="mail-center">
          <DocumentListController/>
          <DocumentList
              key = {this.state.mailboxIdSelected}
              mailboxId = {this.state.mailboxIdSelected}
              mailboxCount = {this.state.mailboxCount}
              onDocumentSelect = {this.documentSelected}
              onEnvelopeItemSelect = {this.envelopeItemSelected}
          />
        </section>
        <section className="mail-right">
          <ToolBar openRedirect={this._openRedirect} openForward={this._openForward}/>
          <PdfViewer
              key = {this.state.doucumentIdSelected}
              docId = {this.state.doucumentIdSelected}
          />
        </section>
      </div>
    );
  }
}
