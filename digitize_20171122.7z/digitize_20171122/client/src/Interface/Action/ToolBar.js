// libs
import React from 'react';
import PropTypes from 'prop-types';


// components
import Icon from 'src/Interface/Common/Icon'


// styles
import './ToolBar.scss';

export default class ToolBar extends React.Component {

    // prop types and default values
    static propTypes = {
        openRedirect: PropTypes.func,
        openForward: PropTypes.func,


    };


    // component render method
    render() {
        return (
            <div className="mail-right-up-section">
                <ul className="mail-document-actions">
                    <li><a href=""><Icon name='user'/> Identify</a></li>
                    <li className="right-divider"><a href=""><Icon name='i-cursor'/> Rename</a></li>
                    <li><a onClick={this.props.openRedirect}><Icon name='arrows-alt'/> Redirect</a></li>
                    <li className="right-divider"><a onClick={this.props.openForward}><Icon name='mail-forward'/> Forward</a></li>
                </ul>
                <div className="mail-search-container">
                    <span className="icon fa fa-search"></span><input className="mail-search-box" placeholder="Search" type="text" />
                </div>
            </div>
        );
    }
}
