// libs
import React from 'react';
import PropTypes from 'prop-types';
import ClassNames from 'classnames';

// application
import MailBox from 'src/Application/MailBox'

// components
import Icon from 'src/Interface/Common/Icon'
import EnvelopeList from 'src/Interface/Envelope/EnvelopeList'
import Twisty from 'src/Interface/Common/Twisty'

// styles
import './DocumentListItem.scss';

export default class DocumentListItem extends React.Component {

    // prop types and default values
    static propTypes = {
      id: PropTypes.number.isRequired,
      name: PropTypes.string.isRequired,
      date: PropTypes.string.isRequired,
      documentSubject: PropTypes.string,
      envelopeId: PropTypes.string,
      pending: PropTypes.bool,
      unread: PropTypes.bool,
      selected: PropTypes.bool,
      index: PropTypes.number.isRequired,
      onItemSelect: PropTypes.func,
      onOpenEnvelope: PropTypes.func,
    };

    constructor() {
      super();
      this.state = {
        openEnvelope: false,
        envelopeDocuSelected: null,
        envelopeList: [],
      };
    }

    onItemSelect = () => {
      if(this.props.onItemSelect) {
        this.props.onItemSelect(this.props.id, this.props.index);
      }
    }

    onEnvelopeItemSelect = (id, index) =>{

      // auto select this document
      this.onItemSelect();

      if(this.props.onEnvelopeItemSelect) {
        this.props.onEnvelopeItemSelect(id, index);
      }
    }

    onClickTwisty = (isOpen) => {

      this.setState({openEnvelope: isOpen});

      // auto select this document if opened
      if (isOpen) {
        this.onItemSelect();
      }
    }


    render() {

        let itemClasses = ClassNames('mail-document-item',
          {pending: this.props.pending},
          {selected: this.props.selected},
          {unread: this.props.unread}
        );

        let rowClasses = ClassNames('mail-document-row',
          {view: this.props.selected && this.state.openEnvelope && this.props.envelopeItemSelectedIndex==null}
        );

        return (
          <li key={this.props.id} className={itemClasses}>
            <Twisty defaultState={false} onClickTwisty={this.onClickTwisty}/>

            <div className={rowClasses} onClick={this.onItemSelect}>
              <span className="mail-document-item-date">{this.props.date}</span>
              <span className="mail-document-item-name">
                <span className="text">{this.props.name}</span>
              </span>
              <div className="mail-document-item-subject">
                {this.props.subject}
              </div>
            </div>

            {this.state.openEnvelope ?
              <EnvelopeList
                  representativeDocId={this.props.id}
                  envelopeId={this.props.envelopeId}
                  selectedIndex={this.props.selected ? this.props.envelopeItemSelectedIndex : null}
                  envelopeItemSelected = {this.onEnvelopeItemSelect}
              />
              : null}
          </li>
        );
    }
}
