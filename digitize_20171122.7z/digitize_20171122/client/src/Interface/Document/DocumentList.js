// libs
import React from 'react';
import PropTypes from 'prop-types';

// application
import MailBox from 'src/Application/MailBox'

// components
import Warn from 'src/Interface/Common/Warn'
import DocumentListItem from './DocumentListItem'
import Loader from 'src/Interface/Common/Loader'
import Button from 'src/Interface/Common/Button'

// styles
import './DocumentList.scss';

export default class DocumentList extends React.Component {

    // prop types and default values
    static propTypes = {
      onSelect: PropTypes.func,
      mailboxId: PropTypes.number,
      mailboxCount: PropTypes.number
    };

    constructor() {
      super();
      this.state = {
        selectedIndex: null,
        items: null,
        hasMore: false,
        envelopeItemSelectedIndex: null
      };
    }

    componentDidMount(){
      if(this.props.mailboxId){
          MailBox.query.doumentsByMailbox(this.props.mailboxId, -1, (res) => {
            let currentItems = this.state.items==null ? res : this.state.items;
            console.log('currentItems: ',currentItems);
            this.setState({items: res, hasMore: (currentItems!= null) && (currentItems.length < this.props.mailboxCount)});

        });
      }
    }

    documentSelected = (id, index) =>  {
      // [TODO: Should not updatte React state like this!]
      this.state.items[index].unread = false;
      this.setState({selectedIndex: index, items: this.state.items, envelopeItemSelectedIndex: null});

      // call parent callback
      if(this.props.onDocumentSelect) {
        this.props.onDocumentSelect(id);
      }
    }

    onEnvelopeItemSelect = (id, index) =>  {
      this.setState({envelopeItemSelectedIndex: index});
      if(this.props.onEnvelopeItemSelect) {
        this.props.onEnvelopeItemSelect(id);
      }
    }

    _showMore = ()=>{
      if(this.state.hasMore)
      {
        
        let lastDocument = this.state.items[this.state.items.length-1];

        MailBox.query.doumentsByMailbox(this.props.mailboxId, lastDocument.docId, (res) => {
          let nextItem = this.state.items.splice(0);
          nextItem.push(...res);
          console.log('nextItem: ',nextItem);
          this.setState({items: nextItem, hasMore: (nextItem!= null) && (nextItem.length < this.props.mailboxCount)});
        });
        console.log('show more button clicked');
      }
    }

    render() {

      let component = this;

      return (
        <div>
          {
            this.props.mailboxId?
              <Loader size='7' visible={this.state.items==null}>
                {this.state.items && this.state.items.length == 0 ?
                  <Warn>There are no documents in this mailbox.</Warn> :
                  <div>
                    <ul className="mail-document-list">
                      {component.state.items && component.state.items.map(function(item, index){
                        return (
                          <DocumentListItem
                              key = {item.id}
                              id={item.docId}
                              name={item.documentName}
                              date={item.loadDate}
                              subject = {item.documentSubject}
                              envelopeId = {item.envelopeId}
                              pending = {item.isPendingToBeInTrim}
                              unread = {item.isUnread}
                              selected={component.state.selectedIndex == index}
                              envelopeItemSelectedIndex={component.state.envelopeItemSelectedIndex}
                              key={index}
                              index={index}
                              onItemSelect={component.documentSelected}
                              onEnvelopeItemSelect={component.onEnvelopeItemSelect}
                              onOpenEnvelope={component.onOpenEnvelope}
                          />);
                      })}
                    </ul>
                      {this.state.hasMore? <Button primary center onClick={this._showMore}>Show more</Button> : null}
                  </div>
                }
              </Loader>
            :
              <Warn>Please select a mail box.</Warn>
          }

        </div>
      );
    }
}
