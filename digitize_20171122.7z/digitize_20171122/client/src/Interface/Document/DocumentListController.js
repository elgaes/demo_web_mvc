// libs
import React from 'react';
import PropTypes from 'prop-types';

// application

// components
import Icon from 'src/Interface/Common/Icon'

// styles
import './DocumentListController.scss';

export default class DocumentListController extends React.Component {

    // prop types and default values
    static propTypes = {
    };

    constructor() {
      super();
      this.state = {
        selectedFilter: null,
      };
    }

    render() {

      return (
        <div className="mail-document-list-controller">

          <div className="mail-doc-menu">
            <div className="mail-menu">
              <Icon name='bars'/>
              <ul className="choices">
                <li className="item">Inbox</li>
                <li className="item">Outbox</li>
                <li className="item">Sent</li>
                <li className="item">Completed</li>
              </ul>
            </div>
          </div>

          <div className="mail-sort-by">
            <span className="sort-by">Sort by </span><span className="date">Date</span><Icon name='caret-down'/>
          </div>
        </div>
      );
    }
}
