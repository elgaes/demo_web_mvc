// libs
import React from 'react';

// styles
import 'src/Interface/Template/Template.scss';

//components
import Icon from 'src/Interface/Common/Icon'

export default class Template extends React.Component {

    render() {
        return (
          <div className="mail">
            <section className="mail-left">
              <button className="logo"><Icon name='envelope'/><strong>Mail</strong>Room</button>
              <ul className="mail-mailbox-list">
                <li className="mail-mailbox-item selected">
                  <span className="text">Claims</span><span className="number">34</span>
                </li>
                <li className="mail-mailbox-item">
                  <span className="text">PIR</span><span className="number">2,306</span>
                </li>
                <li className="mail-mailbox-item">
                  <span className="text">DIR </span><span className="number">1,503</span>
                </li>
                <li className="mail-mailbox-item">
                  <span className="text">Bereavement</span><span className="number">15</span>
                </li>
                <li className="mail-mailbox-item">
                  <span className="text">Payments</span><span className="number">24</span>
                </li>
                <li className="mail-mailbox-item">
                  <span className="text">Advances</span><span className="number">5</span>
                </li>
              </ul>

            </section>
            <section className="mail-center">
              <div className="mail-sort-by">
                <span className="sort-by">Sort by </span><span className="date">Date</span><Icon name='caret-down'/>
              </div>
              <ul className="mail-document-list">
                <li className="mail-document-item pending">
                  <span className="mail-document-item-date">19/10/2017</span>
                  <span className="mail-document-item-name">
                    <button className = "mail-document-item-twisty"><span className="icon fa fa-caret-right" ></span></button><span className="text">DOC-12345678</span>
                  </span>
                  <h5 className="mail-document-item-subject">
                    Comapany goals for 2016
                  </h5>
                </li>
                <li className="mail-document-item selected">
                  <span className="mail-document-item-date">19/10/2017</span>
                  <span className="mail-document-item-name">
                    <button className = "mail-document-item-twisty"><span className="icon fa fa-caret-down" ></span></button><span className="text">DOC-12345678</span>
                  </span>
                  <h5 className="mail-document-item-subject">
                    Design for health project
                  </h5>
                  <ul className="mail-envelope-list">
                    <li className="mail-envelope-item pending">Doc 1 <span className="mailbox">PIR</span></li>
                    <li className="mail-envelope-item">Doc 2 <span className="mailbox">DIR</span></li>
                    <li className="mail-envelope-item">Doc 2 <span className="mailbox">DIR</span></li>
                    <li className="mail-envelope-item">Doc 2 <span className="mailbox">DIR</span></li>
                    <li className="mail-envelope-item actioned">Doc 2 <span className="mailbox">Claims</span></li>
                    <li className="mail-envelope-item actioned">Doc 2 <span className="mailbox">Payments</span></li>
                    <li className="mail-envelope-item internal-redirection">Doc 3 <span className="mailbox">Advances</span></li>
                    <li className="mail-envelope-item external-redirection">Doc 4 <span className="mailbox">Advances</span></li>
                  </ul>
                </li>
                <li className="mail-document-item">
                  <span className="mail-document-item-date">18/10/2017</span>
                  <span className="mail-document-item-name">
                    <button className = "mail-document-item-twisty"><span className="icon fa fa-caret-right" ></span></button><span className="text">DOC-12345678</span>
                  </span>
                  <h5 className="mail-document-item-subject">
                    Comapany goals for 2016
                  </h5>
                </li>
                <li className="mail-document-item unread">
                  <span className="mail-document-item-date">17/10/2017</span>
                  <span className="mail-document-item-name">
                    <button className = "mail-document-item-twisty"><span className="icon fa fa-caret-right" ></span></button><span className="text">DOC-12345678</span>
                  </span>
                  <h5 className="mail-document-item-subject">
                    Comapany goals for 2016
                  </h5>
                </li>
                <li className="mail-document-item unread">
                  <span className="mail-document-item-date">16/10/2017</span>
                  <span className="mail-document-item-name">
                    <span className="icon"></span>DOC-12345678
                  </span>
                  <h5 className="mail-document-item-subject">
                    Comapany goals for 2016
                  </h5>
                </li>
              </ul>
            </section>
            <section className="mail-right">
              <div className="mail-right-up-section">
                <ul className="mail-document-actions">
                  <li><a href=""><Icon name='user'/> Assign</a></li>
                  <li><a href=""><Icon name='mail-forward'/> Redirect</a></li>
                  <li><a href=""><Icon name='i-cursor'/> Rename</a></li>
                </ul>
                <div className="mail-search-container">
                  <span className="icon fa fa-search"></span><input className="mail-search-box" placeholder="Search" type="text" />
                </div>
              </div>
              <div className="mail-document-view">
                <object data="img/scan.pdf" type="application/pdf">
                  <p>This browser does not support PDFs. Please download the PDF to view it: <a href="img/scan.pdf">Download PDF</a></p>
                </object>
              </div>
              {/*<button className="example">Button</button>*/}
            </section>
          </div>
        );
    }
}
