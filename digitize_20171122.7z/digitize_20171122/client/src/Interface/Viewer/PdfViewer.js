// libs
import React from 'react';
import PropTypes from 'prop-types';

// styles
import './PdfViewer.scss';


// components
import Warn from 'src/Interface/Common/Warn'

export default class PdfViewer extends React.Component {

    // prop types and default values
    static propTypes = {
      docId: PropTypes.number,
    };


    // component render method
    render() {
        const dataPrefix = '/service/views/document/Document?documentId=';
console.log('docId: ', this.props.docId);
        return (
            <div className="mail-document-view">
                { this.props.docId?
                    <object data={dataPrefix+this.props.docId} type="application/pdf">
                        <p>This browser does not support PDFs. Please download the PDF to view it: <a href={dataPrefix+this.props.docId}>Download PDF</a></p>
                    </object>
                    :
                    <Warn>Please select a document.</Warn>
                }
            </div>
        );
    }
}
