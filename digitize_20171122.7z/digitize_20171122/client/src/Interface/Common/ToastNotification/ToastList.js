// libs
import React from 'react';
import PropTypes from 'prop-types';
import ClassNames from 'classnames';


//component
import ToastItem from 'src/Interface/Common/ToastNotification/ToastItem'

// styles
import './ToastList.scss';

export default class ToastList extends React.Component {

    constructor() {
        super();
        this.state = {
            show: this.props.show,
            toastList: this.props.toastList
        };
      }
    // prop types and default values
    static propTypes = {
        show: PropTypes.bool,
        small: PropTypes.bool,
        medium: PropTypes.bool,
        large: PropTypes.bool,
        toastList: PropTypes.array,       
    };

    static defaultProps ={
        toastList: []
    }
    componentWillReceiveProps(nextProps)
    {
       this.setState({toastList: nextProps.toastList});
    }
   
    // component render method
    render() {
        let ulClasses = ClassNames(
            {center: this.props.small}, {left: this.props.medium}, {right: this.props.large}
        )
        
        if(this.state.show)
        {
            return (
                <ul className={'toast-container '+ulClasses} >
                    {this.state.toastList.map((item)=>{<ToastItem  ulClasses/>})}
                </ul>
            );
        }
        
    }
}
