// libs
import React from 'react';
import PropTypes from 'prop-types';
import ClassNames from 'classnames';

//Component
import Icon from '../Icon'
// styles
import './ToastItem.scss';

export default class ToastItem extends React.Component {

    constructor() {
        super();
        this.state = {
          show: this.props.show,
         
        };
      }
    // prop types and default values
    static propTypes = {
        show: PropTypes.bool,
        small: PropTypes.bool,
        medium: PropTypes.bool,
        large: PropTypes.bool,
        success: PropTypes.bool,
        error: PropTypes.bool,
        info: PropTypes.bool,
        warning: PropTypes.bool,
        onClick: PropTypes.func
    };

    _onClick=()=>{
        if(this.props.onClick){
            this.setState({show:false});
        }
    }
    // component render method
    render() {
        let liClasses = ClassNames(
            {center: this.props.small}, {left: this.props.medium}, {right: this.props.large},
            {success: this.props.success},{error: this.props.error},{info: this.props.info},
            {warning: this.props.warning}
        )
        let iconSelector;
        if(this.props.success){
            iconSelector = <Icon name = 'check-circle-o'/>;
        }
        else if(this.props.error){
            iconSelector = <Icon  name = 'hand-paper-o'/>;
        }
        else if(this.props.info){
            iconSelector = <Icon name = 'info-circle'/>;
        }
        else if(this.props.warning){
            iconSelector = <Icon name = 'exclamation-circle'/>
        }

        return (
            <li className={'toast '+liClasses} >
                {iconSelector}
                <p>
                    {this.props.text}
                </p>
                <Icon name = 'times' onClick = 'this._onClick'/>
            </li>
        );
    }
}
