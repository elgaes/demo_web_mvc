// libs
import React from 'react';
import PropTypes from 'prop-types';
import ClassNames from 'classnames';

//components


// styles
// import './ModalContent.scss';

export default class ModalContent extends React.Component {
   
    constructor() {
        super();       
      }
   
    // prop types and default values
    static propTypes = {
        title: PropTypes.string.isRequired,
        onChange: PropTypes.func,
    }; 

    _onChange=(e)=>{
        
        let value = e.target.value;
        if(value != null && value.trim().length > 0 && this.props.onValueChange)
        {
            this.props.onValueChange(value);
        }
    }
  
    render() {    
        return (
          <div className = 'text-area'>
            <p className = 'text-area-title'>{this.props.title}</p>
            <textarea onChange={this._onChange}></textarea>            
          </div>
        );
    }
}
