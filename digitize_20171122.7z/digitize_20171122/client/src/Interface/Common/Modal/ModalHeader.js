// libs
import React from 'react';
import PropTypes from 'prop-types';
import ClassNames from 'classnames';

//components


// styles
import './ModalHeader.scss';

export default class ModalHeader extends React.Component {
   
    render() {    
        return (
          <div className = 'modal-header'>
            {this.props.children}            
          </div>
        );
    }
}
