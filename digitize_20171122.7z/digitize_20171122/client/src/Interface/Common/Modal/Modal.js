// libs
import React from 'react';
import PropTypes from 'prop-types';
import ClassNames from 'classnames';

//components
// import SimpleTypeahead from './Common/SimpleTypeahead'
import Icon from 'src/Interface/Common/Icon'
import ModalHeader from './ModalHeader';
import ModalFooter from './ModalFooter';
import ModalContent from './ModalContent';

// styles
import './Modal.scss';

export default class Modal extends React.Component {

    static Header = ModalHeader;
    static Content = ModalContent;
    static Footer = ModalFooter;
    
    // prop types and default values
    static propTypes = {
        onClose: PropTypes.func,        
        show: PropTypes.bool,
        
        small: PropTypes.bool,
        medium: PropTypes.bool,
        large: PropTypes.bool,        
    };

    render() {

        const panelClasses = ClassNames('mail-modal-panel',
            {small: this.props.small},
            {medium: this.props.medium},
            {large: this.props.large}
        );
  

        // Render nothing if the "show" prop is false
        if(!this.props.show) {
          return null;
        }
    
        return (
          <div className = 'mail-modal'>
            <div className = {panelClasses}>
                {this.props.children}

                <div className="close">
                    <Icon className='close-icon' name='times-circle-o' onClick={this.props.onClose}/>
                </div>                    
            </div>
          </div>
        );
    }
}
