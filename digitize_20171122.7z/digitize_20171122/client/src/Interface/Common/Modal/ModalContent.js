// libs
import React from 'react';
import PropTypes from 'prop-types';
import ClassNames from 'classnames';

//components


// styles
import './ModalContent.scss';

export default class ModalContent extends React.Component {
   

    render() {    
        return (
          <div className = 'modal-content'>
            {this.props.children}      
          </div>
        );
    }
}
