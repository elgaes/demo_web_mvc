// libs
import React from 'react';
import PropTypes from 'prop-types';
import ClassNames from 'classnames';

//components


// styles
import './ModalFooter.scss';

export default class ModalFooter extends React.Component {
   
    render() {    
        return (
          <div className = 'modal-footer'>
            {this.props.children}            
          </div>
        );
    }
}
