// libs
import React from 'react';
import PropTypes from 'prop-types';
import ClassNames from 'classnames';

// styles
import './Button.scss';

export default class Loader extends React.Component {

    // prop types and default values
    static propTypes = {
        primary: PropTypes.bool,
        secondary: PropTypes.bool,
        disable: PropTypes.bool,
        empty: PropTypes.bool,
        left: PropTypes.bool,
        right: PropTypes.bool,
        center: PropTypes.bool,
        onClick: PropTypes.func
    };

    onClick=()=>{
        if(this.props.onClick){
            this.props.onClick();
        }
    }
    // component render method
    render() {
        let divClasses = ClassNames(
            {center: this.props.center}, {left: this.props.left}, {right: this.props.right}
        )
        let classes = ClassNames(
          {primary: this.props.primary}, {secondary: this.props.secondary} ,{disable: this.props.disable},{empty: this.props.empty}
        );

        return (
            <div className={divClasses} >
                <button className={classes} onClick={this.onClick}>{this.props.children}</button>
            </div>
        );
    }
}
