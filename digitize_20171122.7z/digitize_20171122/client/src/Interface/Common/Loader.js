// libs
import React from 'react';
import PropTypes from 'prop-types';

// styles
import './Loader.scss';

export default class Loader extends React.Component {

    // prop types and default values
    static propTypes = {
      size: PropTypes.string,
      visible: PropTypes.bool
    };

    // component render method
    render() {
        return (
            <div>
                {this.props.visible?
                    <div className = 'loader'>
                        <i className='fa fa-spinner fa-pulse' style={{fontSize: this.props.size+'rem'}}></i>
                    </div>
                    :
                    this.props.children
                }
            </div>
        );
    }
}
