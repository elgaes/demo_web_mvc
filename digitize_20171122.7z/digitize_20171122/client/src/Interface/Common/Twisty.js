// libs
import React from 'react';
import PropTypes from 'prop-types';

// components
import Icon from 'src/Interface/Common/Icon'

// styles
import './Twisty.scss';

export default class Twisty extends React.Component {

    // prop types and default values
    static propTypes = {
      defaultState: PropTypes.bool,
      onClickTwisty: PropTypes.func
    }

    static defaultProps  = {
      defaultState: false
    }

    constructor() {
      super();
      this.state = {
        isOpen: false
      }
    }

    onClickTwisty = () => {    
      let newState = !this.state.isOpen;

      this.setState({isOpen: newState});

      if(this.props.onClickTwisty) {
        this.props.onClickTwisty(newState);
      }
    }  

    // component render method
    render() {
      return (
        <button className="twisty" onClick={this.onClickTwisty}>        
          {this.state.isOpen ? <Icon name="caret-down" /> : <Icon name="caret-right" />}
        </button>  
      );
    }
}
