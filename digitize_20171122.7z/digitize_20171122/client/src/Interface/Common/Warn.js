// libs
import React from 'react';

// components
import Icon from 'src/Interface/Common/Icon'

// styles
import './Warn.scss';

export default class Warn extends React.Component {

    // component render method
    render() {
        return (
          <div className="warn">
           <Icon name="exclamation-circle" />
           <p>{this.props.children}</p>
          </div>
        );
    }
}
