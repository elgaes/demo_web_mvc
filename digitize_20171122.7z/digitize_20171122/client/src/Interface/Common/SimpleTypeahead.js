/*
 * Customized react-simple-typeahead component.
 * Taken from http://github.com/Nagogus/react-simple-typeahead
 *
 * Added:
 *  - Extra callback handlers
 *  - Fixed original code bugs
 *  - Default styling with uikit & html input.
 *  - Debounced trigger for onChange dropdown handling
 */

import React from 'react';
import ReactDOM from 'react-dom';
import debounce from 'lodash/debounce';  // important for UX + performance
import classNames from 'classnames';
import PropTypes from 'prop-types';

// styles
import './SimpleTypeahead.scss';

class Option extends React.Component {

  constructor() {
    super();
    this.state = {}
  }

  render() {
    let selectedClassFlag = {};
    let classList;

    selectedClassFlag[this.props.customClasses.listItemSelected] = this.props.selected;
    classList = classNames(this.props.customClasses.listItem, selectedClassFlag);

    return (
      <li
          className={classList}
          onClick={this.props.onClick}
          onMouseEnter={this.props.onMouseEnter}
          aria-hidden={(!this.props.selected)?'true':'false'}
          aria-live='rude'
          aria-label={(this.props.selected)?this.props.value:null}
      >
        <span role='menuitem'>{this.props.value}</span>
      </li>
    )
  }
}

Option.propTypes = {
   selected: PropTypes.bool,
   value: PropTypes.string,
   customClasses: PropTypes.object,
   onClick: PropTypes.func,
   onMouseEnter: PropTypes.func
};

class Options extends React.Component {

  constructor() {
    super();
  }

  componentDidUpdate(prevProps) {
    // only scroll into view if the active item changed last render
    if (this.props.selectedIndex !== prevProps.selectedIndex) {
      let selIdx = this.props.selectedIndex;
      let container = ReactDOM.findDOMNode(this);
      let item = this.refs['option_'+this.props.selectedIndex];

      // Don't do this if it's hidden.
      if (selIdx >= 0 && container && item) {
        let domItem = ReactDOM.findDOMNode(item);
        let listSize = this.props.options;

        container.scrollTop = domItem.offsetTop - (container.clientHeight / 2.5);

        //scrollIntoView(domItem, container);
      }
    }
  }

  // triggers when using mouse to click an option.
  onClick = (index) => {
    this.props.onOptionSelected(index);
  }

  onMouseOver = (index) => {
    this.props.selectedIndex = index;
    this.props.onOptionSelected(index);
    this.setState(); // force re-render
  }

  render() {
    if (!this.props.show) {
      return null;
    }

    let options = this.props.options.map((option, index) => {
      let key = 'option_' + index;
      return <Option
          selected={(index === this.props.selectedIndex)}
          value={option.text}
          customClasses={this.props.customClasses}
          onClick={this.onClick.bind(this, index)}
          onMouseOver={this.onMouseOver.bind(this, index)}
          key={key}
          ref={key}
             ></Option>
    });

    return (
      <ul className={this.props.customClasses.list} role='menu' aria-expanded={!this.props.show}>
        {options}
      </ul>
    )
  } r
}

Options.propTypes = {
  show: PropTypes.bool,
  options: PropTypes.array.isRequired,
  selectedIndex: PropTypes.number,
  customClasses: PropTypes.object,
  onOptionSelected: PropTypes.func,
  onInputEmpty: PropTypes.func
};


const KEY_UP = 38;
const KEY_DOWN = 40;
const KEY_ENTER = 13;
const KEY_ESC = 27;
const KEY_SPACE = 32;
const KEY_BACKSPACE = 8;
const KEY_TAB = 9;

export default class SimpleTypeahead extends React.Component {

  constructor() {
    super();

    this.state = {
      showResults: false,
      selectedIndex: -1,
      results: [],
      searchTerm: '',
      lastSearchLength: 0,
      isMouseOver: false
    };
  }

  _doNotSearch = false;

  componentDidUpdate(prevProps) {
    if (prevProps.defaultValue.value !== this.props.defaultValue.value) {
       this.input.value = this.props.defaultValue.text;
    }
  }

  componentWillMount() {
    // Debounce search results
    this.processResultsDebounced = debounce(this.processResults, this.props.searchRenderDelay);

    this.customClasses = Object.assign({
      // Borrowing style classes imported from dropdown.less
      wrapper: 's-typeahead-wrapper',
      input: 's-text-input',
      listWrapper: 's-typeahead-list--wrapper',
      list: 's-typeahead-list',
      listItem: 's-typeahead-list-item',
      listItemSelected: 's-typeahead-list-item--selected'
    }, this.props.customClasses);
  }

  componentDidMount() {
    // disabled - fixed defaultValue state binding
    // Used for rendering text based on a page's requirement to
    // pre-populate the input text field.
    // let selectedInputText = this.props.onPageLoad();
    // if (typeof selectedInputText != 'undefined')
    //   this.input.value = selectedInputText;
  }

  hide = () => {
    if (this.state.showResults && this.state.results.length >= 0 && this.input.value.trim().length > 0) {
      this.setState({showResults: false, selectedIndex: 0});
    }

    else if (this.state.results.length == 0 || this.input.value == null || this.input.value.trim().length == 0
      || (this.state.results.length > 1 && this.state.selectedIndex == -1))
    {
      this.setState({showResults: false, selectedIndex: -1});
    }
  }

  show = () => {
    let resultSize = this.state.results.length;
    if (!this.state.showResults && resultSize > 0
        && this.state.isInputFocused && this.input.value.trim().length > 0)
    {
      if (resultSize == 1) {
        this.setState({showResults: true, selectedIndex: 0 });
      } else {
        this.setState({showResults: true, selectedIndex: -1 });
      }
    }

  }

  // Whenever results are changed based on current value query,
  // re-render the dropdown list.
  processResults = (value) => {
    if (!value)
      value = this.input.value.trim().toLowerCase();

    // optimization - don't re-render search results if there is no change in search term.
    if (value.length == this.state.lastSearchLength && value == this.state.searchTerm) {
      // Usability - if there are results but is currently hidden, show it.
      if (!this.state.showResults && this.state.results.length > 0)
        this.show();

      return;
    }

    // Let's maintain the previously held values - they will
    // be needed for the conditional checks used for optimizing
    // the search rendering performance.
    let previousSearchTerm = this.state.searchTerm;
    let previousSearchLength = this.state.lastSearchLength;
    this.state.searchTerm = value;
    this.state.lastSearchLength = value.length;

    // keep scope of current results object.
    let results = this.state.results;
    let previousResultsSize = results.length;
    let selectedIndex = this.state.selectedIndex;

    // Min search term threshold
    if (value.length < this.props.minSearchLength)
      //|| value.length < previousSearchLength) // lodash.debounce() addresses performance problem here
    {
      // Optimization - Don't re-render the component if zeroed already.
      if (results.length == 0)
        return;

      results.length = 0;
      //this.setState({results: [], selectedIndex: -1});
      this.setState({results: results, selectedIndex: -1, showResults: false});
      //this.hide();
    }
    else { // Render results

      // Optimization - if zero results, do not query main search array.
      if (value.length > this.minSearchLength
        && previousSearchLength < value.length
        && results.length == 0)
        return;

      // Optimization (only where maxOptionsCount is NOT specified) - filter on current results
      // to reduce time to filter.
      if (this.props.maxOptionsCount == -1
        && this.state.results.length > 0
        && previousSearchLength < value.length) {
        // unusual fast array shrinker. borrowed removeIf1 implementation from
        //  https://jsperf.com/splice-vs-filter
        // disabled because it was still creating a new array.
        // if (!results.removeIf1) {
        //   results.removeIf1 = (expression) => {
        //     let res = [];
        //     for(let idx=0; idx < results.length; idx++) {
        //       let currentItem = results[idx];
        //       if(!expression(currentItem))
        //         res.push(currentItem);
        //     }
        //     return res;
        //   };
        // }
        // results = results.removeIf1((option) => {
        //   return option.text.toLowerCase().indexOf(value) == -1;
        // });

        results = this.state.results.filter((option) => {
          return option.text.toLowerCase().indexOf(value) > -1;
        });
      }
      else if (value.length > this.props.minSearchLength
        && previousSearchLength > value.length
        && results.length == 0) {
        // Optimization - If no results returned in search
        return;
      }
      else {
        // fall over to the standard method of querying the source array.
        // Optimization - limit size during filter rather than creating another array
        let _optionCount = 0;
        results = this.props.options.filter((option) => {
          //return option.text.toLowerCase().indexOf(value.trim().toLowerCase()) > -1;
          if (this.props.maxOptionsCount > 0)
            if (_optionCount > this.props.maxOptionsCount)
              return false;

          let optionIndexMatch = option.text.toLowerCase().indexOf(value);

          if (this.props.maxOptionsCount > 0) {
            return (optionIndexMatch > -1 && (++_optionCount) <= this.props.maxOptionsCount);
          } else {
            return (optionIndexMatch > -1);
          }
        });

        // if (this.props.maxOptionsCount > 0) {
        //   results = results.slice(0, this.props.maxOptionsCount);
        // }

        // sort results - only needed on the first pass
        results.sort((a,b) => {return (a.text < b.text) ? -1 : (a.text > b.text) ? 1 : 0; });
      }

      // Results post-processing

      // Usability - keep current value on search if still present?
      let newSelIdx = -1;
      if (results.length>=previousResultsSize && selectedIndex < (this.state.results.length - 1)) {
        let checkValue = results[selectedIndex];
        if (checkValue) {
          if (this.state.results[selectedIndex].text === checkValue.text) {
            newSelIdx = selectedIndex;
          }
        }
      }

      // Usability - if one result returns, select it by default.
      if (newSelIdx == -1 && results.length == 1) {
        newSelIdx = 0;
      }

      // Avoid the possible race condition - showResults when not in focus
      this.setState((this.state.isInputFocused)
        ? { results: results, selectedIndex: newSelIdx, showResults: true }
        : { results: results, selectedIndex: newSelIdx }
      );
      //this.show();
    }
  }

  selectOption = (e) => {
    let selectedIndex = this.state.selectedIndex;
    let selectedOption = this.state.results[selectedIndex];

    // workaround: in case event is not passed
    if (e == null) {
      if (selectedOption == null) {
        e = {target: {name: '', value:''}};
      } else {
        e = {target: {name: this.props.name, value:selectedOption.text}};
      }
    }

    // if there is a currently valid selection (eg: search result)
    if(selectedOption) {
      // clear results table to only have the current option
      this.state.results.length = 1;
      this.state.results[0] = selectedOption;

      // Populate text field then hide autocomplete
      this.input.value = selectedOption.text;
      this.hide();

      // run callback function
      this.props.onOptionSelected(e, selectedOption);
    }
    // record free text if no valid option has been set
    else {
      let freeTextValue = this.input.value.trim();

      if (freeTextValue.length > 0) {
        this.props.onOptionSelected(e, {text:freeTextValue,value:freeTextValue});
      } else {
        this.props.onOptionSelected(e, {text:'',value:''});
      }
      this.state.selectedIndex = -1;
      this.hide();
    }
  }

  setSelectedIndex = (index, callback) => {
    this.setState({selectedIndex: index}, callback);
  }

  updateTextOnSelectedIndex = () => {
    let component = this;

    let selectedIndex = component.state.selectedIndex;
    let selectedOption = component.state.results[selectedIndex];
    if (selectedIndex > -1) {
      component.input.value = selectedOption.text;
    }
  }

  selectNextIndex = () => {
    let currentIndex = this.state.selectedIndex;
    let nextIndex = ++currentIndex;
    if (nextIndex >= this.state.results.length) {
      nextIndex = 0;
    }
    // needed to update text field and prevent a search.
    this._doNotSearch = true;
    this.setSelectedIndex(nextIndex, this.updateTextOnSelectedIndex);
  }

  selectPreviousIndex = () => {
    let currentIndex = this.state.selectedIndex;
    let previousIndex = --currentIndex;
    if (previousIndex < 0) {
      previousIndex = this.state.results.length - 1;
    }
    // needed to update text field and prevent a search.
    this._doNotSearch = true;
    this.setSelectedIndex(previousIndex, this.updateTextOnSelectedIndex);
  }

  // Depends how the blur is triggered. eg: mouseclick away or on
  // dropdown?
  handleBlur = (e) => {
    this.state.isInputFocused = false;
    // HACK - on triple j!
    if (!this.state.isMouseOver && (
      (this.state.showResults && this.state.results.length > 0) ||
      (this.state.results.length == 0))
    ) {

      this.handleKeyPress(e, KEY_ENTER);
    } else if (this.input.value.trim().length == 0) {
      this.state.selectedIndex = -1;
      this.props.onOptionSelected(e, {text:'',value:''});
    }
  }

  // If there is more than one match but you really want to select
  // the option verbatim, choose the closest match
  setClosestMatch = () => {
    let results = this.state.results;

    if (this.state.showResults && results.length > 0) {

      // sift through list, change selected index
      let value = this.state.searchTerm;

      results = results.filter((option) => {
        return (option.text.toLowerCase() === value.trim().toLowerCase());
      });

      if (results.length == 1) {
        this.state.results = results;
        this.state.selectedIndex = 0;
      }
    }
    this.selectOption();
  }

  // All keypresses go here. Usability features are handled.
  handleKeyPress = (e, keyCode) => {
    switch (keyCode) {
      case KEY_DOWN:
        if (this.state.results.length > 0) {
          if (!this.state.showResults) {
            this.show();
          } else {
            this.selectNextIndex();
          }
        }

        break;
      case KEY_UP:
        if (this.state.showResults && this.state.results.length > 0) {
          this.selectPreviousIndex();
        }
        break;
      case KEY_TAB:
        if (!this.state.showResults) {
          this.hide();
          break;
        }
        // passthrough deliberate
      case KEY_ENTER:
        if (this.state.showResults && this.state.selectedIndex >= 0) {
          this.selectOption({target:e.target});
        } else if (this.state.showResults && this.state.results.length >= 0 && this.state.selectedIndex < 0) {
          this.setClosestMatch();
        } else {
          this.selectOption({target:e.target});
          this.hide();
        }

        break;
      case KEY_BACKSPACE:
        this.state.selectedIndex = -1;
        break;
      case KEY_ESC:
        if (this.state.selectedIndex == -1)
          this.setClosestMatch();
        this.hide();
        break;
      case KEY_SPACE:
        if (!this.state.showResults) {
          if (this.state.results.length > 0
            && this.input.value.trim().length >= this.props.minSearchLength) {
            this.show();
          } else {
            this.processResultsDebounced();
          }
        }
    }
  }

  onKeyDown = (event) => {
    this.handleKeyPress(event, event.keyCode);
}

  onKeyUp = (event) => {
    //this.handleKeyPress(event.keyCode);
  }

  onChange = (e) => {
    let value = this.input.value;
    if (!this._doNotSearch) {
      if (value.trim().length > 0) {
        //this.processResults(value);  // feel free to compare performance haha
        this.processResultsDebounced();
      } else {
        this.hide();
        this.props.onInputEmpty(e);
      }
    } else {
      // Reset this back to false (needed for updaing text field without invoking a search)
      this._doNotSearch = false;
    }

    e.preventDefault();
  }

  // Handle selected option event via callback from child Option,
  // then actually set the selected option state.
  onOptionSelected = (index) => {
    this.setSelectedIndex(index, this.selectOption);
  }

  // Highlight the text field
  onMouseUp = () => {
    //this.input.select();
    // if (!this.state.showResults && this.state.isMouseOver)
    //   this.onFocus();
  }

  onFocus = () => {
    this.state.isInputFocused = true;
    if (!this.state.showResults) {
      if (this.input.value.trim().length > this.props.minSearchLength
        && this.state.results.length > 0) {
        this.show();
      }
      else {
        let val = this.input.value;
        if (val.trim().length >= this.props.minSearchLength) {
          this.processResults();
        }
      }
    }
  }

  setMouseoverMode = (flag) => {
    this.state.isMouseOver = flag;
  }

  render() {

    return (
      <div className={this.customClasses.wrapper}
          onMouseOver={(()=>{this.setMouseoverMode(true)}).bind(this)}
          onMouseOut={(()=>{this.setMouseoverMode(false)}).bind(this)}
          onFocus={this.onFocus.bind(this)}
          onBlur={this.handleBlur.bind(this)}
          role='search'
          aria-label='mail box dropdown'
          aria-haspopup={true}
          aria-autocomplete='listbox'
      >
        <label className="" htmlFor={this.props.name}></label>
        <input
            type="search"
            ref={(input) => { if (input != null) { this.input = input;}}}
            className={this.customClasses.input}
            id={this.props.name}
            name={this.props.name}
            defaultValue={this.props.defaultValue.text}
            placeholder={this.props.placeholder}
            onKeyUp={this.onKeyUp}
            onKeyDown={this.onKeyDown}
            onChange={this.onChange}
            //onMouseUp={this.onMouseUp.bind(this)}
            autoComplete={'off'}
            role='presentation'
        />
        {/* <i className="dropdown icon"
            onClick={this.toggleDropdown}
        ></i> */}
        <div className={this.customClasses.listWrapper}>
          <Options
              ref={(options) => { if (options != null) { this.options = options;}}}
              customClasses={this.customClasses}
              show={this.state.showResults}
              options={this.state.results}
              selectedIndex={this.state.selectedIndex}
              onOptionSelected={this.onOptionSelected}
              onInputEmpty={this.props.onInputEmpty}
          />
        </div>
      </div>
    );
  }
}

SimpleTypeahead.propTypes = {
  //defaultValue: React.PropTypes.string,
  defaultValue: PropTypes.object,
  placeholder: PropTypes.string,
  options: PropTypes.array.isRequired,
  onOptionSelected: PropTypes.func,
  onInputEmpty: PropTypes.func,
  maxOptionsCount: PropTypes.number,
  customClasses: PropTypes.object,
  minSearchLength: PropTypes.number,
  //onPageLoad: React.PropTypes.func,
  searchRenderDelay: PropTypes.number
};

SimpleTypeahead.defaultProps = {
  defaultValue: {text:'',value:''},
  placeholder: '',
  options: [],
  onOptionSelected: () => {},
  onInputEmpty: () => {},
  maxOptionsCount: -1,
  customClasses: {},
  minSearchLength: 1,
  //onPageLoad: () => {},
  searchRenderDelay: 100
};
