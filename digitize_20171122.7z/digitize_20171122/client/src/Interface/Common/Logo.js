// libs
import React from 'react';

// components
import Icon from 'src/Interface/Common/Icon'

// styles
import './Logo.scss';

export default class Logo extends React.Component {

    // component render method
    render() {
        return (
          <button className="logo"><Icon name='envelope'/><strong>Mail</strong>Room</button>
        );
    }
}
