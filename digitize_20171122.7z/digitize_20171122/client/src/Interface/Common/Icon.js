// libs
import React from 'react';
import PropTypes from 'prop-types';


export default class Icon extends React.Component {

    // prop types and default values
    static propTypes = {
      name: PropTypes.string.isRequired,
      onClick: PropTypes.func
    };

    onClick=()=>{
      if(this.props.onClick){
          this.props.onClick();
      }
  }

    // component render method
    render() {
        return (
          <i className={'icon fa fa-'+this.props.name} onClick={this.onClick}></i>
        );
    }
}
