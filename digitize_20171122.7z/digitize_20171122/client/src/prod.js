// This file only applies to production deploys - all entry points
console.log = () => undefined;
