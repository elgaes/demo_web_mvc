package au.gov.dva.digitize.jpa;

import java.io.Serializable;
import javax.persistence.*;
import java.util.List;


/**
 * The persistent class for the SEC_PERMISSION database table.
 * 
 */
@Entity
@Table(name="SEC_PERMISSION")
@NamedQuery(name="SecPermission.findAll", query="SELECT s FROM SecPermission s")
public class SecPermission implements Serializable {
	private static final long serialVersionUID = 1L;
	private int id;
	private String label;
	private String objType;
	private List<SecAccess> secAccesses;

	public SecPermission() {
	}


	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}


	public String getLabel() {
		return this.label;
	}

	public void setLabel(String label) {
		this.label = label;
	}


	@Column(name="OBJ_TYPE")
	public String getObjType() {
		return this.objType;
	}

	public void setObjType(String objType) {
		this.objType = objType;
	}


	//bi-directional many-to-one association to SecAccess
	@OneToMany(mappedBy="secPermission")
	public List<SecAccess> getSecAccesses() {
		return this.secAccesses;
	}

	public void setSecAccesses(List<SecAccess> secAccesses) {
		this.secAccesses = secAccesses;
	}

	public SecAccess addSecAccess(SecAccess secAccess) {
		getSecAccesses().add(secAccess);
		secAccess.setSecPermission(this);

		return secAccess;
	}

	public SecAccess removeSecAccess(SecAccess secAccess) {
		getSecAccesses().remove(secAccess);
		secAccess.setSecPermission(null);

		return secAccess;
	}

}