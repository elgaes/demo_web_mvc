package au.gov.dva.digitize.jpa;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the AUDIT_REC database table.
 * 
 */
@Entity
@Table(name="AUDIT_REC")
@NamedQuery(name="AuditRec.findAll", query="SELECT a FROM AuditRec a")
public class AuditRec implements Serializable {
	private static final long serialVersionUID = 1L;
	private int id;
	private String action;
	private String crtBy;
	private Timestamp crtDate;
	private String details;
	private int objId;
	private String objType;
	private String recType;

	public AuditRec() {
	}


	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}


	public String getAction() {
		return this.action;
	}

	public void setAction(String action) {
		this.action = action;
	}


	@Column(name="CRT_BY")
	public String getCrtBy() {
		return this.crtBy;
	}

	public void setCrtBy(String crtBy) {
		this.crtBy = crtBy;
	}


	@Column(name="CRT_DATE")
	public Timestamp getCrtDate() {
		return this.crtDate;
	}

	public void setCrtDate(Timestamp crtDate) {
		this.crtDate = crtDate;
	}


	public String getDetails() {
		return this.details;
	}

	public void setDetails(String details) {
		this.details = details;
	}


	@Column(name="OBJ_ID")
	public int getObjId() {
		return this.objId;
	}

	public void setObjId(int objId) {
		this.objId = objId;
	}


	@Column(name="OBJ_TYPE")
	public String getObjType() {
		return this.objType;
	}

	public void setObjType(String objType) {
		this.objType = objType;
	}


	@Column(name="REC_TYPE")
	public String getRecType() {
		return this.recType;
	}

	public void setRecType(String recType) {
		this.recType = recType;
	}

}