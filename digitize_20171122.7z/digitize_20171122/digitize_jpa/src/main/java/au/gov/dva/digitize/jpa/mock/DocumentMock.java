package au.gov.dva.digitize.jpa.mock;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
/**
 * The persistent class for the DOCUMENT database table.
 * 
 */
public class DocumentMock implements Serializable {
	private static final long serialVersionUID = 1L;
	
	
	private Integer documentId;
	private String documentName;
	private LocalDate loadDate;
	private String title;
	private Boolean isPendingToBeInTrim;
	private Boolean isUnread;
	private byte[] contents;
	
	
	

	public Integer getDocumentId() {
		return documentId;
	}

	public void setDocumentId(Integer documentId) {
		this.documentId = documentId;
	}

	public String getDocumentName() {
		return documentName;
	}

	public void setDocumentName(String docmentName) {
		this.documentName = docmentName;
	}

	public Boolean getIsPendingToBeInTrim() {
		return isPendingToBeInTrim;
	}

	public void setIsPendingToBeInTrim(Boolean isPendingToBeInTrim) {
		this.isPendingToBeInTrim = isPendingToBeInTrim;
	}

	public Boolean getIsUnread() {
		return isUnread;
	}

	public void setIsUnread(Boolean isUnread) {
		this.isUnread = isUnread;
	}

	public byte[] getContents() {
		return contents;
	}

	public void setContents(byte[] contents) {
		this.contents = contents;
	}

	

	

	public String getLoadDate() {
		
		return loadDate.format(DateTimeFormatter.BASIC_ISO_DATE);
	}

	public void setLoadDate(LocalDate loadDate) {
		this.loadDate = loadDate;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public DocumentMock() {
		/*Path path = Paths.get("H:\\scan\\20161108_00000026_D800_Tier2_0003.pdf");
		try {
			setContents(Files.readAllBytes(path));
			setDocuId("20161108_00000026_D800");
		} catch (IOException e) {
			e.printStackTrace();
		}*/
	}


	

}