package au.gov.dva.digitize.jpa.custom;

public class ContainerWithCount {

	private int containerId;
	private String containerName;
	private long unreadDocumentCount;
	
	public ContainerWithCount (int containerId,String containerName, long unreadDocumentCount) {
		this.containerId = containerId;
		this.containerName = containerName;
		this.unreadDocumentCount = unreadDocumentCount;
	}

	public int getContainerId() {
		return containerId;
	}

	public String getContainerName() {
		return containerName;
	}

	public void setContainerId(int containerId) {
		this.containerId = containerId;
	}

	public void setContainerName(String containerName) {
		this.containerName = containerName;
	}

	public long getUnreadDocumentCount() {
		return unreadDocumentCount;
	}

	public void setUnreadDocumentCount(long unreadDocumentCount) {
		this.unreadDocumentCount = unreadDocumentCount;
	}

	

	
}
