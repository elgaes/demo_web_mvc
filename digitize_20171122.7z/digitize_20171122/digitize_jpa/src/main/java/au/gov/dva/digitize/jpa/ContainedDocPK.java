package au.gov.dva.digitize.jpa;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the CONTAINED_DOC database table.
 * 
 */
@Embeddable
public class ContainedDocPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;
	private int contId;
	private int docId;

	public ContainedDocPK() {
	}

	@Column(name="CONT_ID", insertable=false, updatable=false)
	public int getContId() {
		return this.contId;
	}
	public void setContId(int contId) {
		this.contId = contId;
	}

	@Column(name="DOC_ID", insertable=false, updatable=false)
	public int getDocId() {
		return this.docId;
	}
	public void setDocId(int docId) {
		this.docId = docId;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof ContainedDocPK)) {
			return false;
		}
		ContainedDocPK castOther = (ContainedDocPK)other;
		return 
			(this.contId == castOther.contId)
			&& (this.docId == castOther.docId);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.contId;
		hash = hash * prime + this.docId;
		
		return hash;
	}
}