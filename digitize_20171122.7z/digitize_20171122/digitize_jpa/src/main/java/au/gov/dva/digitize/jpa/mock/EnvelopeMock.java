package au.gov.dva.digitize.jpa.mock;

public class EnvelopeMock {

	private boolean isPendingToBeInTrim;
	private boolean isActioned;
	private boolean isUnread;
	private boolean isExternalRedirected;
	private boolean isInternalRedirected;
	private Integer id;
	private String documentName;
	private String mailBox;
	private Integer envelopeId;
	private byte[] contents;

	
	
	
	public boolean getIsPendingToBeInTrim() {
		return isPendingToBeInTrim;
	}
	public void setPendingToBeInTrim(boolean isPendingToBeInTrim) {
		this.isPendingToBeInTrim = isPendingToBeInTrim;
	}
	public boolean getIsActioned() {
		return isActioned;
	}
	public void setActioned(boolean isActioned) {
		this.isActioned = isActioned;
	}
	public boolean getIsUnread() {
		return isUnread;
	}
	public void setUnread(boolean isUnread) {
		this.isUnread = isUnread;
	}
	public boolean getIsExternalRedirected() {
		return isExternalRedirected;
	}
	public void setExternalRedirected(boolean isExternalRedirected) {
		this.isExternalRedirected = isExternalRedirected;
	}
	public boolean getIsInternalRedirected() {
		return isInternalRedirected;
	}
	public void setInternalRedirected(boolean isInternalRedirected) {
		this.isInternalRedirected = isInternalRedirected;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getDocumentName() {
		return documentName;
	}
	public void setDocumentName(String documentName) {
		this.documentName = documentName;
	}
	public String getMailBox() {
		return mailBox;
	}
	public void setMailBox(String mailBox) {
		this.mailBox = mailBox;
	}
	public Integer getEnvelopeId() {
		return envelopeId;
	}
	public void setEnvelopeId(Integer envelopeId) {
		this.envelopeId = envelopeId;
	}
	
	
	
}
