package au.gov.dva.digitize.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import au.gov.dva.digitize.dao.document.DocumentPaginationRepository;
import au.gov.dva.digitize.dao.document.DocumentRepository;
import au.gov.dva.digitize.jpa.Container;
import au.gov.dva.digitize.service.model.Document;
import au.gov.dva.digitize.service.model.MailProcessingStatus;
import au.gov.dva.digitize.service.model.ReadStatus;
@Service
public class DocumentService {
	
	protected DocumentRepository documentRepository;

	
	
	public DocumentRepository getDocumentRepository() {
		return documentRepository;
	}
	@Autowired 
	public void setDocumentRepository(DocumentRepository documentRepository) {
		this.documentRepository = documentRepository;
	}
	
	protected DocumentPaginationRepository documentPaginationRepository;
	
	
	public DocumentPaginationRepository getDocumentPaginationRepository() {
		return documentPaginationRepository;
	}
	@Autowired
	public void setDocumentPaginationRepository(DocumentPaginationRepository documentPaginationRepository) {
		this.documentPaginationRepository = documentPaginationRepository;
	}
	public List<Document> getDocumentsByEnvelopeId(Integer envelId, Integer docIdToFilter){
		
		List<au.gov.dva.digitize.jpa.Document> documentsByEnvelope =  documentRepository.findByEnvelopeId(envelId.toString());
		List<Document> results = new ArrayList<Document>();
		for (au.gov.dva.digitize.jpa.Document document : documentsByEnvelope) {
			
			if(document.getId()!=docIdToFilter) {
				Document documentVO = createDocumentVO(document);
				List<Container> containers= document.getContainers();
				String mailBoxNames = "";
				for (Container container : containers) {
					mailBoxNames = mailBoxNames + " " +container.getLabel();
				}
				documentVO.setMailBox(mailBoxNames);
				results.add(documentVO);
			}
		}
		return results;
	}
	
	public Document getDocumentById(Integer docId ) {
		
		au.gov.dva.digitize.jpa.Document document = documentRepository.findDocumentById(docId);
		Document documentVO = new Document ();
		if(document!=null) {
			documentVO.setBagId(document.getBagId());
			documentVO.setDocId(document.getId());
			documentVO.setDocumentName(document.getScanName());
			documentVO.setDocumentTitle(document.getTitle());
			boolean readStatus = document.getReadSta().equalsIgnoreCase(ReadStatus.READ.name())?true:false;
			documentVO.setReadStatus(readStatus);
			boolean trimStatus = document.getReadSta().equalsIgnoreCase(MailProcessingStatus.TRIM_PENDING.getCode())?true:false;
			documentVO.setPendingInTrim(trimStatus);
			documentVO.setLoadDate(document.getScanDate());
			documentVO.setFileBlob(document.getFileBlob().getFblob());
		}
		
		return documentVO;
	}
	
	
	public void updateDocumenReadStatusById(Document document, String readStaus) {
		au.gov.dva.digitize.jpa.Document jpaDoc = documentRepository.findDocumentById(document.getDocId());
		jpaDoc.setReadSta(ReadStatus.READ.name());
		documentRepository.save(jpaDoc);
	}

	/**
	 * 
	 * @param lastDocId
	 * @param selectedMailboxId
	 * @param Processingtatus
	 * @return
	 */
	public List<Document> getDocumentsByPage(Integer lastDocId, Integer selectedMailboxId , String Processingtatus, PageRequest pageRequest){
		
		
		List<au.gov.dva.digitize.jpa.Document> documentsByPage = documentPaginationRepository.findDocumentsByPageAndStausAndMailBox(selectedMailboxId,
				lastDocId,Processingtatus,pageRequest);
		
		List <Document> results = new ArrayList<Document>();
		for (au.gov.dva.digitize.jpa.Document document : documentsByPage) {
			Document documentVO = createDocumentVO(document);
			results.add(documentVO);
		}
		return results;
	}
	private Document createDocumentVO(au.gov.dva.digitize.jpa.Document document) {
		Document documentVO = new Document ();
		documentVO.setBagId(document.getBagId());
		documentVO.setDocId(document.getId());
		documentVO.setEnvelopeId(document.getEnvelId());
		documentVO.setDocumentName("MAIL_"+document.getEnvelId()+"_"+document.getId()+"_"+document.getScanId());
		String theL3 = document.getTherL3()!=null?document.getTherL3():"";
		boolean readStatus = document.getReadSta().equalsIgnoreCase(ReadStatus.READ.getCode())?true:false;
		documentVO.setReadStatus(readStatus);
		boolean trimStatus = document.getReadSta().equalsIgnoreCase(MailProcessingStatus.TRIM_PENDING.getCode())?true:false;
		documentVO.setPendingInTrim(trimStatus);
		documentVO.setLoadDate(document.getScanDate());
		documentVO.setDocumentSubject(theL3);
		return documentVO;
	}
}
