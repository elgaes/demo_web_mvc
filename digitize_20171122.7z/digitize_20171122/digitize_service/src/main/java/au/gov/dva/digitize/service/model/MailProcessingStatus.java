package au.gov.dva.digitize.service.model;

public enum MailProcessingStatus 
{
	UNPROCESSED("UNPROC"),
	EXT_REDIRECTED("EXREDIR"),
	INT_REDIRECTED("INREDIR"),
	TRIM_PENDING("PENDING"),
	TRIM_COMPLETE("COMPLET"),
	UNDEFINED("UNDEF");
	
	private String code;
	
	MailProcessingStatus(String statusCode)
	{
		this.code=statusCode;
	}
	public String getCode()
	{
		return code;
	}
	
	public static MailProcessingStatus toEnum(String statusCode)
	{
		for(MailProcessingStatus value: MailProcessingStatus.values())
		{
			if(value.getCode().equals(statusCode))
				return value;
		}
		return null;
	}
}
