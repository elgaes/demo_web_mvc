package au.gov.dva.digitize.batch.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Properties;

import javax.batch.operations.JobOperator;
import javax.batch.runtime.BatchRuntime;
import javax.ejb.EJB;
import javax.inject.Inject;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import au.gov.dva.digitize.batch.BatchJobNames;
import au.gov.dva.digitize.batch.schedule.SchedulingRemote;

/**
 * Servlet implementation class BatchJobManager
 */
@WebServlet(name="Batch Manager", urlPatterns= {"/jobstart"}, loadOnStartup=1)
public class BatchJobManager extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
	
	@EJB(name="JobScheduler")
	private SchedulingRemote jobScheduler;
	
    /**
     * Default constructor. 
     */
    public BatchJobManager() 
    {

    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		System.err.println("Starting Batch Job "+BatchJobNames.LOAD_SCANNED_MAIL_JOB+" Manually");
		Properties params=new Properties();
		jobScheduler.runJob(BatchJobNames.LOAD_SCANNED_MAIL_JOB, params);
		PrintWriter w=response.getWriter();
		w.print("<html><head><title>Job "+BatchJobNames.LOAD_SCANNED_MAIL_JOB+" Run Status</title></head><body><table width=\"100%\"><tr><th width=\"25%\">Params</th><th>Values</th></tr><tr><td>Status</td><td>OK</td></tr></table></body></html>");
	}

}
