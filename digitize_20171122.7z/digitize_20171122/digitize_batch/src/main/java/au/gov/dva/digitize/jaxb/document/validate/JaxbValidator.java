package au.gov.dva.digitize.jaxb.document.validate;

import javax.xml.bind.ValidationEvent;
import javax.xml.bind.ValidationEventHandler;

public class JaxbValidator implements ValidationEventHandler {

	public boolean handleEvent(ValidationEvent event) 
	{

		return false;
	}

}
