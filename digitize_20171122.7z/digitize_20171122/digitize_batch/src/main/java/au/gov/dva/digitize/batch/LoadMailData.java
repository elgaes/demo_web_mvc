package au.gov.dva.digitize.batch;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FilenameFilter;
import java.io.IOException;
import java.net.URL;
import java.nio.channels.FileChannel;
import java.nio.channels.FileLock;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardOpenOption;
import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Properties;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceUnit;
import javax.persistence.Query;
import javax.transaction.Transactional;
import javax.transaction.Transactional.TxType;
import javax.xml.XMLConstants;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.Unmarshaller;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;

import org.apache.log4j.Logger;

import au.gov.dva.digitize.batch.schedule.JobScheduler;
import au.gov.dva.digitize.jaxb.document.v1.MailRoomInterface;
import au.gov.dva.digitize.jaxb.document.v1.ObjectFactory;
import au.gov.dva.digitize.jpa.AuditRec;
import au.gov.dva.digitize.jpa.ContainedDoc;
import au.gov.dva.digitize.jpa.ContainedDocPK;
import au.gov.dva.digitize.jpa.Container;
import au.gov.dva.digitize.jpa.Document;
import au.gov.dva.digitize.jpa.FileBlob;

import javax.annotation.Resource;
import javax.batch.api.AbstractBatchlet;
import javax.batch.api.BatchProperty;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.enterprise.context.Dependent;
import javax.inject.Inject;
@Dependent
@Resource(name="jdbc/digitizeDS",mappedName="jdbc/digitizeDS",shareable=false)
public class LoadMailData  extends AbstractBatchlet 
{
	public static final String CONF_DIR_MAIL_DROP="digitize.dir.mail_drop";
	protected static final Logger log=Logger.getLogger(LoadMailData.class);
	 

   // @Inject
   // @BatchProperty(name = "runAt")
	//protected Date runAt;
    protected static final Properties config=loadConfig();
	protected static final String mailDropDir=getConfig(CONF_DIR_MAIL_DROP,"/mail_drop");
	protected static final String unprocessMailDir=mailDropDir+"/unprocess";
	protected static final String processedMailDir=mailDropDir+"/completed";
	@PersistenceContext(unitName="digitizePU")
	protected EntityManager entityMgr;
	@PersistenceUnit(unitName="digitizePU")
	protected EntityManagerFactory entityMgrFact;
	
	protected boolean stop = false; 
    /**
     * @see AbstractBatchlet#AbstractBatchlet()
     */
    public LoadMailData() 
    {
        super();
/*        try {
        	if(entityMgrFact==null)
        		entityMgrFact=Persistence.createEntityManagerFactory("digitizePU");
        	if(entityMgr==null)
        		entityMgr=entityMgrFact.createEntityManager();
        }catch(Throwable e) {
        	log.error("");
        }*/
        
    }
    protected static String getConfig(String key, String defaultVal)
    {
    	String val=config.getProperty(key);
    	return val!=null? val: defaultVal;
    }
    protected static Properties loadConfig()
    {
    	Properties config=new Properties();
    	try {
    		config.load(LoadMailData.class.getResourceAsStream("/config.properties"));
    	}catch(Throwable e) {
    		
    	}
    	return config;
    }
	/**
     * @see AbstractBatchlet#process()
     */
    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public String process() 
    {
    	
    	Path mailDropFolder=new File(mailDropDir).toPath();    	
    	Path unprocessFolder=new File(unprocessMailDir).toPath();
    	Path processedFolder=new File(processedMailDir).toPath();
    	if(!Files.exists(mailDropFolder))
    	{
    		log.error("ERROR: Mail drop directory "+mailDropFolder+ " not exist");
    		return "ERROR: Mail drop directory "+mailDropFolder+ " not exist";
    	}

    	Unmarshaller unmarshaller=null ;
    	try {
        	Files.createDirectories(unprocessFolder);
        	Files.createDirectories(processedFolder);

    		SchemaFactory sf = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
    		URL xsdUrl=this.getClass().getResource("/META-INF/xsd/MailRoomInterface.xsd");
    		Schema schema = sf.newSchema(xsdUrl);      
            JAXBContext jc = JAXBContext.newInstance(ObjectFactory.class);         
            unmarshaller = jc.createUnmarshaller();        
            unmarshaller.setSchema(schema);        
            //unmarshaller.setEventHandler(new MyValidationEventHandler());         		
    	}catch(Throwable e) {
    		log.error("ERROR: "+e.getMessage(),e);
    		return "ERROR: "+e.toString();
    	}

    	File fileList[]=mailDropFolder.toFile().listFiles(new FilenameFilter() {
			public boolean accept(File dir, String name) 
			{
				return name.toLowerCase().trim().endsWith(".xml");
			}});
    	
    	File pdfFile=null;
    	
    	for(File xmlFile: fileList)
    	{
    		if(stop)
    			break;
    		String filename=xmlFile.getName();

			pdfFile=new File(xmlFile.getParentFile(),filename.substring(0, filename.lastIndexOf('.'))+".pdf");
			if(pdfFile.exists())
			{	
				FileChannel ch1=null;
				FileChannel ch2=null;
				FileLock lock1=null;
				FileLock lock2=null;				
    			try {
    				//Obtain exclusive lock on both pdf and xml file pair
    				ch1=FileChannel.open(xmlFile.toPath(),StandardOpenOption.WRITE);
    				ch2=FileChannel.open(pdfFile.toPath(),StandardOpenOption.WRITE);
    				lock1=ch1.tryLock();
    				lock2=ch2.tryLock();
    				if((lock1!=null)&&(lock2!=null))
    				{
    					lock1.release();
    					lock2.release();
    					//Only process files if exclusive file lock obtained otherwise leave this file pair for next scheduled run	due 
    					//to external process might be accessing and locked the files 
	    				processXmlMetaFile(xmlFile, pdfFile,unmarshaller);    	    				
	    				//successfull processed mail file pair will be moved to Completed folder
	    				Files.move(xmlFile.toPath(),processedFolder.resolve(xmlFile.getName()),StandardCopyOption.ATOMIC_MOVE);
	    				Files.move(pdfFile.toPath(),processedFolder.resolve(pdfFile.getName()),StandardCopyOption.ATOMIC_MOVE);
    				}
    				if((lock1!=null)&&(lock1.isShared()))
    					lock1.release();
    				if((lock2!=null)&&(lock2.isShared()))
    					lock2.release();
    			}catch(Throwable e) {
    				log.error("ERROR: "+e.getMessage(),e);
    				e.printStackTrace(System.out);
    			}finally {

    			}
			}else {
				//unpair mail files will be moved to unprocess folder
    			try {
    				Files.move(xmlFile.toPath(),unprocessFolder.resolve(xmlFile.getName()),StandardCopyOption.ATOMIC_MOVE);
    				//moveFile(xmlFile,new File(unprocessFolder, xmlFile.getName()));
    			}catch(Throwable e) {
    				log.error("ERROR: "+e.getMessage(),e);
    				e.printStackTrace(System.out);    				
    			}
			}

    	}
		return stop?"INTERUPTED":"COMPLETED";
    }
    
    protected List<Container> getMailBox(String mailBoxId)
    {
    	Query sql=this.entityMgr.createNamedQuery("Container.findByMailBox", Container.class);
    	sql.setParameter("mailBoxId", mailBoxId);    	
    	return sql.getResultList();
    }
    
    @Transactional(TxType.REQUIRES_NEW)    
    protected void processXmlMetaFile(File xmlFile, File scanFile, Unmarshaller jaxbUnmarshaller) throws Exception
    {   		
    		log.debug("Proccessing: "+xmlFile.getName()+"("+xmlFile.exists()+") - "+scanFile.getName()+" ("+scanFile.exists()+")");
    		    		
    		MailRoomInterface mailMeta=(MailRoomInterface) jaxbUnmarshaller.unmarshal(xmlFile);
	    	Document document=toEntityDocument(mailMeta);
	    	entityMgr.persist(document);
	    	entityMgr.flush();
	    	Document ref=entityMgr.getReference(Document.class, document.getId());
	    	Container container= getMailBox(mailMeta.getMailboxId()).get(0);
	    	if(container==null)	    		
	    	{		    			
	    			container=new Container();
	    			container.setExtRef(mailMeta.getMailboxId());
	    			container.setLabel(mailMeta.getMailboxName());
	    			container.setType("MAIL_ROOM");	    			 	    			
	    			entityMgr.persist(container);
	    	}
	    	container.getDocuments().add(ref);
	    	
	    	ContainedDoc cd=new ContainedDoc();
	    	ContainedDocPK pk=new ContainedDocPK();
	    	cd.setId(pk);
	    	pk.setContId(container.getId());
	    	pk.setDocId(document.getId());
    		entityMgr.persist(cd);	    	    	
	    	
	    	entityMgr.flush();
	    	
	    	FileBlob pdf=new FileBlob();	    		    		    	
	    	pdf.setDocId(document.getId());
	    	pdf.setFblob(toBlobBytes(scanFile));
	    	pdf.setFtype("PDF");
	    	pdf.setDocument(entityMgr.getReference(Document.class, document.getId()));	    	
	    	entityMgr.persist(pdf);
	    	entityMgr.flush();
	    	
	    	AuditRec audit=new AuditRec();
	    	audit.setCrtDate(new Timestamp(System.currentTimeMillis()));
	    	audit.setAction("CREATE");
	    	audit.setObjId(document.getId());
	    	entityMgr.persist(audit);	    	
	    	entityMgr.flush();
    }
    
    protected  Document toEntityDocument(MailRoomInterface mailMeta)
    {
    	Document doc = new Document();
    	doc.setBagId(mailMeta.getBagID());
    	doc.setEnvelId(mailMeta.getEnvelopeID());
    	doc.setArchBox(mailMeta.getArchiveBoxNumber());
    	doc.setTrimRec(mailMeta.getTrimRecordNumber());
    	doc.setTrimContainerName(mailMeta.getTrimContainerName());
    	doc.setTrimContainerNum(mailMeta.getTrimContainerNumber());
    	doc.setScanName(mailMeta.getFileName());
    	doc.setTitle(mailMeta.getFileName());
    	doc.setScanDate(toDate(mailMeta.getDateTimeScanned()));
    	doc.setScanId(mailMeta.getMailDocumentID());
    	doc.setReadSta("UNREAD");
    	doc.setProcSta("UNPROC"); 
    	doc.setTherL1(mailMeta.getThesaurusL1());
    	doc.setTherL2(mailMeta.getThesaurusL2());
    	doc.setTherL3(mailMeta.getThesaurusL3());    	    	    	
    	return doc;
    }
    protected byte[] toBlobBytes(File pdf) throws IOException
    {
    	BufferedInputStream inStream=new BufferedInputStream(new FileInputStream(pdf));
    	ByteArrayOutputStream outStream=new ByteArrayOutputStream();
    	int n=-1;
    	byte[] xBuff=new byte[1024*25];
    	while((n=inStream.read(xBuff, 0, xBuff.length)) > 0)
    		outStream.write(xBuff, 0, n);
    	outStream.flush();
    	byte[] buff= outStream.toByteArray();
    	inStream.close();
    	outStream.close();
    	return buff;
    }
    protected Date toDate(XMLGregorianCalendar xmlDate)
    {

    	Calendar cal=Calendar.getInstance();
    	cal.set(xmlDate.getYear(), xmlDate.getMonth(), xmlDate.getDay());
    	return cal.getTime() ; 
    
    }
    
	//@Override
	public void stop() throws Exception 
	{
		stop=true;
	}


	public static void main(String[] args)
	{
		LoadMailData loader=new LoadMailData ();
		loader.process();
	}

	public EntityManager getEntityMgr() {
		return entityMgr;
	}

	public void setEntityMgr(EntityManager entityMgr) {
		this.entityMgr = entityMgr;
	}	
}
