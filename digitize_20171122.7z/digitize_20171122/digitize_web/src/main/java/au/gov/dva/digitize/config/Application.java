package au.gov.dva.digitize.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.autoconfigure.jdbc.DataSourceBuilder;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.web.support.SpringBootServletInitializer;
import org.springframework.context.annotation.Bean;
import org.springframework.core.env.Environment;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jndi.JndiTemplate;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;

/**
 * This is Spring Boot main configuration class to wire in a number of required components
 * 		-Derby XA Embbeded Data Source - Provide access to embedded derby database name demo_db stored at root folder of this app
 *  	-Local Entity Manager factory - Produce Spring JPA entity manager factory wrapper which will automatic detect 
 *  									Hibernate JPA provider on classpath and configure Hibernate JPA for the app
 *  	-JPA Transaction Manager - Wire in a Transaction service to provide transaction management for the JPA.
 *  
 *  There are more application configuration setup in the Spring Application.properties directory /src/main/resource/config
 *  Spring will auto pickup configuration from this file and setup the rest of the Spring MVC framework include the Thymeleaf 
 *  web template engine which process web template for this app 
 *  
 *  This class also tell sprinng to enable transaction management infra as well as tell it auto scan app service components 
 *  and JPA entity packages
 *   
 * @author seagle
 *
 */

@EnableTransactionManagement
@SpringBootApplication(
		scanBasePackages = {"au.gov.dva.digitize.mvc.controller",
							"au.gov.dva.digitize.service.test",
							"au.gov.dva.digitize.service",
							"au.gov.dva.digitize.config"})
@EntityScan(basePackages= {"au.gov.dva.digitize.jpa","au.gov.dva.digitize.jpa.test"})
@EnableJpaRepositories(basePackages= {"au.gov.dva.digitize.dao","au.gov.dva.digitize.dao.test"})
public class Application extends SpringBootServletInitializer
{
	@Autowired
    private Environment env;

	public static void main(String[] args)
	{
		//Set directory for derby to create its database, default to working directory
		System.setProperty("derby.system.home",System.getProperty("user.dir"));
		SpringApplication.run(Application.class, args);
	}

	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
		System.setProperty("derby.system.home",System.getProperty("user.dir"));
		return application.sources(Application.class);
	}

	@Bean
	@ConfigurationProperties("digitize.datasource")
	public DataSource dataSource(Environment env) throws Throwable
	{		
		if("server".equalsIgnoreCase(env.getProperty("digitize.env")))
		{
			return (DataSource) new JndiTemplate().lookup(env.getProperty("digitize.datasource.jndi"));
		}else {
			//return DataSourceBuilder.create().type((Class<? extends DataSource>) Class.forName("org.apache.derby.jdbc.EmbeddedXADataSource")).build();
			return DataSourceBuilder.create().type((Class<? extends DataSource>) Class.forName(env.getProperty("digitize.datasource.class"))).build();
		}
	}

	@Bean
	public LocalContainerEntityManagerFactoryBean entityManagerFactory(DataSource dataSource, Environment env) 
	{
		LocalContainerEntityManagerFactoryBean entityManagerFactoryBean = new LocalContainerEntityManagerFactoryBean();		
		entityManagerFactoryBean.setDataSource(dataSource);
		entityManagerFactoryBean.setJpaVendorAdapter(new HibernateJpaVendorAdapter());
		entityManagerFactoryBean.setPersistenceXmlLocation("classpath:META-INF/persistence.xml");
		//entityManagerFactoryBean.setPackagesToScan("haibang.demo.jpa");
		return entityManagerFactoryBean;
	}
	
	@Bean
	public JpaTransactionManager transactionManager(EntityManagerFactory entityManagerFactory) 
	{
		JpaTransactionManager transactionManager = new JpaTransactionManager();
		transactionManager.setEntityManagerFactory(entityManagerFactory);
		return transactionManager;
	}

}
