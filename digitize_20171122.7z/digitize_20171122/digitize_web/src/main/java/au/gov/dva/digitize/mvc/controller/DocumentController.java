package au.gov.dva.digitize.mvc.controller;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.tomcat.util.http.fileupload.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import au.gov.dva.digitize.service.ContainerService;
import au.gov.dva.digitize.service.DocumentService;
import au.gov.dva.digitize.service.model.Document;
import au.gov.dva.digitize.service.model.MailBox;
import au.gov.dva.digitize.service.model.MailProcessingStatus;
import au.gov.dva.digitize.service.model.ReadStatus;

/**
 * 
 * @author znairm
 * 
 *
 * @param <T>
 */
@Controller
@RequestMapping("service/views/document/*")
public class DocumentController<T> extends AbstractController{

	@Autowired
	ContainerService containerService;
	
	@Autowired
	DocumentService documentService;
	
	/**
	 * 
	 * @param mailBoxId
	 * @param httpRequest
	 * @return all documents by mail box Id
	 */
	@ResponseBody
	@RequestMapping(path="getAllDocumentsByMailBoxId", produces="application/json")
	public List<?> getAllDocumentsByMailBoxId(@RequestParam(value="mailBoxId", required=false) Integer mailBoxId,HttpServletRequest httpRequest){
		
		return containerService.getDocumentsByMailBoxId(httpRequest.getUserPrincipal(),mailBoxId);
	}
	
	
	/**
	 * 
	 * @param mailBoxId
	 * @param httpRequest
	 * @return
	 */
	@ResponseBody
	@RequestMapping(path="getAllDocumentsByMailBoxIdAndPage", produces="application/json")
	public List<?> getAllDocumentsByMailBoxIdAndPage(@RequestParam(value="mailBoxId", required=true) Integer mailBoxId,@RequestParam(value="documentId", required=false) Integer lastDocId,HttpServletRequest httpRequest){
		
		return documentService.getDocumentsByPage(lastDocId,mailBoxId, MailProcessingStatus.UNPROCESSED.getCode(), new PageRequest(0, 200));
	}
	
	
	/**
	 * 
	 * @param envelopeId
	 * @param httpRequest
	 * @return
	 */
	@ResponseBody
	@RequestMapping(path="getAllDocumentsByEnvelopeId", produces="application/json")
	public List<?> getAllDocumentsByEnvelopeId(@RequestParam(value="envelopeId", required=false) Integer envelopeId,
			@RequestParam(value="representativeDocId", required=false) Integer representativeDocId ,HttpServletRequest httpRequest){
		
		return documentService.getDocumentsByEnvelopeId(envelopeId,representativeDocId);
	}
	
	/**
	 * Writes the pdf to response
	 * 
	 * @param response
	 * @param documentId
	 * @throws IOException 
	 */
	
	@RequestMapping(value="Document", method=RequestMethod.GET)
	public void getDocumentById(HttpServletResponse response, @RequestParam(value="documentId", required=false) Integer documentId) {
		
			Document document = documentService.getDocumentById(documentId);
			
			if(document!=null) {
				byte [] contents = document.getFileBlob();
				if(contents!=null) {
					ByteArrayInputStream in = new ByteArrayInputStream(contents);
					try {
						IOUtils.copy(in,response.getOutputStream());
					} catch (IOException e) {
						try {
							writeErrorPdf(response);
						} catch (IOException e1) {
							logger.error(e.getMessage());
						}
						logger.error(e.getMessage());
					}
				// Mark the document as read;
				documentService.updateDocumenReadStatusById(document,ReadStatus.READ.name());
				}
			}else {
				try {
					writeErrorPdf(response);
				} catch (IOException e) {
					logger.error(e.getMessage());
				}
			}
	}


	private void writeErrorPdf(HttpServletResponse response) throws IOException{
		logger.info("writeErrorPdf :: Entry");
		File file= new File("src\\test\\resources\\error.pdf");
		InputStream targetStream;
		try {
			targetStream = new FileInputStream(file);
			IOUtils.copy(targetStream, response.getOutputStream());
			response.setContentType("application/pdf");
			response.addHeader("Content-disposition", "inline");
			response.flushBuffer();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		logger.info("writeErrorPdf :: Exit");
	}
	
	/**
	 * 
	 * @param userId
	 * @param httpRequest
	 * @return
	 */
	@ResponseBody
	@RequestMapping(path="listAllMailBoxes", produces="application/json")
	public Object getMailboxesAndUnProcessedDocumentCountByUser(HttpServletRequest httpRequest){
		List<MailBox> accessibleMailBoxes = containerService.getUserAccessibleContainersWithCount(httpRequest.getUserPrincipal());
		return accessibleMailBoxes;
	}
	
}
