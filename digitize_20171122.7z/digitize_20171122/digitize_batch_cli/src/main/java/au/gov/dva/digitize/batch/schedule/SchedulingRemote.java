package au.gov.dva.digitize.batch.schedule;

import java.util.Properties;

import javax.ejb.ScheduleExpression;
import javax.ejb.Timer;

public interface SchedulingRemote 
{
	long runJob(String jobName, Properties params); 
	Timer runJobAt(String jobName, Properties params, ScheduleExpression schedule);
}
