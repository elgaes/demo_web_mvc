package au.gov.dva.digitize.batch;

public interface BatchJobNames 
{
	String LOAD_SCANNED_MAIL_JOB="LoadMailData";
}
