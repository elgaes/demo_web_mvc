package au.gov.dva.digitize.batch.schedule;


public interface SchedulingLocal {

}
