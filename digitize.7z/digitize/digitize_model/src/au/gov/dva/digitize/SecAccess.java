/**
 */
package au.gov.dva.digitize;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Sec Access</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link au.gov.dva.digitize.SecAccess#getObjectId <em>Object Id</em>}</li>
 *   <li>{@link au.gov.dva.digitize.SecAccess#getObjectType <em>Object Type</em>}</li>
 *   <li>{@link au.gov.dva.digitize.SecAccess#getPermissionId <em>Permission Id</em>}</li>
 *   <li>{@link au.gov.dva.digitize.SecAccess#getSubjectId <em>Subject Id</em>}</li>
 * </ul>
 *
 * @see au.gov.dva.digitize.meta.DigitizePackage#getSecAccess()
 * @model
 * @generated
 */
public interface SecAccess extends EObject {
	/**
	 * Returns the value of the '<em><b>Object Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Object Id</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Object Id</em>' attribute.
	 * @see #setObjectId(int)
	 * @see au.gov.dva.digitize.meta.DigitizePackage#getSecAccess_ObjectId()
	 * @model unique="false" required="true" ordered="false"
	 * @generated
	 */
	int getObjectId();

	/**
	 * Sets the value of the '{@link au.gov.dva.digitize.SecAccess#getObjectId <em>Object Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Object Id</em>' attribute.
	 * @see #getObjectId()
	 * @generated
	 */
	void setObjectId(int value);

	/**
	 * Returns the value of the '<em><b>Object Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Object Type</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Object Type</em>' attribute.
	 * @see #setObjectType(String)
	 * @see au.gov.dva.digitize.meta.DigitizePackage#getSecAccess_ObjectType()
	 * @model unique="false" required="true" ordered="false"
	 * @generated
	 */
	String getObjectType();

	/**
	 * Sets the value of the '{@link au.gov.dva.digitize.SecAccess#getObjectType <em>Object Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Object Type</em>' attribute.
	 * @see #getObjectType()
	 * @generated
	 */
	void setObjectType(String value);

	/**
	 * Returns the value of the '<em><b>Permission Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Permission Id</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Permission Id</em>' attribute.
	 * @see #setPermissionId(int)
	 * @see au.gov.dva.digitize.meta.DigitizePackage#getSecAccess_PermissionId()
	 * @model unique="false" required="true" ordered="false"
	 * @generated
	 */
	int getPermissionId();

	/**
	 * Sets the value of the '{@link au.gov.dva.digitize.SecAccess#getPermissionId <em>Permission Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Permission Id</em>' attribute.
	 * @see #getPermissionId()
	 * @generated
	 */
	void setPermissionId(int value);

	/**
	 * Returns the value of the '<em><b>Subject Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Subject Id</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Subject Id</em>' attribute.
	 * @see #setSubjectId(String)
	 * @see au.gov.dva.digitize.meta.DigitizePackage#getSecAccess_SubjectId()
	 * @model unique="false" required="true" ordered="false"
	 * @generated
	 */
	String getSubjectId();

	/**
	 * Sets the value of the '{@link au.gov.dva.digitize.SecAccess#getSubjectId <em>Subject Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Subject Id</em>' attribute.
	 * @see #getSubjectId()
	 * @generated
	 */
	void setSubjectId(String value);

} // SecAccess
