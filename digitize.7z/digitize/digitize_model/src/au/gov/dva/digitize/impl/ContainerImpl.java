/**
 */
package au.gov.dva.digitize.impl;

import au.gov.dva.digitize.ContainedDoc;
import au.gov.dva.digitize.SecAccess;

import au.gov.dva.digitize.meta.DigitizePackage;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.InternalEObject;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectResolvingEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Container</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link au.gov.dva.digitize.impl.ContainerImpl#getId <em>Id</em>}</li>
 *   <li>{@link au.gov.dva.digitize.impl.ContainerImpl#getParentId <em>Parent Id</em>}</li>
 *   <li>{@link au.gov.dva.digitize.impl.ContainerImpl#getType <em>Type</em>}</li>
 *   <li>{@link au.gov.dva.digitize.impl.ContainerImpl#getLabel <em>Label</em>}</li>
 *   <li>{@link au.gov.dva.digitize.impl.ContainerImpl#getExtRef <em>Ext Ref</em>}</li>
 *   <li>{@link au.gov.dva.digitize.impl.ContainerImpl#getDocuments <em>Documents</em>}</li>
 *   <li>{@link au.gov.dva.digitize.impl.ContainerImpl#getACL <em>ACL</em>}</li>
 *   <li>{@link au.gov.dva.digitize.impl.ContainerImpl#getParentContainer <em>Parent Container</em>}</li>
 * </ul>
 *
 * @generated
 */
public class ContainerImpl extends MinimalEObjectImpl.Container implements au.gov.dva.digitize.Container {
	/**
	 * The default value of the '{@link #getId() <em>Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getId()
	 * @generated
	 * @ordered
	 */
	protected static final int ID_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getId() <em>Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getId()
	 * @generated
	 * @ordered
	 */
	protected int id = ID_EDEFAULT;

	/**
	 * This is true if the Id attribute has been set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	protected boolean idESet;

	/**
	 * The default value of the '{@link #getParentId() <em>Parent Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getParentId()
	 * @generated
	 * @ordered
	 */
	protected static final int PARENT_ID_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getParentId() <em>Parent Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getParentId()
	 * @generated
	 * @ordered
	 */
	protected int parentId = PARENT_ID_EDEFAULT;

	/**
	 * The default value of the '{@link #getType() <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getType()
	 * @generated
	 * @ordered
	 */
	protected static final String TYPE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getType() <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getType()
	 * @generated
	 * @ordered
	 */
	protected String type = TYPE_EDEFAULT;

	/**
	 * The default value of the '{@link #getLabel() <em>Label</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLabel()
	 * @generated
	 * @ordered
	 */
	protected static final String LABEL_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getLabel() <em>Label</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLabel()
	 * @generated
	 * @ordered
	 */
	protected String label = LABEL_EDEFAULT;

	/**
	 * The default value of the '{@link #getExtRef() <em>Ext Ref</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getExtRef()
	 * @generated
	 * @ordered
	 */
	protected static final String EXT_REF_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getExtRef() <em>Ext Ref</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getExtRef()
	 * @generated
	 * @ordered
	 */
	protected String extRef = EXT_REF_EDEFAULT;

	/**
	 * The cached value of the '{@link #getDocuments() <em>Documents</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDocuments()
	 * @generated
	 * @ordered
	 */
	protected EList documents;

	/**
	 * The cached value of the '{@link #getACL() <em>ACL</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getACL()
	 * @generated
	 * @ordered
	 */
	protected EList acl;

	/**
	 * The cached value of the '{@link #getParentContainer() <em>Parent Container</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getParentContainer()
	 * @generated
	 * @ordered
	 */
	protected au.gov.dva.digitize.Container parentContainer;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ContainerImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return DigitizePackage.Literals.CONTAINER;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getId() {
		return id;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isSetId() {
		return idESet;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getParentId() {
		return parentId;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setParentId(int newParentId) {
		int oldParentId = parentId;
		parentId = newParentId;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, DigitizePackage.CONTAINER__PARENT_ID, oldParentId, parentId));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getType() {
		return type;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setType(String newType) {
		String oldType = type;
		type = newType;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, DigitizePackage.CONTAINER__TYPE, oldType, type));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getLabel() {
		return label;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setLabel(String newLabel) {
		String oldLabel = label;
		label = newLabel;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, DigitizePackage.CONTAINER__LABEL, oldLabel, label));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getExtRef() {
		return extRef;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setExtRef(String newExtRef) {
		String oldExtRef = extRef;
		extRef = newExtRef;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, DigitizePackage.CONTAINER__EXT_REF, oldExtRef, extRef));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getDocuments() {
		if (documents == null) {
			documents = new EObjectResolvingEList(ContainedDoc.class, this, DigitizePackage.CONTAINER__DOCUMENTS);
		}
		return documents;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getACL() {
		if (acl == null) {
			acl = new EObjectResolvingEList(SecAccess.class, this, DigitizePackage.CONTAINER__ACL);
		}
		return acl;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public au.gov.dva.digitize.Container getParentContainer() {
		if (parentContainer != null && parentContainer.eIsProxy()) {
			InternalEObject oldParentContainer = (InternalEObject)parentContainer;
			parentContainer = (au.gov.dva.digitize.Container)eResolveProxy(oldParentContainer);
			if (parentContainer != oldParentContainer) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, DigitizePackage.CONTAINER__PARENT_CONTAINER, oldParentContainer, parentContainer));
			}
		}
		return parentContainer;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public au.gov.dva.digitize.Container basicGetParentContainer() {
		return parentContainer;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setParentContainer(au.gov.dva.digitize.Container newParentContainer) {
		au.gov.dva.digitize.Container oldParentContainer = parentContainer;
		parentContainer = newParentContainer;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, DigitizePackage.CONTAINER__PARENT_CONTAINER, oldParentContainer, parentContainer));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case DigitizePackage.CONTAINER__ID:
				return new Integer(getId());
			case DigitizePackage.CONTAINER__PARENT_ID:
				return new Integer(getParentId());
			case DigitizePackage.CONTAINER__TYPE:
				return getType();
			case DigitizePackage.CONTAINER__LABEL:
				return getLabel();
			case DigitizePackage.CONTAINER__EXT_REF:
				return getExtRef();
			case DigitizePackage.CONTAINER__DOCUMENTS:
				return getDocuments();
			case DigitizePackage.CONTAINER__ACL:
				return getACL();
			case DigitizePackage.CONTAINER__PARENT_CONTAINER:
				if (resolve) return getParentContainer();
				return basicGetParentContainer();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case DigitizePackage.CONTAINER__PARENT_ID:
				setParentId(((Integer)newValue).intValue());
				return;
			case DigitizePackage.CONTAINER__TYPE:
				setType((String)newValue);
				return;
			case DigitizePackage.CONTAINER__LABEL:
				setLabel((String)newValue);
				return;
			case DigitizePackage.CONTAINER__EXT_REF:
				setExtRef((String)newValue);
				return;
			case DigitizePackage.CONTAINER__DOCUMENTS:
				getDocuments().clear();
				getDocuments().addAll((Collection)newValue);
				return;
			case DigitizePackage.CONTAINER__ACL:
				getACL().clear();
				getACL().addAll((Collection)newValue);
				return;
			case DigitizePackage.CONTAINER__PARENT_CONTAINER:
				setParentContainer((au.gov.dva.digitize.Container)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eUnset(int featureID) {
		switch (featureID) {
			case DigitizePackage.CONTAINER__PARENT_ID:
				setParentId(PARENT_ID_EDEFAULT);
				return;
			case DigitizePackage.CONTAINER__TYPE:
				setType(TYPE_EDEFAULT);
				return;
			case DigitizePackage.CONTAINER__LABEL:
				setLabel(LABEL_EDEFAULT);
				return;
			case DigitizePackage.CONTAINER__EXT_REF:
				setExtRef(EXT_REF_EDEFAULT);
				return;
			case DigitizePackage.CONTAINER__DOCUMENTS:
				getDocuments().clear();
				return;
			case DigitizePackage.CONTAINER__ACL:
				getACL().clear();
				return;
			case DigitizePackage.CONTAINER__PARENT_CONTAINER:
				setParentContainer((au.gov.dva.digitize.Container)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case DigitizePackage.CONTAINER__ID:
				return isSetId();
			case DigitizePackage.CONTAINER__PARENT_ID:
				return parentId != PARENT_ID_EDEFAULT;
			case DigitizePackage.CONTAINER__TYPE:
				return TYPE_EDEFAULT == null ? type != null : !TYPE_EDEFAULT.equals(type);
			case DigitizePackage.CONTAINER__LABEL:
				return LABEL_EDEFAULT == null ? label != null : !LABEL_EDEFAULT.equals(label);
			case DigitizePackage.CONTAINER__EXT_REF:
				return EXT_REF_EDEFAULT == null ? extRef != null : !EXT_REF_EDEFAULT.equals(extRef);
			case DigitizePackage.CONTAINER__DOCUMENTS:
				return documents != null && !documents.isEmpty();
			case DigitizePackage.CONTAINER__ACL:
				return acl != null && !acl.isEmpty();
			case DigitizePackage.CONTAINER__PARENT_CONTAINER:
				return parentContainer != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (id: ");
		if (idESet) result.append(id); else result.append("<unset>");
		result.append(", parentId: ");
		result.append(parentId);
		result.append(", type: ");
		result.append(type);
		result.append(", label: ");
		result.append(label);
		result.append(", extRef: ");
		result.append(extRef);
		result.append(')');
		return result.toString();
	}

} //ContainerImpl
