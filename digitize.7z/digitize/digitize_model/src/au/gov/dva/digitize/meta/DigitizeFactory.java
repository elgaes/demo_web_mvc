/**
 */
package au.gov.dva.digitize.meta;

import au.gov.dva.digitize.AuditRec;
import au.gov.dva.digitize.ContainedDoc;
import au.gov.dva.digitize.Container;
import au.gov.dva.digitize.Document;
import au.gov.dva.digitize.FileBlob;
import au.gov.dva.digitize.SecAccess;
import au.gov.dva.digitize.SecPermission;
import au.gov.dva.digitize.SecSubject;

import org.eclipse.emf.ecore.EFactory;

/**
 * <!-- begin-user-doc -->
 * The <b>Factory</b> for the model.
 * It provides a create method for each non-abstract class of the model.
 * <!-- end-user-doc -->
 * @see au.gov.dva.digitize.meta.DigitizePackage
 * @generated
 */
public interface DigitizeFactory extends EFactory {
	/**
	 * The singleton instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	DigitizeFactory eINSTANCE = au.gov.dva.digitize.impl.DigitizeFactoryImpl.init();

	/**
	 * Returns a new object of class '<em>Document</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Document</em>'.
	 * @generated
	 */
	Document createDocument();

	/**
	 * Returns a new object of class '<em>Container</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Container</em>'.
	 * @generated
	 */
	Container createContainer();

	/**
	 * Returns a new object of class '<em>Contained Doc</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Contained Doc</em>'.
	 * @generated
	 */
	ContainedDoc createContainedDoc();

	/**
	 * Returns a new object of class '<em>File Blob</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>File Blob</em>'.
	 * @generated
	 */
	FileBlob createFileBlob();

	/**
	 * Returns a new object of class '<em>Audit Rec</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Audit Rec</em>'.
	 * @generated
	 */
	AuditRec createAuditRec();

	/**
	 * Returns a new object of class '<em>Sec Access</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Sec Access</em>'.
	 * @generated
	 */
	SecAccess createSecAccess();

	/**
	 * Returns a new object of class '<em>Sec Subject</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Sec Subject</em>'.
	 * @generated
	 */
	SecSubject createSecSubject();

	/**
	 * Returns a new object of class '<em>Sec Permission</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Sec Permission</em>'.
	 * @generated
	 */
	SecPermission createSecPermission();

	/**
	 * Returns the package supported by this factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the package supported by this factory.
	 * @generated
	 */
	DigitizePackage getDigitizePackage();

} //DigitizeFactory
