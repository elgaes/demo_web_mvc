/**
 */
package au.gov.dva.digitize;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Sec Subject</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link au.gov.dva.digitize.SecSubject#getId <em>Id</em>}</li>
 *   <li>{@link au.gov.dva.digitize.SecSubject#getLabel <em>Label</em>}</li>
 *   <li>{@link au.gov.dva.digitize.SecSubject#getExternalName <em>External Name</em>}</li>
 *   <li>{@link au.gov.dva.digitize.SecSubject#getExternalId <em>External Id</em>}</li>
 *   <li>{@link au.gov.dva.digitize.SecSubject#getACL <em>ACL</em>}</li>
 * </ul>
 *
 * @see au.gov.dva.digitize.meta.DigitizePackage#getSecSubject()
 * @model
 * @generated
 */
public interface SecSubject extends EObject {
	/**
	 * Returns the value of the '<em><b>Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Id</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Id</em>' attribute.
	 * @see #isSetId()
	 * @see au.gov.dva.digitize.meta.DigitizePackage#getSecSubject_Id()
	 * @model unsettable="true" id="true" required="true" changeable="false" ordered="false"
	 * @generated
	 */
	int getId();

	/**
	 * Returns whether the value of the '{@link au.gov.dva.digitize.SecSubject#getId <em>Id</em>}' attribute is set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return whether the value of the '<em>Id</em>' attribute is set.
	 * @see #getId()
	 * @generated
	 */
	boolean isSetId();

	/**
	 * Returns the value of the '<em><b>Label</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Label</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Label</em>' attribute.
	 * @see #setLabel(String)
	 * @see au.gov.dva.digitize.meta.DigitizePackage#getSecSubject_Label()
	 * @model required="true"
	 * @generated
	 */
	String getLabel();

	/**
	 * Sets the value of the '{@link au.gov.dva.digitize.SecSubject#getLabel <em>Label</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Label</em>' attribute.
	 * @see #getLabel()
	 * @generated
	 */
	void setLabel(String value);

	/**
	 * Returns the value of the '<em><b>External Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>External Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>External Name</em>' attribute.
	 * @see #setExternalName(String)
	 * @see au.gov.dva.digitize.meta.DigitizePackage#getSecSubject_ExternalName()
	 * @model required="true"
	 * @generated
	 */
	String getExternalName();

	/**
	 * Sets the value of the '{@link au.gov.dva.digitize.SecSubject#getExternalName <em>External Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>External Name</em>' attribute.
	 * @see #getExternalName()
	 * @generated
	 */
	void setExternalName(String value);

	/**
	 * Returns the value of the '<em><b>External Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>External Id</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>External Id</em>' attribute.
	 * @see #setExternalId(String)
	 * @see au.gov.dva.digitize.meta.DigitizePackage#getSecSubject_ExternalId()
	 * @model required="true"
	 * @generated
	 */
	String getExternalId();

	/**
	 * Sets the value of the '{@link au.gov.dva.digitize.SecSubject#getExternalId <em>External Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>External Id</em>' attribute.
	 * @see #getExternalId()
	 * @generated
	 */
	void setExternalId(String value);

	/**
	 * Returns the value of the '<em><b>ACL</b></em>' reference list.
	 * The list contents are of type {@link au.gov.dva.digitize.SecAccess}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>ACL</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>ACL</em>' reference list.
	 * @see au.gov.dva.digitize.meta.DigitizePackage#getSecSubject_ACL()
	 * @model type="au.gov.dva.digitize.SecAccess" keys="subjectId"
	 * @generated
	 */
	EList getACL();

} // SecSubject
