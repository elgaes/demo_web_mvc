/**
 */
package au.gov.dva.digitize.impl;

import au.gov.dva.digitize.AuditRec;
import au.gov.dva.digitize.ContainedDoc;
import au.gov.dva.digitize.Document;
import au.gov.dva.digitize.FileBlob;
import au.gov.dva.digitize.SecAccess;
import au.gov.dva.digitize.SecPermission;
import au.gov.dva.digitize.SecSubject;

import au.gov.dva.digitize.meta.DigitizeFactory;
import au.gov.dva.digitize.meta.DigitizePackage;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

import org.eclipse.emf.ecore.impl.EPackageImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Package</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class DigitizePackageImpl extends EPackageImpl implements DigitizePackage {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass documentEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass containerEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass containedDocEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass fileBlobEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass auditRecEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass secAccessEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass secSubjectEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass secPermissionEClass = null;

	/**
	 * Creates an instance of the model <b>Package</b>, registered with
	 * {@link org.eclipse.emf.ecore.EPackage.Registry EPackage.Registry} by the package
	 * package URI value.
	 * <p>Note: the correct way to create the package is via the static
	 * factory method {@link #init init()}, which also performs
	 * initialization of the package, or returns the registered package,
	 * if one already exists.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.ecore.EPackage.Registry
	 * @see au.gov.dva.digitize.meta.DigitizePackage#eNS_URI
	 * @see #init()
	 * @generated
	 */
	private DigitizePackageImpl() {
		super(eNS_URI, DigitizeFactory.eINSTANCE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static boolean isInited = false;

	/**
	 * Creates, registers, and initializes the <b>Package</b> for this model, and for any others upon which it depends.
	 * 
	 * <p>This method is used to initialize {@link DigitizePackage#eINSTANCE} when that field is accessed.
	 * Clients should not invoke it directly. Instead, they should simply access that field to obtain the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #eNS_URI
	 * @see #createPackageContents()
	 * @see #initializePackageContents()
	 * @generated
	 */
	public static DigitizePackage init() {
		if (isInited) return (DigitizePackage)EPackage.Registry.INSTANCE.getEPackage(DigitizePackage.eNS_URI);

		// Obtain or create and register package
		DigitizePackageImpl theDigitizePackage = (DigitizePackageImpl)(EPackage.Registry.INSTANCE.get(eNS_URI) instanceof DigitizePackageImpl ? EPackage.Registry.INSTANCE.get(eNS_URI) : new DigitizePackageImpl());

		isInited = true;

		// Create package meta-data objects
		theDigitizePackage.createPackageContents();

		// Initialize created meta-data
		theDigitizePackage.initializePackageContents();

		// Mark meta-data to indicate it can't be changed
		theDigitizePackage.freeze();

  
		// Update the registry and return the package
		EPackage.Registry.INSTANCE.put(DigitizePackage.eNS_URI, theDigitizePackage);
		return theDigitizePackage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getDocument() {
		return documentEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDocument_Id() {
		return (EAttribute)documentEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDocument_ProcStatus() {
		return (EAttribute)documentEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDocument_ReadStatus() {
		return (EAttribute)documentEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDocument_Title() {
		return (EAttribute)documentEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDocument_TherL1() {
		return (EAttribute)documentEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDocument_TherL2() {
		return (EAttribute)documentEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDocument_TherL3() {
		return (EAttribute)documentEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDocument_ExtRef() {
		return (EAttribute)documentEClass.getEStructuralFeatures().get(7);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDocument_BagId() {
		return (EAttribute)documentEClass.getEStructuralFeatures().get(8);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDocument_EnvelopeId() {
		return (EAttribute)documentEClass.getEStructuralFeatures().get(9);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDocument_ScanId() {
		return (EAttribute)documentEClass.getEStructuralFeatures().get(10);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDocument_ScanName() {
		return (EAttribute)documentEClass.getEStructuralFeatures().get(11);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDocument_ScanDate() {
		return (EAttribute)documentEClass.getEStructuralFeatures().get(12);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDocument_ArchiveBoxNum() {
		return (EAttribute)documentEClass.getEStructuralFeatures().get(13);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDocument_AuditRecords() {
		return (EReference)documentEClass.getEStructuralFeatures().get(14);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDocument_Fileblob() {
		return (EReference)documentEClass.getEStructuralFeatures().get(15);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDocument_Container() {
		return (EReference)documentEClass.getEStructuralFeatures().get(16);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDocument_ACL() {
		return (EReference)documentEClass.getEStructuralFeatures().get(17);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getContainer() {
		return containerEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getContainer_Id() {
		return (EAttribute)containerEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getContainer_ParentId() {
		return (EAttribute)containerEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getContainer_Type() {
		return (EAttribute)containerEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getContainer_Label() {
		return (EAttribute)containerEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getContainer_ExtRef() {
		return (EAttribute)containerEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getContainer_Documents() {
		return (EReference)containerEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getContainer_ACL() {
		return (EReference)containerEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getContainer_ParentContainer() {
		return (EReference)containerEClass.getEStructuralFeatures().get(7);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getContainedDoc() {
		return containedDocEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getContainedDoc_ContainerId() {
		return (EAttribute)containedDocEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getContainedDoc_DocId() {
		return (EAttribute)containedDocEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getFileBlob() {
		return fileBlobEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getFileBlob_DocId() {
		return (EAttribute)fileBlobEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getFileBlob_Blob() {
		return (EAttribute)fileBlobEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getFileBlob_Type() {
		return (EAttribute)fileBlobEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getAuditRec() {
		return auditRecEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAuditRec_Id() {
		return (EAttribute)auditRecEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAuditRec_Type() {
		return (EAttribute)auditRecEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAuditRec_ObjectId() {
		return (EAttribute)auditRecEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAuditRec_ObjectType() {
		return (EAttribute)auditRecEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAuditRec_CreateDate() {
		return (EAttribute)auditRecEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAuditRec_CreateBy() {
		return (EAttribute)auditRecEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAuditRec_Action() {
		return (EAttribute)auditRecEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAuditRec_Details() {
		return (EAttribute)auditRecEClass.getEStructuralFeatures().get(7);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getSecAccess() {
		return secAccessEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSecAccess_ObjectId() {
		return (EAttribute)secAccessEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSecAccess_ObjectType() {
		return (EAttribute)secAccessEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSecAccess_PermissionId() {
		return (EAttribute)secAccessEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSecAccess_SubjectId() {
		return (EAttribute)secAccessEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getSecSubject() {
		return secSubjectEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSecSubject_Id() {
		return (EAttribute)secSubjectEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSecSubject_Label() {
		return (EAttribute)secSubjectEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSecSubject_ExternalName() {
		return (EAttribute)secSubjectEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSecSubject_ExternalId() {
		return (EAttribute)secSubjectEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getSecSubject_ACL() {
		return (EReference)secSubjectEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getSecPermission() {
		return secPermissionEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSecPermission_Id() {
		return (EAttribute)secPermissionEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSecPermission_Label() {
		return (EAttribute)secPermissionEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSecPermission_ObjectType() {
		return (EAttribute)secPermissionEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getSecPermission_ACL() {
		return (EReference)secPermissionEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DigitizeFactory getDigitizeFactory() {
		return (DigitizeFactory)getEFactoryInstance();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isCreated = false;

	/**
	 * Creates the meta-model objects for the package.  This method is
	 * guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void createPackageContents() {
		if (isCreated) return;
		isCreated = true;

		// Create classes and their features
		documentEClass = createEClass(DOCUMENT);
		createEAttribute(documentEClass, DOCUMENT__ID);
		createEAttribute(documentEClass, DOCUMENT__PROC_STATUS);
		createEAttribute(documentEClass, DOCUMENT__READ_STATUS);
		createEAttribute(documentEClass, DOCUMENT__TITLE);
		createEAttribute(documentEClass, DOCUMENT__THER_L1);
		createEAttribute(documentEClass, DOCUMENT__THER_L2);
		createEAttribute(documentEClass, DOCUMENT__THER_L3);
		createEAttribute(documentEClass, DOCUMENT__EXT_REF);
		createEAttribute(documentEClass, DOCUMENT__BAG_ID);
		createEAttribute(documentEClass, DOCUMENT__ENVELOPE_ID);
		createEAttribute(documentEClass, DOCUMENT__SCAN_ID);
		createEAttribute(documentEClass, DOCUMENT__SCAN_NAME);
		createEAttribute(documentEClass, DOCUMENT__SCAN_DATE);
		createEAttribute(documentEClass, DOCUMENT__ARCHIVE_BOX_NUM);
		createEReference(documentEClass, DOCUMENT__AUDIT_RECORDS);
		createEReference(documentEClass, DOCUMENT__FILEBLOB);
		createEReference(documentEClass, DOCUMENT__CONTAINER);
		createEReference(documentEClass, DOCUMENT__ACL);

		containerEClass = createEClass(CONTAINER);
		createEAttribute(containerEClass, CONTAINER__ID);
		createEAttribute(containerEClass, CONTAINER__PARENT_ID);
		createEAttribute(containerEClass, CONTAINER__TYPE);
		createEAttribute(containerEClass, CONTAINER__LABEL);
		createEAttribute(containerEClass, CONTAINER__EXT_REF);
		createEReference(containerEClass, CONTAINER__DOCUMENTS);
		createEReference(containerEClass, CONTAINER__ACL);
		createEReference(containerEClass, CONTAINER__PARENT_CONTAINER);

		containedDocEClass = createEClass(CONTAINED_DOC);
		createEAttribute(containedDocEClass, CONTAINED_DOC__CONTAINER_ID);
		createEAttribute(containedDocEClass, CONTAINED_DOC__DOC_ID);

		fileBlobEClass = createEClass(FILE_BLOB);
		createEAttribute(fileBlobEClass, FILE_BLOB__DOC_ID);
		createEAttribute(fileBlobEClass, FILE_BLOB__BLOB);
		createEAttribute(fileBlobEClass, FILE_BLOB__TYPE);

		auditRecEClass = createEClass(AUDIT_REC);
		createEAttribute(auditRecEClass, AUDIT_REC__ID);
		createEAttribute(auditRecEClass, AUDIT_REC__TYPE);
		createEAttribute(auditRecEClass, AUDIT_REC__OBJECT_ID);
		createEAttribute(auditRecEClass, AUDIT_REC__OBJECT_TYPE);
		createEAttribute(auditRecEClass, AUDIT_REC__CREATE_DATE);
		createEAttribute(auditRecEClass, AUDIT_REC__CREATE_BY);
		createEAttribute(auditRecEClass, AUDIT_REC__ACTION);
		createEAttribute(auditRecEClass, AUDIT_REC__DETAILS);

		secAccessEClass = createEClass(SEC_ACCESS);
		createEAttribute(secAccessEClass, SEC_ACCESS__OBJECT_ID);
		createEAttribute(secAccessEClass, SEC_ACCESS__OBJECT_TYPE);
		createEAttribute(secAccessEClass, SEC_ACCESS__PERMISSION_ID);
		createEAttribute(secAccessEClass, SEC_ACCESS__SUBJECT_ID);

		secSubjectEClass = createEClass(SEC_SUBJECT);
		createEAttribute(secSubjectEClass, SEC_SUBJECT__ID);
		createEAttribute(secSubjectEClass, SEC_SUBJECT__LABEL);
		createEAttribute(secSubjectEClass, SEC_SUBJECT__EXTERNAL_NAME);
		createEAttribute(secSubjectEClass, SEC_SUBJECT__EXTERNAL_ID);
		createEReference(secSubjectEClass, SEC_SUBJECT__ACL);

		secPermissionEClass = createEClass(SEC_PERMISSION);
		createEAttribute(secPermissionEClass, SEC_PERMISSION__ID);
		createEAttribute(secPermissionEClass, SEC_PERMISSION__LABEL);
		createEAttribute(secPermissionEClass, SEC_PERMISSION__OBJECT_TYPE);
		createEReference(secPermissionEClass, SEC_PERMISSION__ACL);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isInitialized = false;

	/**
	 * Complete the initialization of the package and its meta-model.  This
	 * method is guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void initializePackageContents() {
		if (isInitialized) return;
		isInitialized = true;

		// Initialize package
		setName(eNAME);
		setNsPrefix(eNS_PREFIX);
		setNsURI(eNS_URI);

		// Add supertypes to classes

		// Initialize classes and features; add operations and parameters
		initEClass(documentEClass, Document.class, "Document", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getDocument_Id(), ecorePackage.getEInt(), "id", null, 1, 1, Document.class, !IS_TRANSIENT, !IS_VOLATILE, !IS_CHANGEABLE, IS_UNSETTABLE, IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEAttribute(getDocument_ProcStatus(), ecorePackage.getEString(), "procStatus", null, 1, 1, Document.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getDocument_ReadStatus(), ecorePackage.getEString(), "readStatus", null, 1, 1, Document.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEAttribute(getDocument_Title(), ecorePackage.getEString(), "title", null, 1, 1, Document.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getDocument_TherL1(), ecorePackage.getEString(), "therL1", null, 1, 1, Document.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEAttribute(getDocument_TherL2(), ecorePackage.getEString(), "therL2", null, 1, 1, Document.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEAttribute(getDocument_TherL3(), ecorePackage.getEString(), "therL3", null, 1, 1, Document.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEAttribute(getDocument_ExtRef(), ecorePackage.getEString(), "extRef", null, 1, 1, Document.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEAttribute(getDocument_BagId(), ecorePackage.getEString(), "bagId", null, 1, 1, Document.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getDocument_EnvelopeId(), ecorePackage.getEString(), "envelopeId", null, 1, 1, Document.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getDocument_ScanId(), ecorePackage.getEString(), "scanId", null, 1, 1, Document.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getDocument_ScanName(), ecorePackage.getEString(), "scanName", null, 1, 1, Document.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getDocument_ScanDate(), ecorePackage.getEDate(), "scanDate", null, 1, 1, Document.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getDocument_ArchiveBoxNum(), ecorePackage.getEString(), "archiveBoxNum", null, 1, 1, Document.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getDocument_AuditRecords(), this.getAuditRec(), null, "auditRecords", null, 0, -1, Document.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		getDocument_AuditRecords().getEKeys().add(this.getAuditRec_ObjectId());
		initEReference(getDocument_Fileblob(), this.getFileBlob(), null, "fileblob", null, 1, 1, Document.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		getDocument_Fileblob().getEKeys().add(this.getFileBlob_DocId());
		initEReference(getDocument_Container(), this.getContainedDoc(), null, "container", null, 1, 1, Document.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		getDocument_Container().getEKeys().add(this.getContainedDoc_DocId());
		initEReference(getDocument_ACL(), this.getSecAccess(), null, "ACL", null, 0, -1, Document.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		getDocument_ACL().getEKeys().add(this.getSecAccess_ObjectId());

		initEClass(containerEClass, au.gov.dva.digitize.Container.class, "Container", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getContainer_Id(), ecorePackage.getEInt(), "id", null, 1, 1, au.gov.dva.digitize.Container.class, !IS_TRANSIENT, !IS_VOLATILE, !IS_CHANGEABLE, IS_UNSETTABLE, IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEAttribute(getContainer_ParentId(), ecorePackage.getEInt(), "parentId", null, 1, 1, au.gov.dva.digitize.Container.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEAttribute(getContainer_Type(), ecorePackage.getEString(), "type", null, 1, 1, au.gov.dva.digitize.Container.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEAttribute(getContainer_Label(), ecorePackage.getEString(), "label", null, 1, 1, au.gov.dva.digitize.Container.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEAttribute(getContainer_ExtRef(), ecorePackage.getEString(), "extRef", null, 1, 1, au.gov.dva.digitize.Container.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getContainer_Documents(), this.getContainedDoc(), null, "documents", null, 0, -1, au.gov.dva.digitize.Container.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		getContainer_Documents().getEKeys().add(this.getContainedDoc_ContainerId());
		initEReference(getContainer_ACL(), this.getSecAccess(), null, "ACL", null, 0, -1, au.gov.dva.digitize.Container.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		getContainer_ACL().getEKeys().add(this.getSecAccess_ObjectId());
		initEReference(getContainer_ParentContainer(), this.getContainer(), null, "parentContainer", null, 0, 1, au.gov.dva.digitize.Container.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		getContainer_ParentContainer().getEKeys().add(this.getContainer_ParentId());

		initEClass(containedDocEClass, ContainedDoc.class, "ContainedDoc", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getContainedDoc_ContainerId(), ecorePackage.getEInt(), "containerId", null, 1, 1, ContainedDoc.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getContainedDoc_DocId(), ecorePackage.getEInt(), "docId", null, 1, 1, ContainedDoc.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(fileBlobEClass, FileBlob.class, "FileBlob", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getFileBlob_DocId(), ecorePackage.getEInt(), "docId", null, 1, 1, FileBlob.class, !IS_TRANSIENT, !IS_VOLATILE, !IS_CHANGEABLE, IS_UNSETTABLE, IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEAttribute(getFileBlob_Blob(), ecorePackage.getEByteArray(), "blob", null, 1, 1, FileBlob.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getFileBlob_Type(), ecorePackage.getEString(), "type", null, 1, 1, FileBlob.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);

		initEClass(auditRecEClass, AuditRec.class, "AuditRec", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getAuditRec_Id(), ecorePackage.getEInt(), "id", null, 1, 1, AuditRec.class, !IS_TRANSIENT, !IS_VOLATILE, !IS_CHANGEABLE, IS_UNSETTABLE, IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEAttribute(getAuditRec_Type(), ecorePackage.getEString(), "type", null, 1, 1, AuditRec.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getAuditRec_ObjectId(), ecorePackage.getEInt(), "objectId", null, 1, 1, AuditRec.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getAuditRec_ObjectType(), ecorePackage.getEString(), "objectType", null, 1, 1, AuditRec.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getAuditRec_CreateDate(), ecorePackage.getEDate(), "createDate", null, 1, 1, AuditRec.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getAuditRec_CreateBy(), ecorePackage.getEString(), "createBy", null, 1, 1, AuditRec.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getAuditRec_Action(), ecorePackage.getEString(), "action", null, 1, 1, AuditRec.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getAuditRec_Details(), ecorePackage.getEString(), "details", null, 1, 1, AuditRec.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(secAccessEClass, SecAccess.class, "SecAccess", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getSecAccess_ObjectId(), ecorePackage.getEInt(), "objectId", null, 1, 1, SecAccess.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEAttribute(getSecAccess_ObjectType(), ecorePackage.getEString(), "objectType", null, 1, 1, SecAccess.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEAttribute(getSecAccess_PermissionId(), ecorePackage.getEInt(), "permissionId", null, 1, 1, SecAccess.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEAttribute(getSecAccess_SubjectId(), ecorePackage.getEString(), "subjectId", null, 1, 1, SecAccess.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);

		initEClass(secSubjectEClass, SecSubject.class, "SecSubject", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getSecSubject_Id(), ecorePackage.getEInt(), "id", null, 1, 1, SecSubject.class, !IS_TRANSIENT, !IS_VOLATILE, !IS_CHANGEABLE, IS_UNSETTABLE, IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEAttribute(getSecSubject_Label(), ecorePackage.getEString(), "label", null, 1, 1, SecSubject.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getSecSubject_ExternalName(), ecorePackage.getEString(), "externalName", null, 1, 1, SecSubject.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getSecSubject_ExternalId(), ecorePackage.getEString(), "externalId", null, 1, 1, SecSubject.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getSecSubject_ACL(), this.getSecAccess(), null, "ACL", null, 0, -1, SecSubject.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		getSecSubject_ACL().getEKeys().add(this.getSecAccess_SubjectId());

		initEClass(secPermissionEClass, SecPermission.class, "SecPermission", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getSecPermission_Id(), ecorePackage.getEInt(), "id", null, 1, 1, SecPermission.class, !IS_TRANSIENT, !IS_VOLATILE, !IS_CHANGEABLE, IS_UNSETTABLE, IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEAttribute(getSecPermission_Label(), ecorePackage.getEString(), "label", null, 1, 1, SecPermission.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getSecPermission_ObjectType(), ecorePackage.getEString(), "objectType", null, 1, 1, SecPermission.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getSecPermission_ACL(), this.getSecAccess(), null, "ACL", null, 0, -1, SecPermission.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		getSecPermission_ACL().getEKeys().add(this.getSecAccess_PermissionId());

		// Create resource
		createResource(eNS_URI);
	}

} //DigitizePackageImpl
