/**
 */
package au.gov.dva.digitize.impl;

import au.gov.dva.digitize.AuditRec;
import au.gov.dva.digitize.ContainedDoc;
import au.gov.dva.digitize.Document;
import au.gov.dva.digitize.FileBlob;
import au.gov.dva.digitize.SecAccess;

import au.gov.dva.digitize.meta.DigitizePackage;

import java.util.Collection;
import java.util.Date;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectResolvingEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Document</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link au.gov.dva.digitize.impl.DocumentImpl#getId <em>Id</em>}</li>
 *   <li>{@link au.gov.dva.digitize.impl.DocumentImpl#getProcStatus <em>Proc Status</em>}</li>
 *   <li>{@link au.gov.dva.digitize.impl.DocumentImpl#getReadStatus <em>Read Status</em>}</li>
 *   <li>{@link au.gov.dva.digitize.impl.DocumentImpl#getTitle <em>Title</em>}</li>
 *   <li>{@link au.gov.dva.digitize.impl.DocumentImpl#getTherL1 <em>Ther L1</em>}</li>
 *   <li>{@link au.gov.dva.digitize.impl.DocumentImpl#getTherL2 <em>Ther L2</em>}</li>
 *   <li>{@link au.gov.dva.digitize.impl.DocumentImpl#getTherL3 <em>Ther L3</em>}</li>
 *   <li>{@link au.gov.dva.digitize.impl.DocumentImpl#getExtRef <em>Ext Ref</em>}</li>
 *   <li>{@link au.gov.dva.digitize.impl.DocumentImpl#getBagId <em>Bag Id</em>}</li>
 *   <li>{@link au.gov.dva.digitize.impl.DocumentImpl#getEnvelopeId <em>Envelope Id</em>}</li>
 *   <li>{@link au.gov.dva.digitize.impl.DocumentImpl#getScanId <em>Scan Id</em>}</li>
 *   <li>{@link au.gov.dva.digitize.impl.DocumentImpl#getScanName <em>Scan Name</em>}</li>
 *   <li>{@link au.gov.dva.digitize.impl.DocumentImpl#getScanDate <em>Scan Date</em>}</li>
 *   <li>{@link au.gov.dva.digitize.impl.DocumentImpl#getArchiveBoxNum <em>Archive Box Num</em>}</li>
 *   <li>{@link au.gov.dva.digitize.impl.DocumentImpl#getAuditRecords <em>Audit Records</em>}</li>
 *   <li>{@link au.gov.dva.digitize.impl.DocumentImpl#getFileblob <em>Fileblob</em>}</li>
 *   <li>{@link au.gov.dva.digitize.impl.DocumentImpl#getContainer <em>Container</em>}</li>
 *   <li>{@link au.gov.dva.digitize.impl.DocumentImpl#getACL <em>ACL</em>}</li>
 * </ul>
 *
 * @generated
 */
public class DocumentImpl extends MinimalEObjectImpl.Container implements Document {
	/**
	 * The default value of the '{@link #getId() <em>Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getId()
	 * @generated
	 * @ordered
	 */
	protected static final int ID_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getId() <em>Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getId()
	 * @generated
	 * @ordered
	 */
	protected int id = ID_EDEFAULT;

	/**
	 * This is true if the Id attribute has been set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	protected boolean idESet;

	/**
	 * The default value of the '{@link #getProcStatus() <em>Proc Status</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getProcStatus()
	 * @generated
	 * @ordered
	 */
	protected static final String PROC_STATUS_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getProcStatus() <em>Proc Status</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getProcStatus()
	 * @generated
	 * @ordered
	 */
	protected String procStatus = PROC_STATUS_EDEFAULT;

	/**
	 * The default value of the '{@link #getReadStatus() <em>Read Status</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getReadStatus()
	 * @generated
	 * @ordered
	 */
	protected static final String READ_STATUS_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getReadStatus() <em>Read Status</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getReadStatus()
	 * @generated
	 * @ordered
	 */
	protected String readStatus = READ_STATUS_EDEFAULT;

	/**
	 * The default value of the '{@link #getTitle() <em>Title</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTitle()
	 * @generated
	 * @ordered
	 */
	protected static final String TITLE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getTitle() <em>Title</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTitle()
	 * @generated
	 * @ordered
	 */
	protected String title = TITLE_EDEFAULT;

	/**
	 * The default value of the '{@link #getTherL1() <em>Ther L1</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTherL1()
	 * @generated
	 * @ordered
	 */
	protected static final String THER_L1_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getTherL1() <em>Ther L1</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTherL1()
	 * @generated
	 * @ordered
	 */
	protected String therL1 = THER_L1_EDEFAULT;

	/**
	 * The default value of the '{@link #getTherL2() <em>Ther L2</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTherL2()
	 * @generated
	 * @ordered
	 */
	protected static final String THER_L2_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getTherL2() <em>Ther L2</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTherL2()
	 * @generated
	 * @ordered
	 */
	protected String therL2 = THER_L2_EDEFAULT;

	/**
	 * The default value of the '{@link #getTherL3() <em>Ther L3</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTherL3()
	 * @generated
	 * @ordered
	 */
	protected static final String THER_L3_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getTherL3() <em>Ther L3</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTherL3()
	 * @generated
	 * @ordered
	 */
	protected String therL3 = THER_L3_EDEFAULT;

	/**
	 * The default value of the '{@link #getExtRef() <em>Ext Ref</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getExtRef()
	 * @generated
	 * @ordered
	 */
	protected static final String EXT_REF_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getExtRef() <em>Ext Ref</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getExtRef()
	 * @generated
	 * @ordered
	 */
	protected String extRef = EXT_REF_EDEFAULT;

	/**
	 * The default value of the '{@link #getBagId() <em>Bag Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getBagId()
	 * @generated
	 * @ordered
	 */
	protected static final String BAG_ID_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getBagId() <em>Bag Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getBagId()
	 * @generated
	 * @ordered
	 */
	protected String bagId = BAG_ID_EDEFAULT;

	/**
	 * The default value of the '{@link #getEnvelopeId() <em>Envelope Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEnvelopeId()
	 * @generated
	 * @ordered
	 */
	protected static final String ENVELOPE_ID_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getEnvelopeId() <em>Envelope Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEnvelopeId()
	 * @generated
	 * @ordered
	 */
	protected String envelopeId = ENVELOPE_ID_EDEFAULT;

	/**
	 * The default value of the '{@link #getScanId() <em>Scan Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getScanId()
	 * @generated
	 * @ordered
	 */
	protected static final String SCAN_ID_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getScanId() <em>Scan Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getScanId()
	 * @generated
	 * @ordered
	 */
	protected String scanId = SCAN_ID_EDEFAULT;

	/**
	 * The default value of the '{@link #getScanName() <em>Scan Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getScanName()
	 * @generated
	 * @ordered
	 */
	protected static final String SCAN_NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getScanName() <em>Scan Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getScanName()
	 * @generated
	 * @ordered
	 */
	protected String scanName = SCAN_NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getScanDate() <em>Scan Date</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getScanDate()
	 * @generated
	 * @ordered
	 */
	protected static final Date SCAN_DATE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getScanDate() <em>Scan Date</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getScanDate()
	 * @generated
	 * @ordered
	 */
	protected Date scanDate = SCAN_DATE_EDEFAULT;

	/**
	 * The default value of the '{@link #getArchiveBoxNum() <em>Archive Box Num</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getArchiveBoxNum()
	 * @generated
	 * @ordered
	 */
	protected static final String ARCHIVE_BOX_NUM_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getArchiveBoxNum() <em>Archive Box Num</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getArchiveBoxNum()
	 * @generated
	 * @ordered
	 */
	protected String archiveBoxNum = ARCHIVE_BOX_NUM_EDEFAULT;

	/**
	 * The cached value of the '{@link #getAuditRecords() <em>Audit Records</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAuditRecords()
	 * @generated
	 * @ordered
	 */
	protected EList auditRecords;

	/**
	 * The cached value of the '{@link #getFileblob() <em>Fileblob</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFileblob()
	 * @generated
	 * @ordered
	 */
	protected FileBlob fileblob;

	/**
	 * The cached value of the '{@link #getContainer() <em>Container</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getContainer()
	 * @generated
	 * @ordered
	 */
	protected ContainedDoc container;

	/**
	 * The cached value of the '{@link #getACL() <em>ACL</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getACL()
	 * @generated
	 * @ordered
	 */
	protected EList acl;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected DocumentImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return DigitizePackage.Literals.DOCUMENT;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getId() {
		return id;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isSetId() {
		return idESet;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getProcStatus() {
		return procStatus;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setProcStatus(String newProcStatus) {
		String oldProcStatus = procStatus;
		procStatus = newProcStatus;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, DigitizePackage.DOCUMENT__PROC_STATUS, oldProcStatus, procStatus));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getReadStatus() {
		return readStatus;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setReadStatus(String newReadStatus) {
		String oldReadStatus = readStatus;
		readStatus = newReadStatus;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, DigitizePackage.DOCUMENT__READ_STATUS, oldReadStatus, readStatus));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getTitle() {
		return title;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTitle(String newTitle) {
		String oldTitle = title;
		title = newTitle;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, DigitizePackage.DOCUMENT__TITLE, oldTitle, title));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getTherL1() {
		return therL1;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTherL1(String newTherL1) {
		String oldTherL1 = therL1;
		therL1 = newTherL1;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, DigitizePackage.DOCUMENT__THER_L1, oldTherL1, therL1));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getTherL2() {
		return therL2;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTherL2(String newTherL2) {
		String oldTherL2 = therL2;
		therL2 = newTherL2;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, DigitizePackage.DOCUMENT__THER_L2, oldTherL2, therL2));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getTherL3() {
		return therL3;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTherL3(String newTherL3) {
		String oldTherL3 = therL3;
		therL3 = newTherL3;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, DigitizePackage.DOCUMENT__THER_L3, oldTherL3, therL3));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getExtRef() {
		return extRef;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setExtRef(String newExtRef) {
		String oldExtRef = extRef;
		extRef = newExtRef;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, DigitizePackage.DOCUMENT__EXT_REF, oldExtRef, extRef));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getBagId() {
		return bagId;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setBagId(String newBagId) {
		String oldBagId = bagId;
		bagId = newBagId;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, DigitizePackage.DOCUMENT__BAG_ID, oldBagId, bagId));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getEnvelopeId() {
		return envelopeId;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setEnvelopeId(String newEnvelopeId) {
		String oldEnvelopeId = envelopeId;
		envelopeId = newEnvelopeId;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, DigitizePackage.DOCUMENT__ENVELOPE_ID, oldEnvelopeId, envelopeId));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getScanId() {
		return scanId;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setScanId(String newScanId) {
		String oldScanId = scanId;
		scanId = newScanId;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, DigitizePackage.DOCUMENT__SCAN_ID, oldScanId, scanId));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getScanName() {
		return scanName;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setScanName(String newScanName) {
		String oldScanName = scanName;
		scanName = newScanName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, DigitizePackage.DOCUMENT__SCAN_NAME, oldScanName, scanName));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Date getScanDate() {
		return scanDate;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setScanDate(Date newScanDate) {
		Date oldScanDate = scanDate;
		scanDate = newScanDate;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, DigitizePackage.DOCUMENT__SCAN_DATE, oldScanDate, scanDate));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getArchiveBoxNum() {
		return archiveBoxNum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setArchiveBoxNum(String newArchiveBoxNum) {
		String oldArchiveBoxNum = archiveBoxNum;
		archiveBoxNum = newArchiveBoxNum;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, DigitizePackage.DOCUMENT__ARCHIVE_BOX_NUM, oldArchiveBoxNum, archiveBoxNum));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getAuditRecords() {
		if (auditRecords == null) {
			auditRecords = new EObjectResolvingEList(AuditRec.class, this, DigitizePackage.DOCUMENT__AUDIT_RECORDS);
		}
		return auditRecords;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public FileBlob getFileblob() {
		if (fileblob != null && fileblob.eIsProxy()) {
			InternalEObject oldFileblob = (InternalEObject)fileblob;
			fileblob = (FileBlob)eResolveProxy(oldFileblob);
			if (fileblob != oldFileblob) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, DigitizePackage.DOCUMENT__FILEBLOB, oldFileblob, fileblob));
			}
		}
		return fileblob;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public FileBlob basicGetFileblob() {
		return fileblob;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setFileblob(FileBlob newFileblob) {
		FileBlob oldFileblob = fileblob;
		fileblob = newFileblob;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, DigitizePackage.DOCUMENT__FILEBLOB, oldFileblob, fileblob));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ContainedDoc getContainer() {
		if (container != null && container.eIsProxy()) {
			InternalEObject oldContainer = (InternalEObject)container;
			container = (ContainedDoc)eResolveProxy(oldContainer);
			if (container != oldContainer) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, DigitizePackage.DOCUMENT__CONTAINER, oldContainer, container));
			}
		}
		return container;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ContainedDoc basicGetContainer() {
		return container;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setContainer(ContainedDoc newContainer) {
		ContainedDoc oldContainer = container;
		container = newContainer;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, DigitizePackage.DOCUMENT__CONTAINER, oldContainer, container));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getACL() {
		if (acl == null) {
			acl = new EObjectResolvingEList(SecAccess.class, this, DigitizePackage.DOCUMENT__ACL);
		}
		return acl;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case DigitizePackage.DOCUMENT__ID:
				return new Integer(getId());
			case DigitizePackage.DOCUMENT__PROC_STATUS:
				return getProcStatus();
			case DigitizePackage.DOCUMENT__READ_STATUS:
				return getReadStatus();
			case DigitizePackage.DOCUMENT__TITLE:
				return getTitle();
			case DigitizePackage.DOCUMENT__THER_L1:
				return getTherL1();
			case DigitizePackage.DOCUMENT__THER_L2:
				return getTherL2();
			case DigitizePackage.DOCUMENT__THER_L3:
				return getTherL3();
			case DigitizePackage.DOCUMENT__EXT_REF:
				return getExtRef();
			case DigitizePackage.DOCUMENT__BAG_ID:
				return getBagId();
			case DigitizePackage.DOCUMENT__ENVELOPE_ID:
				return getEnvelopeId();
			case DigitizePackage.DOCUMENT__SCAN_ID:
				return getScanId();
			case DigitizePackage.DOCUMENT__SCAN_NAME:
				return getScanName();
			case DigitizePackage.DOCUMENT__SCAN_DATE:
				return getScanDate();
			case DigitizePackage.DOCUMENT__ARCHIVE_BOX_NUM:
				return getArchiveBoxNum();
			case DigitizePackage.DOCUMENT__AUDIT_RECORDS:
				return getAuditRecords();
			case DigitizePackage.DOCUMENT__FILEBLOB:
				if (resolve) return getFileblob();
				return basicGetFileblob();
			case DigitizePackage.DOCUMENT__CONTAINER:
				if (resolve) return getContainer();
				return basicGetContainer();
			case DigitizePackage.DOCUMENT__ACL:
				return getACL();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case DigitizePackage.DOCUMENT__PROC_STATUS:
				setProcStatus((String)newValue);
				return;
			case DigitizePackage.DOCUMENT__READ_STATUS:
				setReadStatus((String)newValue);
				return;
			case DigitizePackage.DOCUMENT__TITLE:
				setTitle((String)newValue);
				return;
			case DigitizePackage.DOCUMENT__THER_L1:
				setTherL1((String)newValue);
				return;
			case DigitizePackage.DOCUMENT__THER_L2:
				setTherL2((String)newValue);
				return;
			case DigitizePackage.DOCUMENT__THER_L3:
				setTherL3((String)newValue);
				return;
			case DigitizePackage.DOCUMENT__EXT_REF:
				setExtRef((String)newValue);
				return;
			case DigitizePackage.DOCUMENT__BAG_ID:
				setBagId((String)newValue);
				return;
			case DigitizePackage.DOCUMENT__ENVELOPE_ID:
				setEnvelopeId((String)newValue);
				return;
			case DigitizePackage.DOCUMENT__SCAN_ID:
				setScanId((String)newValue);
				return;
			case DigitizePackage.DOCUMENT__SCAN_NAME:
				setScanName((String)newValue);
				return;
			case DigitizePackage.DOCUMENT__SCAN_DATE:
				setScanDate((Date)newValue);
				return;
			case DigitizePackage.DOCUMENT__ARCHIVE_BOX_NUM:
				setArchiveBoxNum((String)newValue);
				return;
			case DigitizePackage.DOCUMENT__AUDIT_RECORDS:
				getAuditRecords().clear();
				getAuditRecords().addAll((Collection)newValue);
				return;
			case DigitizePackage.DOCUMENT__FILEBLOB:
				setFileblob((FileBlob)newValue);
				return;
			case DigitizePackage.DOCUMENT__CONTAINER:
				setContainer((ContainedDoc)newValue);
				return;
			case DigitizePackage.DOCUMENT__ACL:
				getACL().clear();
				getACL().addAll((Collection)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eUnset(int featureID) {
		switch (featureID) {
			case DigitizePackage.DOCUMENT__PROC_STATUS:
				setProcStatus(PROC_STATUS_EDEFAULT);
				return;
			case DigitizePackage.DOCUMENT__READ_STATUS:
				setReadStatus(READ_STATUS_EDEFAULT);
				return;
			case DigitizePackage.DOCUMENT__TITLE:
				setTitle(TITLE_EDEFAULT);
				return;
			case DigitizePackage.DOCUMENT__THER_L1:
				setTherL1(THER_L1_EDEFAULT);
				return;
			case DigitizePackage.DOCUMENT__THER_L2:
				setTherL2(THER_L2_EDEFAULT);
				return;
			case DigitizePackage.DOCUMENT__THER_L3:
				setTherL3(THER_L3_EDEFAULT);
				return;
			case DigitizePackage.DOCUMENT__EXT_REF:
				setExtRef(EXT_REF_EDEFAULT);
				return;
			case DigitizePackage.DOCUMENT__BAG_ID:
				setBagId(BAG_ID_EDEFAULT);
				return;
			case DigitizePackage.DOCUMENT__ENVELOPE_ID:
				setEnvelopeId(ENVELOPE_ID_EDEFAULT);
				return;
			case DigitizePackage.DOCUMENT__SCAN_ID:
				setScanId(SCAN_ID_EDEFAULT);
				return;
			case DigitizePackage.DOCUMENT__SCAN_NAME:
				setScanName(SCAN_NAME_EDEFAULT);
				return;
			case DigitizePackage.DOCUMENT__SCAN_DATE:
				setScanDate(SCAN_DATE_EDEFAULT);
				return;
			case DigitizePackage.DOCUMENT__ARCHIVE_BOX_NUM:
				setArchiveBoxNum(ARCHIVE_BOX_NUM_EDEFAULT);
				return;
			case DigitizePackage.DOCUMENT__AUDIT_RECORDS:
				getAuditRecords().clear();
				return;
			case DigitizePackage.DOCUMENT__FILEBLOB:
				setFileblob((FileBlob)null);
				return;
			case DigitizePackage.DOCUMENT__CONTAINER:
				setContainer((ContainedDoc)null);
				return;
			case DigitizePackage.DOCUMENT__ACL:
				getACL().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case DigitizePackage.DOCUMENT__ID:
				return isSetId();
			case DigitizePackage.DOCUMENT__PROC_STATUS:
				return PROC_STATUS_EDEFAULT == null ? procStatus != null : !PROC_STATUS_EDEFAULT.equals(procStatus);
			case DigitizePackage.DOCUMENT__READ_STATUS:
				return READ_STATUS_EDEFAULT == null ? readStatus != null : !READ_STATUS_EDEFAULT.equals(readStatus);
			case DigitizePackage.DOCUMENT__TITLE:
				return TITLE_EDEFAULT == null ? title != null : !TITLE_EDEFAULT.equals(title);
			case DigitizePackage.DOCUMENT__THER_L1:
				return THER_L1_EDEFAULT == null ? therL1 != null : !THER_L1_EDEFAULT.equals(therL1);
			case DigitizePackage.DOCUMENT__THER_L2:
				return THER_L2_EDEFAULT == null ? therL2 != null : !THER_L2_EDEFAULT.equals(therL2);
			case DigitizePackage.DOCUMENT__THER_L3:
				return THER_L3_EDEFAULT == null ? therL3 != null : !THER_L3_EDEFAULT.equals(therL3);
			case DigitizePackage.DOCUMENT__EXT_REF:
				return EXT_REF_EDEFAULT == null ? extRef != null : !EXT_REF_EDEFAULT.equals(extRef);
			case DigitizePackage.DOCUMENT__BAG_ID:
				return BAG_ID_EDEFAULT == null ? bagId != null : !BAG_ID_EDEFAULT.equals(bagId);
			case DigitizePackage.DOCUMENT__ENVELOPE_ID:
				return ENVELOPE_ID_EDEFAULT == null ? envelopeId != null : !ENVELOPE_ID_EDEFAULT.equals(envelopeId);
			case DigitizePackage.DOCUMENT__SCAN_ID:
				return SCAN_ID_EDEFAULT == null ? scanId != null : !SCAN_ID_EDEFAULT.equals(scanId);
			case DigitizePackage.DOCUMENT__SCAN_NAME:
				return SCAN_NAME_EDEFAULT == null ? scanName != null : !SCAN_NAME_EDEFAULT.equals(scanName);
			case DigitizePackage.DOCUMENT__SCAN_DATE:
				return SCAN_DATE_EDEFAULT == null ? scanDate != null : !SCAN_DATE_EDEFAULT.equals(scanDate);
			case DigitizePackage.DOCUMENT__ARCHIVE_BOX_NUM:
				return ARCHIVE_BOX_NUM_EDEFAULT == null ? archiveBoxNum != null : !ARCHIVE_BOX_NUM_EDEFAULT.equals(archiveBoxNum);
			case DigitizePackage.DOCUMENT__AUDIT_RECORDS:
				return auditRecords != null && !auditRecords.isEmpty();
			case DigitizePackage.DOCUMENT__FILEBLOB:
				return fileblob != null;
			case DigitizePackage.DOCUMENT__CONTAINER:
				return container != null;
			case DigitizePackage.DOCUMENT__ACL:
				return acl != null && !acl.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (id: ");
		if (idESet) result.append(id); else result.append("<unset>");
		result.append(", procStatus: ");
		result.append(procStatus);
		result.append(", readStatus: ");
		result.append(readStatus);
		result.append(", title: ");
		result.append(title);
		result.append(", therL1: ");
		result.append(therL1);
		result.append(", therL2: ");
		result.append(therL2);
		result.append(", therL3: ");
		result.append(therL3);
		result.append(", extRef: ");
		result.append(extRef);
		result.append(", bagId: ");
		result.append(bagId);
		result.append(", envelopeId: ");
		result.append(envelopeId);
		result.append(", scanId: ");
		result.append(scanId);
		result.append(", scanName: ");
		result.append(scanName);
		result.append(", scanDate: ");
		result.append(scanDate);
		result.append(", archiveBoxNum: ");
		result.append(archiveBoxNum);
		result.append(')');
		return result.toString();
	}

} //DocumentImpl
