/**
 */
package au.gov.dva.digitize;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Contained Doc</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link au.gov.dva.digitize.ContainedDoc#getContainerId <em>Container Id</em>}</li>
 *   <li>{@link au.gov.dva.digitize.ContainedDoc#getDocId <em>Doc Id</em>}</li>
 * </ul>
 *
 * @see au.gov.dva.digitize.meta.DigitizePackage#getContainedDoc()
 * @model
 * @generated
 */
public interface ContainedDoc extends EObject {
	/**
	 * Returns the value of the '<em><b>Container Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Container Id</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Container Id</em>' attribute.
	 * @see #setContainerId(int)
	 * @see au.gov.dva.digitize.meta.DigitizePackage#getContainedDoc_ContainerId()
	 * @model required="true"
	 * @generated
	 */
	int getContainerId();

	/**
	 * Sets the value of the '{@link au.gov.dva.digitize.ContainedDoc#getContainerId <em>Container Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Container Id</em>' attribute.
	 * @see #getContainerId()
	 * @generated
	 */
	void setContainerId(int value);

	/**
	 * Returns the value of the '<em><b>Doc Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Doc Id</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Doc Id</em>' attribute.
	 * @see #setDocId(int)
	 * @see au.gov.dva.digitize.meta.DigitizePackage#getContainedDoc_DocId()
	 * @model required="true"
	 * @generated
	 */
	int getDocId();

	/**
	 * Sets the value of the '{@link au.gov.dva.digitize.ContainedDoc#getDocId <em>Doc Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Doc Id</em>' attribute.
	 * @see #getDocId()
	 * @generated
	 */
	void setDocId(int value);

} // ContainedDoc
