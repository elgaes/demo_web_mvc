/**
 */
package au.gov.dva.digitize.impl;

import au.gov.dva.digitize.FileBlob;

import au.gov.dva.digitize.meta.DigitizePackage;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>File Blob</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link au.gov.dva.digitize.impl.FileBlobImpl#getDocId <em>Doc Id</em>}</li>
 *   <li>{@link au.gov.dva.digitize.impl.FileBlobImpl#getBlob <em>Blob</em>}</li>
 *   <li>{@link au.gov.dva.digitize.impl.FileBlobImpl#getType <em>Type</em>}</li>
 * </ul>
 *
 * @generated
 */
public class FileBlobImpl extends MinimalEObjectImpl.Container implements FileBlob {
	/**
	 * The default value of the '{@link #getDocId() <em>Doc Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDocId()
	 * @generated
	 * @ordered
	 */
	protected static final int DOC_ID_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getDocId() <em>Doc Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDocId()
	 * @generated
	 * @ordered
	 */
	protected int docId = DOC_ID_EDEFAULT;

	/**
	 * This is true if the Doc Id attribute has been set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	protected boolean docIdESet;

	/**
	 * The default value of the '{@link #getBlob() <em>Blob</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getBlob()
	 * @generated
	 * @ordered
	 */
	protected static final byte[] BLOB_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getBlob() <em>Blob</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getBlob()
	 * @generated
	 * @ordered
	 */
	protected byte[] blob = BLOB_EDEFAULT;

	/**
	 * The default value of the '{@link #getType() <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getType()
	 * @generated
	 * @ordered
	 */
	protected static final String TYPE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getType() <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getType()
	 * @generated
	 * @ordered
	 */
	protected String type = TYPE_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected FileBlobImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return DigitizePackage.Literals.FILE_BLOB;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getDocId() {
		return docId;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isSetDocId() {
		return docIdESet;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public byte[] getBlob() {
		return blob;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setBlob(byte[] newBlob) {
		byte[] oldBlob = blob;
		blob = newBlob;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, DigitizePackage.FILE_BLOB__BLOB, oldBlob, blob));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getType() {
		return type;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setType(String newType) {
		String oldType = type;
		type = newType;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, DigitizePackage.FILE_BLOB__TYPE, oldType, type));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case DigitizePackage.FILE_BLOB__DOC_ID:
				return new Integer(getDocId());
			case DigitizePackage.FILE_BLOB__BLOB:
				return getBlob();
			case DigitizePackage.FILE_BLOB__TYPE:
				return getType();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case DigitizePackage.FILE_BLOB__BLOB:
				setBlob((byte[])newValue);
				return;
			case DigitizePackage.FILE_BLOB__TYPE:
				setType((String)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eUnset(int featureID) {
		switch (featureID) {
			case DigitizePackage.FILE_BLOB__BLOB:
				setBlob(BLOB_EDEFAULT);
				return;
			case DigitizePackage.FILE_BLOB__TYPE:
				setType(TYPE_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case DigitizePackage.FILE_BLOB__DOC_ID:
				return isSetDocId();
			case DigitizePackage.FILE_BLOB__BLOB:
				return BLOB_EDEFAULT == null ? blob != null : !BLOB_EDEFAULT.equals(blob);
			case DigitizePackage.FILE_BLOB__TYPE:
				return TYPE_EDEFAULT == null ? type != null : !TYPE_EDEFAULT.equals(type);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (docId: ");
		if (docIdESet) result.append(docId); else result.append("<unset>");
		result.append(", blob: ");
		result.append(blob);
		result.append(", type: ");
		result.append(type);
		result.append(')');
		return result.toString();
	}

} //FileBlobImpl
