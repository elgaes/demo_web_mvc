/**
 */
package au.gov.dva.digitize.util;

import au.gov.dva.digitize.*;

import au.gov.dva.digitize.meta.DigitizePackage;

import org.eclipse.emf.common.notify.Adapter;
import org.eclipse.emf.common.notify.Notifier;

import org.eclipse.emf.common.notify.impl.AdapterFactoryImpl;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * The <b>Adapter Factory</b> for the model.
 * It provides an adapter <code>createXXX</code> method for each class of the model.
 * <!-- end-user-doc -->
 * @see au.gov.dva.digitize.meta.DigitizePackage
 * @generated
 */
public class DigitizeAdapterFactory extends AdapterFactoryImpl {
	/**
	 * The cached model package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static DigitizePackage modelPackage;

	/**
	 * Creates an instance of the adapter factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DigitizeAdapterFactory() {
		if (modelPackage == null) {
			modelPackage = DigitizePackage.eINSTANCE;
		}
	}

	/**
	 * Returns whether this factory is applicable for the type of the object.
	 * <!-- begin-user-doc -->
	 * This implementation returns <code>true</code> if the object is either the model's package or is an instance object of the model.
	 * <!-- end-user-doc -->
	 * @return whether this factory is applicable for the type of the object.
	 * @generated
	 */
	public boolean isFactoryForType(Object object) {
		if (object == modelPackage) {
			return true;
		}
		if (object instanceof EObject) {
			return ((EObject)object).eClass().getEPackage() == modelPackage;
		}
		return false;
	}

	/**
	 * The switch that delegates to the <code>createXXX</code> methods.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected DigitizeSwitch modelSwitch =
		new DigitizeSwitch() {
			public Object caseDocument(Document object) {
				return createDocumentAdapter();
			}
			public Object caseContainer(Container object) {
				return createContainerAdapter();
			}
			public Object caseContainedDoc(ContainedDoc object) {
				return createContainedDocAdapter();
			}
			public Object caseFileBlob(FileBlob object) {
				return createFileBlobAdapter();
			}
			public Object caseAuditRec(AuditRec object) {
				return createAuditRecAdapter();
			}
			public Object caseSecAccess(SecAccess object) {
				return createSecAccessAdapter();
			}
			public Object caseSecSubject(SecSubject object) {
				return createSecSubjectAdapter();
			}
			public Object caseSecPermission(SecPermission object) {
				return createSecPermissionAdapter();
			}
			public Object defaultCase(EObject object) {
				return createEObjectAdapter();
			}
		};

	/**
	 * Creates an adapter for the <code>target</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param target the object to adapt.
	 * @return the adapter for the <code>target</code>.
	 * @generated
	 */
	public Adapter createAdapter(Notifier target) {
		return (Adapter)modelSwitch.doSwitch((EObject)target);
	}


	/**
	 * Creates a new adapter for an object of class '{@link au.gov.dva.digitize.Document <em>Document</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see au.gov.dva.digitize.Document
	 * @generated
	 */
	public Adapter createDocumentAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link au.gov.dva.digitize.Container <em>Container</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see au.gov.dva.digitize.Container
	 * @generated
	 */
	public Adapter createContainerAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link au.gov.dva.digitize.ContainedDoc <em>Contained Doc</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see au.gov.dva.digitize.ContainedDoc
	 * @generated
	 */
	public Adapter createContainedDocAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link au.gov.dva.digitize.FileBlob <em>File Blob</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see au.gov.dva.digitize.FileBlob
	 * @generated
	 */
	public Adapter createFileBlobAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link au.gov.dva.digitize.AuditRec <em>Audit Rec</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see au.gov.dva.digitize.AuditRec
	 * @generated
	 */
	public Adapter createAuditRecAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link au.gov.dva.digitize.SecAccess <em>Sec Access</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see au.gov.dva.digitize.SecAccess
	 * @generated
	 */
	public Adapter createSecAccessAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link au.gov.dva.digitize.SecSubject <em>Sec Subject</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see au.gov.dva.digitize.SecSubject
	 * @generated
	 */
	public Adapter createSecSubjectAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link au.gov.dva.digitize.SecPermission <em>Sec Permission</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see au.gov.dva.digitize.SecPermission
	 * @generated
	 */
	public Adapter createSecPermissionAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for the default case.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @generated
	 */
	public Adapter createEObjectAdapter() {
		return null;
	}

} //DigitizeAdapterFactory
