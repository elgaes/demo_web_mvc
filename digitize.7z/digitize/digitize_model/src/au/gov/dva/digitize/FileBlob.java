/**
 */
package au.gov.dva.digitize;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>File Blob</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link au.gov.dva.digitize.FileBlob#getDocId <em>Doc Id</em>}</li>
 *   <li>{@link au.gov.dva.digitize.FileBlob#getBlob <em>Blob</em>}</li>
 *   <li>{@link au.gov.dva.digitize.FileBlob#getType <em>Type</em>}</li>
 * </ul>
 *
 * @see au.gov.dva.digitize.meta.DigitizePackage#getFileBlob()
 * @model
 * @generated
 */
public interface FileBlob extends EObject {
	/**
	 * Returns the value of the '<em><b>Doc Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Doc Id</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Doc Id</em>' attribute.
	 * @see #isSetDocId()
	 * @see au.gov.dva.digitize.meta.DigitizePackage#getFileBlob_DocId()
	 * @model unsettable="true" id="true" required="true" changeable="false" ordered="false"
	 * @generated
	 */
	int getDocId();

	/**
	 * Returns whether the value of the '{@link au.gov.dva.digitize.FileBlob#getDocId <em>Doc Id</em>}' attribute is set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return whether the value of the '<em>Doc Id</em>' attribute is set.
	 * @see #getDocId()
	 * @generated
	 */
	boolean isSetDocId();

	/**
	 * Returns the value of the '<em><b>Blob</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Blob</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Blob</em>' attribute.
	 * @see #setBlob(byte[])
	 * @see au.gov.dva.digitize.meta.DigitizePackage#getFileBlob_Blob()
	 * @model required="true"
	 * @generated
	 */
	byte[] getBlob();

	/**
	 * Sets the value of the '{@link au.gov.dva.digitize.FileBlob#getBlob <em>Blob</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Blob</em>' attribute.
	 * @see #getBlob()
	 * @generated
	 */
	void setBlob(byte[] value);

	/**
	 * Returns the value of the '<em><b>Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Type</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Type</em>' attribute.
	 * @see #setType(String)
	 * @see au.gov.dva.digitize.meta.DigitizePackage#getFileBlob_Type()
	 * @model unique="false" required="true" ordered="false"
	 * @generated
	 */
	String getType();

	/**
	 * Sets the value of the '{@link au.gov.dva.digitize.FileBlob#getType <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Type</em>' attribute.
	 * @see #getType()
	 * @generated
	 */
	void setType(String value);

} // FileBlob
