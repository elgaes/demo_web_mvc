/**
 */
package au.gov.dva.digitize.impl;

import au.gov.dva.digitize.SecAccess;

import au.gov.dva.digitize.meta.DigitizePackage;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Sec Access</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link au.gov.dva.digitize.impl.SecAccessImpl#getObjectId <em>Object Id</em>}</li>
 *   <li>{@link au.gov.dva.digitize.impl.SecAccessImpl#getObjectType <em>Object Type</em>}</li>
 *   <li>{@link au.gov.dva.digitize.impl.SecAccessImpl#getPermissionId <em>Permission Id</em>}</li>
 *   <li>{@link au.gov.dva.digitize.impl.SecAccessImpl#getSubjectId <em>Subject Id</em>}</li>
 * </ul>
 *
 * @generated
 */
public class SecAccessImpl extends MinimalEObjectImpl.Container implements SecAccess {
	/**
	 * The default value of the '{@link #getObjectId() <em>Object Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getObjectId()
	 * @generated
	 * @ordered
	 */
	protected static final int OBJECT_ID_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getObjectId() <em>Object Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getObjectId()
	 * @generated
	 * @ordered
	 */
	protected int objectId = OBJECT_ID_EDEFAULT;

	/**
	 * The default value of the '{@link #getObjectType() <em>Object Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getObjectType()
	 * @generated
	 * @ordered
	 */
	protected static final String OBJECT_TYPE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getObjectType() <em>Object Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getObjectType()
	 * @generated
	 * @ordered
	 */
	protected String objectType = OBJECT_TYPE_EDEFAULT;

	/**
	 * The default value of the '{@link #getPermissionId() <em>Permission Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPermissionId()
	 * @generated
	 * @ordered
	 */
	protected static final int PERMISSION_ID_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getPermissionId() <em>Permission Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPermissionId()
	 * @generated
	 * @ordered
	 */
	protected int permissionId = PERMISSION_ID_EDEFAULT;

	/**
	 * The default value of the '{@link #getSubjectId() <em>Subject Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSubjectId()
	 * @generated
	 * @ordered
	 */
	protected static final String SUBJECT_ID_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getSubjectId() <em>Subject Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSubjectId()
	 * @generated
	 * @ordered
	 */
	protected String subjectId = SUBJECT_ID_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SecAccessImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return DigitizePackage.Literals.SEC_ACCESS;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getObjectId() {
		return objectId;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setObjectId(int newObjectId) {
		int oldObjectId = objectId;
		objectId = newObjectId;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, DigitizePackage.SEC_ACCESS__OBJECT_ID, oldObjectId, objectId));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getObjectType() {
		return objectType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setObjectType(String newObjectType) {
		String oldObjectType = objectType;
		objectType = newObjectType;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, DigitizePackage.SEC_ACCESS__OBJECT_TYPE, oldObjectType, objectType));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getPermissionId() {
		return permissionId;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPermissionId(int newPermissionId) {
		int oldPermissionId = permissionId;
		permissionId = newPermissionId;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, DigitizePackage.SEC_ACCESS__PERMISSION_ID, oldPermissionId, permissionId));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getSubjectId() {
		return subjectId;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSubjectId(String newSubjectId) {
		String oldSubjectId = subjectId;
		subjectId = newSubjectId;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, DigitizePackage.SEC_ACCESS__SUBJECT_ID, oldSubjectId, subjectId));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case DigitizePackage.SEC_ACCESS__OBJECT_ID:
				return new Integer(getObjectId());
			case DigitizePackage.SEC_ACCESS__OBJECT_TYPE:
				return getObjectType();
			case DigitizePackage.SEC_ACCESS__PERMISSION_ID:
				return new Integer(getPermissionId());
			case DigitizePackage.SEC_ACCESS__SUBJECT_ID:
				return getSubjectId();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case DigitizePackage.SEC_ACCESS__OBJECT_ID:
				setObjectId(((Integer)newValue).intValue());
				return;
			case DigitizePackage.SEC_ACCESS__OBJECT_TYPE:
				setObjectType((String)newValue);
				return;
			case DigitizePackage.SEC_ACCESS__PERMISSION_ID:
				setPermissionId(((Integer)newValue).intValue());
				return;
			case DigitizePackage.SEC_ACCESS__SUBJECT_ID:
				setSubjectId((String)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eUnset(int featureID) {
		switch (featureID) {
			case DigitizePackage.SEC_ACCESS__OBJECT_ID:
				setObjectId(OBJECT_ID_EDEFAULT);
				return;
			case DigitizePackage.SEC_ACCESS__OBJECT_TYPE:
				setObjectType(OBJECT_TYPE_EDEFAULT);
				return;
			case DigitizePackage.SEC_ACCESS__PERMISSION_ID:
				setPermissionId(PERMISSION_ID_EDEFAULT);
				return;
			case DigitizePackage.SEC_ACCESS__SUBJECT_ID:
				setSubjectId(SUBJECT_ID_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case DigitizePackage.SEC_ACCESS__OBJECT_ID:
				return objectId != OBJECT_ID_EDEFAULT;
			case DigitizePackage.SEC_ACCESS__OBJECT_TYPE:
				return OBJECT_TYPE_EDEFAULT == null ? objectType != null : !OBJECT_TYPE_EDEFAULT.equals(objectType);
			case DigitizePackage.SEC_ACCESS__PERMISSION_ID:
				return permissionId != PERMISSION_ID_EDEFAULT;
			case DigitizePackage.SEC_ACCESS__SUBJECT_ID:
				return SUBJECT_ID_EDEFAULT == null ? subjectId != null : !SUBJECT_ID_EDEFAULT.equals(subjectId);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (objectId: ");
		result.append(objectId);
		result.append(", objectType: ");
		result.append(objectType);
		result.append(", permissionId: ");
		result.append(permissionId);
		result.append(", subjectId: ");
		result.append(subjectId);
		result.append(')');
		return result.toString();
	}

} //SecAccessImpl
