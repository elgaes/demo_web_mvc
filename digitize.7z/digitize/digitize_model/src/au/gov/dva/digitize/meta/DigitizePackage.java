/**
 */
package au.gov.dva.digitize.meta;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see au.gov.dva.digitize.meta.DigitizeFactory
 * @model kind="package"
 * @generated
 */
public interface DigitizePackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "digitize";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://www.dva.gov.au/digitize";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "digitize";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	DigitizePackage eINSTANCE = au.gov.dva.digitize.impl.DigitizePackageImpl.init();

	/**
	 * The meta object id for the '{@link au.gov.dva.digitize.impl.DocumentImpl <em>Document</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see au.gov.dva.digitize.impl.DocumentImpl
	 * @see au.gov.dva.digitize.impl.DigitizePackageImpl#getDocument()
	 * @generated
	 */
	int DOCUMENT = 0;

	/**
	 * The feature id for the '<em><b>Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOCUMENT__ID = 0;

	/**
	 * The feature id for the '<em><b>Proc Status</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOCUMENT__PROC_STATUS = 1;

	/**
	 * The feature id for the '<em><b>Read Status</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOCUMENT__READ_STATUS = 2;

	/**
	 * The feature id for the '<em><b>Title</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOCUMENT__TITLE = 3;

	/**
	 * The feature id for the '<em><b>Ther L1</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOCUMENT__THER_L1 = 4;

	/**
	 * The feature id for the '<em><b>Ther L2</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOCUMENT__THER_L2 = 5;

	/**
	 * The feature id for the '<em><b>Ther L3</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOCUMENT__THER_L3 = 6;

	/**
	 * The feature id for the '<em><b>Ext Ref</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOCUMENT__EXT_REF = 7;

	/**
	 * The feature id for the '<em><b>Bag Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOCUMENT__BAG_ID = 8;

	/**
	 * The feature id for the '<em><b>Envelope Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOCUMENT__ENVELOPE_ID = 9;

	/**
	 * The feature id for the '<em><b>Scan Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOCUMENT__SCAN_ID = 10;

	/**
	 * The feature id for the '<em><b>Scan Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOCUMENT__SCAN_NAME = 11;

	/**
	 * The feature id for the '<em><b>Scan Date</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOCUMENT__SCAN_DATE = 12;

	/**
	 * The feature id for the '<em><b>Archive Box Num</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOCUMENT__ARCHIVE_BOX_NUM = 13;

	/**
	 * The feature id for the '<em><b>Audit Records</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOCUMENT__AUDIT_RECORDS = 14;

	/**
	 * The feature id for the '<em><b>Fileblob</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOCUMENT__FILEBLOB = 15;

	/**
	 * The feature id for the '<em><b>Container</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOCUMENT__CONTAINER = 16;

	/**
	 * The feature id for the '<em><b>ACL</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOCUMENT__ACL = 17;

	/**
	 * The number of structural features of the '<em>Document</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOCUMENT_FEATURE_COUNT = 18;

	/**
	 * The meta object id for the '{@link au.gov.dva.digitize.impl.ContainerImpl <em>Container</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see au.gov.dva.digitize.impl.ContainerImpl
	 * @see au.gov.dva.digitize.impl.DigitizePackageImpl#getContainer()
	 * @generated
	 */
	int CONTAINER = 1;

	/**
	 * The feature id for the '<em><b>Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTAINER__ID = 0;

	/**
	 * The feature id for the '<em><b>Parent Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTAINER__PARENT_ID = 1;

	/**
	 * The feature id for the '<em><b>Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTAINER__TYPE = 2;

	/**
	 * The feature id for the '<em><b>Label</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTAINER__LABEL = 3;

	/**
	 * The feature id for the '<em><b>Ext Ref</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTAINER__EXT_REF = 4;

	/**
	 * The feature id for the '<em><b>Documents</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTAINER__DOCUMENTS = 5;

	/**
	 * The feature id for the '<em><b>ACL</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTAINER__ACL = 6;

	/**
	 * The feature id for the '<em><b>Parent Container</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTAINER__PARENT_CONTAINER = 7;

	/**
	 * The number of structural features of the '<em>Container</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTAINER_FEATURE_COUNT = 8;

	/**
	 * The meta object id for the '{@link au.gov.dva.digitize.impl.ContainedDocImpl <em>Contained Doc</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see au.gov.dva.digitize.impl.ContainedDocImpl
	 * @see au.gov.dva.digitize.impl.DigitizePackageImpl#getContainedDoc()
	 * @generated
	 */
	int CONTAINED_DOC = 2;

	/**
	 * The feature id for the '<em><b>Container Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTAINED_DOC__CONTAINER_ID = 0;

	/**
	 * The feature id for the '<em><b>Doc Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTAINED_DOC__DOC_ID = 1;

	/**
	 * The number of structural features of the '<em>Contained Doc</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTAINED_DOC_FEATURE_COUNT = 2;

	/**
	 * The meta object id for the '{@link au.gov.dva.digitize.impl.FileBlobImpl <em>File Blob</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see au.gov.dva.digitize.impl.FileBlobImpl
	 * @see au.gov.dva.digitize.impl.DigitizePackageImpl#getFileBlob()
	 * @generated
	 */
	int FILE_BLOB = 3;

	/**
	 * The feature id for the '<em><b>Doc Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FILE_BLOB__DOC_ID = 0;

	/**
	 * The feature id for the '<em><b>Blob</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FILE_BLOB__BLOB = 1;

	/**
	 * The feature id for the '<em><b>Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FILE_BLOB__TYPE = 2;

	/**
	 * The number of structural features of the '<em>File Blob</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FILE_BLOB_FEATURE_COUNT = 3;

	/**
	 * The meta object id for the '{@link au.gov.dva.digitize.impl.AuditRecImpl <em>Audit Rec</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see au.gov.dva.digitize.impl.AuditRecImpl
	 * @see au.gov.dva.digitize.impl.DigitizePackageImpl#getAuditRec()
	 * @generated
	 */
	int AUDIT_REC = 4;

	/**
	 * The feature id for the '<em><b>Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AUDIT_REC__ID = 0;

	/**
	 * The feature id for the '<em><b>Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AUDIT_REC__TYPE = 1;

	/**
	 * The feature id for the '<em><b>Object Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AUDIT_REC__OBJECT_ID = 2;

	/**
	 * The feature id for the '<em><b>Object Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AUDIT_REC__OBJECT_TYPE = 3;

	/**
	 * The feature id for the '<em><b>Create Date</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AUDIT_REC__CREATE_DATE = 4;

	/**
	 * The feature id for the '<em><b>Create By</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AUDIT_REC__CREATE_BY = 5;

	/**
	 * The feature id for the '<em><b>Action</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AUDIT_REC__ACTION = 6;

	/**
	 * The feature id for the '<em><b>Details</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AUDIT_REC__DETAILS = 7;

	/**
	 * The number of structural features of the '<em>Audit Rec</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AUDIT_REC_FEATURE_COUNT = 8;

	/**
	 * The meta object id for the '{@link au.gov.dva.digitize.impl.SecAccessImpl <em>Sec Access</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see au.gov.dva.digitize.impl.SecAccessImpl
	 * @see au.gov.dva.digitize.impl.DigitizePackageImpl#getSecAccess()
	 * @generated
	 */
	int SEC_ACCESS = 5;

	/**
	 * The feature id for the '<em><b>Object Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SEC_ACCESS__OBJECT_ID = 0;

	/**
	 * The feature id for the '<em><b>Object Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SEC_ACCESS__OBJECT_TYPE = 1;

	/**
	 * The feature id for the '<em><b>Permission Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SEC_ACCESS__PERMISSION_ID = 2;

	/**
	 * The feature id for the '<em><b>Subject Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SEC_ACCESS__SUBJECT_ID = 3;

	/**
	 * The number of structural features of the '<em>Sec Access</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SEC_ACCESS_FEATURE_COUNT = 4;

	/**
	 * The meta object id for the '{@link au.gov.dva.digitize.impl.SecSubjectImpl <em>Sec Subject</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see au.gov.dva.digitize.impl.SecSubjectImpl
	 * @see au.gov.dva.digitize.impl.DigitizePackageImpl#getSecSubject()
	 * @generated
	 */
	int SEC_SUBJECT = 6;

	/**
	 * The feature id for the '<em><b>Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SEC_SUBJECT__ID = 0;

	/**
	 * The feature id for the '<em><b>Label</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SEC_SUBJECT__LABEL = 1;

	/**
	 * The feature id for the '<em><b>External Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SEC_SUBJECT__EXTERNAL_NAME = 2;

	/**
	 * The feature id for the '<em><b>External Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SEC_SUBJECT__EXTERNAL_ID = 3;

	/**
	 * The feature id for the '<em><b>ACL</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SEC_SUBJECT__ACL = 4;

	/**
	 * The number of structural features of the '<em>Sec Subject</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SEC_SUBJECT_FEATURE_COUNT = 5;

	/**
	 * The meta object id for the '{@link au.gov.dva.digitize.impl.SecPermissionImpl <em>Sec Permission</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see au.gov.dva.digitize.impl.SecPermissionImpl
	 * @see au.gov.dva.digitize.impl.DigitizePackageImpl#getSecPermission()
	 * @generated
	 */
	int SEC_PERMISSION = 7;

	/**
	 * The feature id for the '<em><b>Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SEC_PERMISSION__ID = 0;

	/**
	 * The feature id for the '<em><b>Label</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SEC_PERMISSION__LABEL = 1;

	/**
	 * The feature id for the '<em><b>Object Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SEC_PERMISSION__OBJECT_TYPE = 2;

	/**
	 * The feature id for the '<em><b>ACL</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SEC_PERMISSION__ACL = 3;

	/**
	 * The number of structural features of the '<em>Sec Permission</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SEC_PERMISSION_FEATURE_COUNT = 4;


	/**
	 * Returns the meta object for class '{@link au.gov.dva.digitize.Document <em>Document</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Document</em>'.
	 * @see au.gov.dva.digitize.Document
	 * @generated
	 */
	EClass getDocument();

	/**
	 * Returns the meta object for the attribute '{@link au.gov.dva.digitize.Document#getId <em>Id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Id</em>'.
	 * @see au.gov.dva.digitize.Document#getId()
	 * @see #getDocument()
	 * @generated
	 */
	EAttribute getDocument_Id();

	/**
	 * Returns the meta object for the attribute '{@link au.gov.dva.digitize.Document#getProcStatus <em>Proc Status</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Proc Status</em>'.
	 * @see au.gov.dva.digitize.Document#getProcStatus()
	 * @see #getDocument()
	 * @generated
	 */
	EAttribute getDocument_ProcStatus();

	/**
	 * Returns the meta object for the attribute '{@link au.gov.dva.digitize.Document#getReadStatus <em>Read Status</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Read Status</em>'.
	 * @see au.gov.dva.digitize.Document#getReadStatus()
	 * @see #getDocument()
	 * @generated
	 */
	EAttribute getDocument_ReadStatus();

	/**
	 * Returns the meta object for the attribute '{@link au.gov.dva.digitize.Document#getTitle <em>Title</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Title</em>'.
	 * @see au.gov.dva.digitize.Document#getTitle()
	 * @see #getDocument()
	 * @generated
	 */
	EAttribute getDocument_Title();

	/**
	 * Returns the meta object for the attribute '{@link au.gov.dva.digitize.Document#getTherL1 <em>Ther L1</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Ther L1</em>'.
	 * @see au.gov.dva.digitize.Document#getTherL1()
	 * @see #getDocument()
	 * @generated
	 */
	EAttribute getDocument_TherL1();

	/**
	 * Returns the meta object for the attribute '{@link au.gov.dva.digitize.Document#getTherL2 <em>Ther L2</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Ther L2</em>'.
	 * @see au.gov.dva.digitize.Document#getTherL2()
	 * @see #getDocument()
	 * @generated
	 */
	EAttribute getDocument_TherL2();

	/**
	 * Returns the meta object for the attribute '{@link au.gov.dva.digitize.Document#getTherL3 <em>Ther L3</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Ther L3</em>'.
	 * @see au.gov.dva.digitize.Document#getTherL3()
	 * @see #getDocument()
	 * @generated
	 */
	EAttribute getDocument_TherL3();

	/**
	 * Returns the meta object for the attribute '{@link au.gov.dva.digitize.Document#getExtRef <em>Ext Ref</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Ext Ref</em>'.
	 * @see au.gov.dva.digitize.Document#getExtRef()
	 * @see #getDocument()
	 * @generated
	 */
	EAttribute getDocument_ExtRef();

	/**
	 * Returns the meta object for the attribute '{@link au.gov.dva.digitize.Document#getBagId <em>Bag Id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Bag Id</em>'.
	 * @see au.gov.dva.digitize.Document#getBagId()
	 * @see #getDocument()
	 * @generated
	 */
	EAttribute getDocument_BagId();

	/**
	 * Returns the meta object for the attribute '{@link au.gov.dva.digitize.Document#getEnvelopeId <em>Envelope Id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Envelope Id</em>'.
	 * @see au.gov.dva.digitize.Document#getEnvelopeId()
	 * @see #getDocument()
	 * @generated
	 */
	EAttribute getDocument_EnvelopeId();

	/**
	 * Returns the meta object for the attribute '{@link au.gov.dva.digitize.Document#getScanId <em>Scan Id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Scan Id</em>'.
	 * @see au.gov.dva.digitize.Document#getScanId()
	 * @see #getDocument()
	 * @generated
	 */
	EAttribute getDocument_ScanId();

	/**
	 * Returns the meta object for the attribute '{@link au.gov.dva.digitize.Document#getScanName <em>Scan Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Scan Name</em>'.
	 * @see au.gov.dva.digitize.Document#getScanName()
	 * @see #getDocument()
	 * @generated
	 */
	EAttribute getDocument_ScanName();

	/**
	 * Returns the meta object for the attribute '{@link au.gov.dva.digitize.Document#getScanDate <em>Scan Date</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Scan Date</em>'.
	 * @see au.gov.dva.digitize.Document#getScanDate()
	 * @see #getDocument()
	 * @generated
	 */
	EAttribute getDocument_ScanDate();

	/**
	 * Returns the meta object for the attribute '{@link au.gov.dva.digitize.Document#getArchiveBoxNum <em>Archive Box Num</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Archive Box Num</em>'.
	 * @see au.gov.dva.digitize.Document#getArchiveBoxNum()
	 * @see #getDocument()
	 * @generated
	 */
	EAttribute getDocument_ArchiveBoxNum();

	/**
	 * Returns the meta object for the reference list '{@link au.gov.dva.digitize.Document#getAuditRecords <em>Audit Records</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Audit Records</em>'.
	 * @see au.gov.dva.digitize.Document#getAuditRecords()
	 * @see #getDocument()
	 * @generated
	 */
	EReference getDocument_AuditRecords();

	/**
	 * Returns the meta object for the reference '{@link au.gov.dva.digitize.Document#getFileblob <em>Fileblob</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Fileblob</em>'.
	 * @see au.gov.dva.digitize.Document#getFileblob()
	 * @see #getDocument()
	 * @generated
	 */
	EReference getDocument_Fileblob();

	/**
	 * Returns the meta object for the reference '{@link au.gov.dva.digitize.Document#getContainer <em>Container</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Container</em>'.
	 * @see au.gov.dva.digitize.Document#getContainer()
	 * @see #getDocument()
	 * @generated
	 */
	EReference getDocument_Container();

	/**
	 * Returns the meta object for the reference list '{@link au.gov.dva.digitize.Document#getACL <em>ACL</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>ACL</em>'.
	 * @see au.gov.dva.digitize.Document#getACL()
	 * @see #getDocument()
	 * @generated
	 */
	EReference getDocument_ACL();

	/**
	 * Returns the meta object for class '{@link au.gov.dva.digitize.Container <em>Container</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Container</em>'.
	 * @see au.gov.dva.digitize.Container
	 * @generated
	 */
	EClass getContainer();

	/**
	 * Returns the meta object for the attribute '{@link au.gov.dva.digitize.Container#getId <em>Id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Id</em>'.
	 * @see au.gov.dva.digitize.Container#getId()
	 * @see #getContainer()
	 * @generated
	 */
	EAttribute getContainer_Id();

	/**
	 * Returns the meta object for the attribute '{@link au.gov.dva.digitize.Container#getParentId <em>Parent Id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Parent Id</em>'.
	 * @see au.gov.dva.digitize.Container#getParentId()
	 * @see #getContainer()
	 * @generated
	 */
	EAttribute getContainer_ParentId();

	/**
	 * Returns the meta object for the attribute '{@link au.gov.dva.digitize.Container#getType <em>Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Type</em>'.
	 * @see au.gov.dva.digitize.Container#getType()
	 * @see #getContainer()
	 * @generated
	 */
	EAttribute getContainer_Type();

	/**
	 * Returns the meta object for the attribute '{@link au.gov.dva.digitize.Container#getLabel <em>Label</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Label</em>'.
	 * @see au.gov.dva.digitize.Container#getLabel()
	 * @see #getContainer()
	 * @generated
	 */
	EAttribute getContainer_Label();

	/**
	 * Returns the meta object for the attribute '{@link au.gov.dva.digitize.Container#getExtRef <em>Ext Ref</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Ext Ref</em>'.
	 * @see au.gov.dva.digitize.Container#getExtRef()
	 * @see #getContainer()
	 * @generated
	 */
	EAttribute getContainer_ExtRef();

	/**
	 * Returns the meta object for the reference list '{@link au.gov.dva.digitize.Container#getDocuments <em>Documents</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Documents</em>'.
	 * @see au.gov.dva.digitize.Container#getDocuments()
	 * @see #getContainer()
	 * @generated
	 */
	EReference getContainer_Documents();

	/**
	 * Returns the meta object for the reference list '{@link au.gov.dva.digitize.Container#getACL <em>ACL</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>ACL</em>'.
	 * @see au.gov.dva.digitize.Container#getACL()
	 * @see #getContainer()
	 * @generated
	 */
	EReference getContainer_ACL();

	/**
	 * Returns the meta object for the reference '{@link au.gov.dva.digitize.Container#getParentContainer <em>Parent Container</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Parent Container</em>'.
	 * @see au.gov.dva.digitize.Container#getParentContainer()
	 * @see #getContainer()
	 * @generated
	 */
	EReference getContainer_ParentContainer();

	/**
	 * Returns the meta object for class '{@link au.gov.dva.digitize.ContainedDoc <em>Contained Doc</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Contained Doc</em>'.
	 * @see au.gov.dva.digitize.ContainedDoc
	 * @generated
	 */
	EClass getContainedDoc();

	/**
	 * Returns the meta object for the attribute '{@link au.gov.dva.digitize.ContainedDoc#getContainerId <em>Container Id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Container Id</em>'.
	 * @see au.gov.dva.digitize.ContainedDoc#getContainerId()
	 * @see #getContainedDoc()
	 * @generated
	 */
	EAttribute getContainedDoc_ContainerId();

	/**
	 * Returns the meta object for the attribute '{@link au.gov.dva.digitize.ContainedDoc#getDocId <em>Doc Id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Doc Id</em>'.
	 * @see au.gov.dva.digitize.ContainedDoc#getDocId()
	 * @see #getContainedDoc()
	 * @generated
	 */
	EAttribute getContainedDoc_DocId();

	/**
	 * Returns the meta object for class '{@link au.gov.dva.digitize.FileBlob <em>File Blob</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>File Blob</em>'.
	 * @see au.gov.dva.digitize.FileBlob
	 * @generated
	 */
	EClass getFileBlob();

	/**
	 * Returns the meta object for the attribute '{@link au.gov.dva.digitize.FileBlob#getDocId <em>Doc Id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Doc Id</em>'.
	 * @see au.gov.dva.digitize.FileBlob#getDocId()
	 * @see #getFileBlob()
	 * @generated
	 */
	EAttribute getFileBlob_DocId();

	/**
	 * Returns the meta object for the attribute '{@link au.gov.dva.digitize.FileBlob#getBlob <em>Blob</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Blob</em>'.
	 * @see au.gov.dva.digitize.FileBlob#getBlob()
	 * @see #getFileBlob()
	 * @generated
	 */
	EAttribute getFileBlob_Blob();

	/**
	 * Returns the meta object for the attribute '{@link au.gov.dva.digitize.FileBlob#getType <em>Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Type</em>'.
	 * @see au.gov.dva.digitize.FileBlob#getType()
	 * @see #getFileBlob()
	 * @generated
	 */
	EAttribute getFileBlob_Type();

	/**
	 * Returns the meta object for class '{@link au.gov.dva.digitize.AuditRec <em>Audit Rec</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Audit Rec</em>'.
	 * @see au.gov.dva.digitize.AuditRec
	 * @generated
	 */
	EClass getAuditRec();

	/**
	 * Returns the meta object for the attribute '{@link au.gov.dva.digitize.AuditRec#getId <em>Id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Id</em>'.
	 * @see au.gov.dva.digitize.AuditRec#getId()
	 * @see #getAuditRec()
	 * @generated
	 */
	EAttribute getAuditRec_Id();

	/**
	 * Returns the meta object for the attribute '{@link au.gov.dva.digitize.AuditRec#getType <em>Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Type</em>'.
	 * @see au.gov.dva.digitize.AuditRec#getType()
	 * @see #getAuditRec()
	 * @generated
	 */
	EAttribute getAuditRec_Type();

	/**
	 * Returns the meta object for the attribute '{@link au.gov.dva.digitize.AuditRec#getObjectId <em>Object Id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Object Id</em>'.
	 * @see au.gov.dva.digitize.AuditRec#getObjectId()
	 * @see #getAuditRec()
	 * @generated
	 */
	EAttribute getAuditRec_ObjectId();

	/**
	 * Returns the meta object for the attribute '{@link au.gov.dva.digitize.AuditRec#getObjectType <em>Object Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Object Type</em>'.
	 * @see au.gov.dva.digitize.AuditRec#getObjectType()
	 * @see #getAuditRec()
	 * @generated
	 */
	EAttribute getAuditRec_ObjectType();

	/**
	 * Returns the meta object for the attribute '{@link au.gov.dva.digitize.AuditRec#getCreateDate <em>Create Date</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Create Date</em>'.
	 * @see au.gov.dva.digitize.AuditRec#getCreateDate()
	 * @see #getAuditRec()
	 * @generated
	 */
	EAttribute getAuditRec_CreateDate();

	/**
	 * Returns the meta object for the attribute '{@link au.gov.dva.digitize.AuditRec#getCreateBy <em>Create By</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Create By</em>'.
	 * @see au.gov.dva.digitize.AuditRec#getCreateBy()
	 * @see #getAuditRec()
	 * @generated
	 */
	EAttribute getAuditRec_CreateBy();

	/**
	 * Returns the meta object for the attribute '{@link au.gov.dva.digitize.AuditRec#getAction <em>Action</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Action</em>'.
	 * @see au.gov.dva.digitize.AuditRec#getAction()
	 * @see #getAuditRec()
	 * @generated
	 */
	EAttribute getAuditRec_Action();

	/**
	 * Returns the meta object for the attribute '{@link au.gov.dva.digitize.AuditRec#getDetails <em>Details</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Details</em>'.
	 * @see au.gov.dva.digitize.AuditRec#getDetails()
	 * @see #getAuditRec()
	 * @generated
	 */
	EAttribute getAuditRec_Details();

	/**
	 * Returns the meta object for class '{@link au.gov.dva.digitize.SecAccess <em>Sec Access</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Sec Access</em>'.
	 * @see au.gov.dva.digitize.SecAccess
	 * @generated
	 */
	EClass getSecAccess();

	/**
	 * Returns the meta object for the attribute '{@link au.gov.dva.digitize.SecAccess#getObjectId <em>Object Id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Object Id</em>'.
	 * @see au.gov.dva.digitize.SecAccess#getObjectId()
	 * @see #getSecAccess()
	 * @generated
	 */
	EAttribute getSecAccess_ObjectId();

	/**
	 * Returns the meta object for the attribute '{@link au.gov.dva.digitize.SecAccess#getObjectType <em>Object Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Object Type</em>'.
	 * @see au.gov.dva.digitize.SecAccess#getObjectType()
	 * @see #getSecAccess()
	 * @generated
	 */
	EAttribute getSecAccess_ObjectType();

	/**
	 * Returns the meta object for the attribute '{@link au.gov.dva.digitize.SecAccess#getPermissionId <em>Permission Id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Permission Id</em>'.
	 * @see au.gov.dva.digitize.SecAccess#getPermissionId()
	 * @see #getSecAccess()
	 * @generated
	 */
	EAttribute getSecAccess_PermissionId();

	/**
	 * Returns the meta object for the attribute '{@link au.gov.dva.digitize.SecAccess#getSubjectId <em>Subject Id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Subject Id</em>'.
	 * @see au.gov.dva.digitize.SecAccess#getSubjectId()
	 * @see #getSecAccess()
	 * @generated
	 */
	EAttribute getSecAccess_SubjectId();

	/**
	 * Returns the meta object for class '{@link au.gov.dva.digitize.SecSubject <em>Sec Subject</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Sec Subject</em>'.
	 * @see au.gov.dva.digitize.SecSubject
	 * @generated
	 */
	EClass getSecSubject();

	/**
	 * Returns the meta object for the attribute '{@link au.gov.dva.digitize.SecSubject#getId <em>Id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Id</em>'.
	 * @see au.gov.dva.digitize.SecSubject#getId()
	 * @see #getSecSubject()
	 * @generated
	 */
	EAttribute getSecSubject_Id();

	/**
	 * Returns the meta object for the attribute '{@link au.gov.dva.digitize.SecSubject#getLabel <em>Label</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Label</em>'.
	 * @see au.gov.dva.digitize.SecSubject#getLabel()
	 * @see #getSecSubject()
	 * @generated
	 */
	EAttribute getSecSubject_Label();

	/**
	 * Returns the meta object for the attribute '{@link au.gov.dva.digitize.SecSubject#getExternalName <em>External Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>External Name</em>'.
	 * @see au.gov.dva.digitize.SecSubject#getExternalName()
	 * @see #getSecSubject()
	 * @generated
	 */
	EAttribute getSecSubject_ExternalName();

	/**
	 * Returns the meta object for the attribute '{@link au.gov.dva.digitize.SecSubject#getExternalId <em>External Id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>External Id</em>'.
	 * @see au.gov.dva.digitize.SecSubject#getExternalId()
	 * @see #getSecSubject()
	 * @generated
	 */
	EAttribute getSecSubject_ExternalId();

	/**
	 * Returns the meta object for the reference list '{@link au.gov.dva.digitize.SecSubject#getACL <em>ACL</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>ACL</em>'.
	 * @see au.gov.dva.digitize.SecSubject#getACL()
	 * @see #getSecSubject()
	 * @generated
	 */
	EReference getSecSubject_ACL();

	/**
	 * Returns the meta object for class '{@link au.gov.dva.digitize.SecPermission <em>Sec Permission</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Sec Permission</em>'.
	 * @see au.gov.dva.digitize.SecPermission
	 * @generated
	 */
	EClass getSecPermission();

	/**
	 * Returns the meta object for the attribute '{@link au.gov.dva.digitize.SecPermission#getId <em>Id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Id</em>'.
	 * @see au.gov.dva.digitize.SecPermission#getId()
	 * @see #getSecPermission()
	 * @generated
	 */
	EAttribute getSecPermission_Id();

	/**
	 * Returns the meta object for the attribute '{@link au.gov.dva.digitize.SecPermission#getLabel <em>Label</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Label</em>'.
	 * @see au.gov.dva.digitize.SecPermission#getLabel()
	 * @see #getSecPermission()
	 * @generated
	 */
	EAttribute getSecPermission_Label();

	/**
	 * Returns the meta object for the attribute '{@link au.gov.dva.digitize.SecPermission#getObjectType <em>Object Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Object Type</em>'.
	 * @see au.gov.dva.digitize.SecPermission#getObjectType()
	 * @see #getSecPermission()
	 * @generated
	 */
	EAttribute getSecPermission_ObjectType();

	/**
	 * Returns the meta object for the reference list '{@link au.gov.dva.digitize.SecPermission#getACL <em>ACL</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>ACL</em>'.
	 * @see au.gov.dva.digitize.SecPermission#getACL()
	 * @see #getSecPermission()
	 * @generated
	 */
	EReference getSecPermission_ACL();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	DigitizeFactory getDigitizeFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link au.gov.dva.digitize.impl.DocumentImpl <em>Document</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see au.gov.dva.digitize.impl.DocumentImpl
		 * @see au.gov.dva.digitize.impl.DigitizePackageImpl#getDocument()
		 * @generated
		 */
		EClass DOCUMENT = eINSTANCE.getDocument();

		/**
		 * The meta object literal for the '<em><b>Id</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DOCUMENT__ID = eINSTANCE.getDocument_Id();

		/**
		 * The meta object literal for the '<em><b>Proc Status</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DOCUMENT__PROC_STATUS = eINSTANCE.getDocument_ProcStatus();

		/**
		 * The meta object literal for the '<em><b>Read Status</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DOCUMENT__READ_STATUS = eINSTANCE.getDocument_ReadStatus();

		/**
		 * The meta object literal for the '<em><b>Title</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DOCUMENT__TITLE = eINSTANCE.getDocument_Title();

		/**
		 * The meta object literal for the '<em><b>Ther L1</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DOCUMENT__THER_L1 = eINSTANCE.getDocument_TherL1();

		/**
		 * The meta object literal for the '<em><b>Ther L2</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DOCUMENT__THER_L2 = eINSTANCE.getDocument_TherL2();

		/**
		 * The meta object literal for the '<em><b>Ther L3</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DOCUMENT__THER_L3 = eINSTANCE.getDocument_TherL3();

		/**
		 * The meta object literal for the '<em><b>Ext Ref</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DOCUMENT__EXT_REF = eINSTANCE.getDocument_ExtRef();

		/**
		 * The meta object literal for the '<em><b>Bag Id</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DOCUMENT__BAG_ID = eINSTANCE.getDocument_BagId();

		/**
		 * The meta object literal for the '<em><b>Envelope Id</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DOCUMENT__ENVELOPE_ID = eINSTANCE.getDocument_EnvelopeId();

		/**
		 * The meta object literal for the '<em><b>Scan Id</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DOCUMENT__SCAN_ID = eINSTANCE.getDocument_ScanId();

		/**
		 * The meta object literal for the '<em><b>Scan Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DOCUMENT__SCAN_NAME = eINSTANCE.getDocument_ScanName();

		/**
		 * The meta object literal for the '<em><b>Scan Date</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DOCUMENT__SCAN_DATE = eINSTANCE.getDocument_ScanDate();

		/**
		 * The meta object literal for the '<em><b>Archive Box Num</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DOCUMENT__ARCHIVE_BOX_NUM = eINSTANCE.getDocument_ArchiveBoxNum();

		/**
		 * The meta object literal for the '<em><b>Audit Records</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DOCUMENT__AUDIT_RECORDS = eINSTANCE.getDocument_AuditRecords();

		/**
		 * The meta object literal for the '<em><b>Fileblob</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DOCUMENT__FILEBLOB = eINSTANCE.getDocument_Fileblob();

		/**
		 * The meta object literal for the '<em><b>Container</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DOCUMENT__CONTAINER = eINSTANCE.getDocument_Container();

		/**
		 * The meta object literal for the '<em><b>ACL</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DOCUMENT__ACL = eINSTANCE.getDocument_ACL();

		/**
		 * The meta object literal for the '{@link au.gov.dva.digitize.impl.ContainerImpl <em>Container</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see au.gov.dva.digitize.impl.ContainerImpl
		 * @see au.gov.dva.digitize.impl.DigitizePackageImpl#getContainer()
		 * @generated
		 */
		EClass CONTAINER = eINSTANCE.getContainer();

		/**
		 * The meta object literal for the '<em><b>Id</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CONTAINER__ID = eINSTANCE.getContainer_Id();

		/**
		 * The meta object literal for the '<em><b>Parent Id</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CONTAINER__PARENT_ID = eINSTANCE.getContainer_ParentId();

		/**
		 * The meta object literal for the '<em><b>Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CONTAINER__TYPE = eINSTANCE.getContainer_Type();

		/**
		 * The meta object literal for the '<em><b>Label</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CONTAINER__LABEL = eINSTANCE.getContainer_Label();

		/**
		 * The meta object literal for the '<em><b>Ext Ref</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CONTAINER__EXT_REF = eINSTANCE.getContainer_ExtRef();

		/**
		 * The meta object literal for the '<em><b>Documents</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CONTAINER__DOCUMENTS = eINSTANCE.getContainer_Documents();

		/**
		 * The meta object literal for the '<em><b>ACL</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CONTAINER__ACL = eINSTANCE.getContainer_ACL();

		/**
		 * The meta object literal for the '<em><b>Parent Container</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CONTAINER__PARENT_CONTAINER = eINSTANCE.getContainer_ParentContainer();

		/**
		 * The meta object literal for the '{@link au.gov.dva.digitize.impl.ContainedDocImpl <em>Contained Doc</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see au.gov.dva.digitize.impl.ContainedDocImpl
		 * @see au.gov.dva.digitize.impl.DigitizePackageImpl#getContainedDoc()
		 * @generated
		 */
		EClass CONTAINED_DOC = eINSTANCE.getContainedDoc();

		/**
		 * The meta object literal for the '<em><b>Container Id</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CONTAINED_DOC__CONTAINER_ID = eINSTANCE.getContainedDoc_ContainerId();

		/**
		 * The meta object literal for the '<em><b>Doc Id</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CONTAINED_DOC__DOC_ID = eINSTANCE.getContainedDoc_DocId();

		/**
		 * The meta object literal for the '{@link au.gov.dva.digitize.impl.FileBlobImpl <em>File Blob</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see au.gov.dva.digitize.impl.FileBlobImpl
		 * @see au.gov.dva.digitize.impl.DigitizePackageImpl#getFileBlob()
		 * @generated
		 */
		EClass FILE_BLOB = eINSTANCE.getFileBlob();

		/**
		 * The meta object literal for the '<em><b>Doc Id</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute FILE_BLOB__DOC_ID = eINSTANCE.getFileBlob_DocId();

		/**
		 * The meta object literal for the '<em><b>Blob</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute FILE_BLOB__BLOB = eINSTANCE.getFileBlob_Blob();

		/**
		 * The meta object literal for the '<em><b>Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute FILE_BLOB__TYPE = eINSTANCE.getFileBlob_Type();

		/**
		 * The meta object literal for the '{@link au.gov.dva.digitize.impl.AuditRecImpl <em>Audit Rec</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see au.gov.dva.digitize.impl.AuditRecImpl
		 * @see au.gov.dva.digitize.impl.DigitizePackageImpl#getAuditRec()
		 * @generated
		 */
		EClass AUDIT_REC = eINSTANCE.getAuditRec();

		/**
		 * The meta object literal for the '<em><b>Id</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute AUDIT_REC__ID = eINSTANCE.getAuditRec_Id();

		/**
		 * The meta object literal for the '<em><b>Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute AUDIT_REC__TYPE = eINSTANCE.getAuditRec_Type();

		/**
		 * The meta object literal for the '<em><b>Object Id</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute AUDIT_REC__OBJECT_ID = eINSTANCE.getAuditRec_ObjectId();

		/**
		 * The meta object literal for the '<em><b>Object Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute AUDIT_REC__OBJECT_TYPE = eINSTANCE.getAuditRec_ObjectType();

		/**
		 * The meta object literal for the '<em><b>Create Date</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute AUDIT_REC__CREATE_DATE = eINSTANCE.getAuditRec_CreateDate();

		/**
		 * The meta object literal for the '<em><b>Create By</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute AUDIT_REC__CREATE_BY = eINSTANCE.getAuditRec_CreateBy();

		/**
		 * The meta object literal for the '<em><b>Action</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute AUDIT_REC__ACTION = eINSTANCE.getAuditRec_Action();

		/**
		 * The meta object literal for the '<em><b>Details</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute AUDIT_REC__DETAILS = eINSTANCE.getAuditRec_Details();

		/**
		 * The meta object literal for the '{@link au.gov.dva.digitize.impl.SecAccessImpl <em>Sec Access</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see au.gov.dva.digitize.impl.SecAccessImpl
		 * @see au.gov.dva.digitize.impl.DigitizePackageImpl#getSecAccess()
		 * @generated
		 */
		EClass SEC_ACCESS = eINSTANCE.getSecAccess();

		/**
		 * The meta object literal for the '<em><b>Object Id</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SEC_ACCESS__OBJECT_ID = eINSTANCE.getSecAccess_ObjectId();

		/**
		 * The meta object literal for the '<em><b>Object Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SEC_ACCESS__OBJECT_TYPE = eINSTANCE.getSecAccess_ObjectType();

		/**
		 * The meta object literal for the '<em><b>Permission Id</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SEC_ACCESS__PERMISSION_ID = eINSTANCE.getSecAccess_PermissionId();

		/**
		 * The meta object literal for the '<em><b>Subject Id</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SEC_ACCESS__SUBJECT_ID = eINSTANCE.getSecAccess_SubjectId();

		/**
		 * The meta object literal for the '{@link au.gov.dva.digitize.impl.SecSubjectImpl <em>Sec Subject</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see au.gov.dva.digitize.impl.SecSubjectImpl
		 * @see au.gov.dva.digitize.impl.DigitizePackageImpl#getSecSubject()
		 * @generated
		 */
		EClass SEC_SUBJECT = eINSTANCE.getSecSubject();

		/**
		 * The meta object literal for the '<em><b>Id</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SEC_SUBJECT__ID = eINSTANCE.getSecSubject_Id();

		/**
		 * The meta object literal for the '<em><b>Label</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SEC_SUBJECT__LABEL = eINSTANCE.getSecSubject_Label();

		/**
		 * The meta object literal for the '<em><b>External Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SEC_SUBJECT__EXTERNAL_NAME = eINSTANCE.getSecSubject_ExternalName();

		/**
		 * The meta object literal for the '<em><b>External Id</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SEC_SUBJECT__EXTERNAL_ID = eINSTANCE.getSecSubject_ExternalId();

		/**
		 * The meta object literal for the '<em><b>ACL</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SEC_SUBJECT__ACL = eINSTANCE.getSecSubject_ACL();

		/**
		 * The meta object literal for the '{@link au.gov.dva.digitize.impl.SecPermissionImpl <em>Sec Permission</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see au.gov.dva.digitize.impl.SecPermissionImpl
		 * @see au.gov.dva.digitize.impl.DigitizePackageImpl#getSecPermission()
		 * @generated
		 */
		EClass SEC_PERMISSION = eINSTANCE.getSecPermission();

		/**
		 * The meta object literal for the '<em><b>Id</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SEC_PERMISSION__ID = eINSTANCE.getSecPermission_Id();

		/**
		 * The meta object literal for the '<em><b>Label</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SEC_PERMISSION__LABEL = eINSTANCE.getSecPermission_Label();

		/**
		 * The meta object literal for the '<em><b>Object Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SEC_PERMISSION__OBJECT_TYPE = eINSTANCE.getSecPermission_ObjectType();

		/**
		 * The meta object literal for the '<em><b>ACL</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SEC_PERMISSION__ACL = eINSTANCE.getSecPermission_ACL();

	}

} //DigitizePackage
