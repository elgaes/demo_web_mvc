/**
 */
package au.gov.dva.digitize;

import java.util.Date;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Audit Rec</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link au.gov.dva.digitize.AuditRec#getId <em>Id</em>}</li>
 *   <li>{@link au.gov.dva.digitize.AuditRec#getType <em>Type</em>}</li>
 *   <li>{@link au.gov.dva.digitize.AuditRec#getObjectId <em>Object Id</em>}</li>
 *   <li>{@link au.gov.dva.digitize.AuditRec#getObjectType <em>Object Type</em>}</li>
 *   <li>{@link au.gov.dva.digitize.AuditRec#getCreateDate <em>Create Date</em>}</li>
 *   <li>{@link au.gov.dva.digitize.AuditRec#getCreateBy <em>Create By</em>}</li>
 *   <li>{@link au.gov.dva.digitize.AuditRec#getAction <em>Action</em>}</li>
 *   <li>{@link au.gov.dva.digitize.AuditRec#getDetails <em>Details</em>}</li>
 * </ul>
 *
 * @see au.gov.dva.digitize.meta.DigitizePackage#getAuditRec()
 * @model
 * @generated
 */
public interface AuditRec extends EObject {
	/**
	 * Returns the value of the '<em><b>Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Id</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Id</em>' attribute.
	 * @see #isSetId()
	 * @see au.gov.dva.digitize.meta.DigitizePackage#getAuditRec_Id()
	 * @model unsettable="true" id="true" required="true" changeable="false" ordered="false"
	 * @generated
	 */
	int getId();

	/**
	 * Returns whether the value of the '{@link au.gov.dva.digitize.AuditRec#getId <em>Id</em>}' attribute is set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return whether the value of the '<em>Id</em>' attribute is set.
	 * @see #getId()
	 * @generated
	 */
	boolean isSetId();

	/**
	 * Returns the value of the '<em><b>Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Type</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Type</em>' attribute.
	 * @see #setType(String)
	 * @see au.gov.dva.digitize.meta.DigitizePackage#getAuditRec_Type()
	 * @model required="true"
	 * @generated
	 */
	String getType();

	/**
	 * Sets the value of the '{@link au.gov.dva.digitize.AuditRec#getType <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Type</em>' attribute.
	 * @see #getType()
	 * @generated
	 */
	void setType(String value);

	/**
	 * Returns the value of the '<em><b>Object Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Object Id</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Object Id</em>' attribute.
	 * @see #setObjectId(int)
	 * @see au.gov.dva.digitize.meta.DigitizePackage#getAuditRec_ObjectId()
	 * @model required="true"
	 * @generated
	 */
	int getObjectId();

	/**
	 * Sets the value of the '{@link au.gov.dva.digitize.AuditRec#getObjectId <em>Object Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Object Id</em>' attribute.
	 * @see #getObjectId()
	 * @generated
	 */
	void setObjectId(int value);

	/**
	 * Returns the value of the '<em><b>Object Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * The Object Type this audit record associated with e.g. DOCUMENT, CONTAINER etc.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Object Type</em>' attribute.
	 * @see #setObjectType(String)
	 * @see au.gov.dva.digitize.meta.DigitizePackage#getAuditRec_ObjectType()
	 * @model required="true"
	 * @generated
	 */
	String getObjectType();

	/**
	 * Sets the value of the '{@link au.gov.dva.digitize.AuditRec#getObjectType <em>Object Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Object Type</em>' attribute.
	 * @see #getObjectType()
	 * @generated
	 */
	void setObjectType(String value);

	/**
	 * Returns the value of the '<em><b>Create Date</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Create Date</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Create Date</em>' attribute.
	 * @see #setCreateDate(Date)
	 * @see au.gov.dva.digitize.meta.DigitizePackage#getAuditRec_CreateDate()
	 * @model required="true"
	 * @generated
	 */
	Date getCreateDate();

	/**
	 * Sets the value of the '{@link au.gov.dva.digitize.AuditRec#getCreateDate <em>Create Date</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Create Date</em>' attribute.
	 * @see #getCreateDate()
	 * @generated
	 */
	void setCreateDate(Date value);

	/**
	 * Returns the value of the '<em><b>Create By</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Create By</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Create By</em>' attribute.
	 * @see #setCreateBy(String)
	 * @see au.gov.dva.digitize.meta.DigitizePackage#getAuditRec_CreateBy()
	 * @model required="true"
	 * @generated
	 */
	String getCreateBy();

	/**
	 * Sets the value of the '{@link au.gov.dva.digitize.AuditRec#getCreateBy <em>Create By</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Create By</em>' attribute.
	 * @see #getCreateBy()
	 * @generated
	 */
	void setCreateBy(String value);

	/**
	 * Returns the value of the '<em><b>Action</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Action</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Action</em>' attribute.
	 * @see #setAction(String)
	 * @see au.gov.dva.digitize.meta.DigitizePackage#getAuditRec_Action()
	 * @model required="true"
	 * @generated
	 */
	String getAction();

	/**
	 * Sets the value of the '{@link au.gov.dva.digitize.AuditRec#getAction <em>Action</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Action</em>' attribute.
	 * @see #getAction()
	 * @generated
	 */
	void setAction(String value);

	/**
	 * Returns the value of the '<em><b>Details</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Details</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Details</em>' attribute.
	 * @see #setDetails(String)
	 * @see au.gov.dva.digitize.meta.DigitizePackage#getAuditRec_Details()
	 * @model required="true"
	 * @generated
	 */
	String getDetails();

	/**
	 * Sets the value of the '{@link au.gov.dva.digitize.AuditRec#getDetails <em>Details</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Details</em>' attribute.
	 * @see #getDetails()
	 * @generated
	 */
	void setDetails(String value);

} // AuditRec
