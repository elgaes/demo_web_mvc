/**
 */
package au.gov.dva.digitize.impl;

import au.gov.dva.digitize.AuditRec;

import au.gov.dva.digitize.meta.DigitizePackage;

import java.util.Date;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Audit Rec</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link au.gov.dva.digitize.impl.AuditRecImpl#getId <em>Id</em>}</li>
 *   <li>{@link au.gov.dva.digitize.impl.AuditRecImpl#getType <em>Type</em>}</li>
 *   <li>{@link au.gov.dva.digitize.impl.AuditRecImpl#getObjectId <em>Object Id</em>}</li>
 *   <li>{@link au.gov.dva.digitize.impl.AuditRecImpl#getObjectType <em>Object Type</em>}</li>
 *   <li>{@link au.gov.dva.digitize.impl.AuditRecImpl#getCreateDate <em>Create Date</em>}</li>
 *   <li>{@link au.gov.dva.digitize.impl.AuditRecImpl#getCreateBy <em>Create By</em>}</li>
 *   <li>{@link au.gov.dva.digitize.impl.AuditRecImpl#getAction <em>Action</em>}</li>
 *   <li>{@link au.gov.dva.digitize.impl.AuditRecImpl#getDetails <em>Details</em>}</li>
 * </ul>
 *
 * @generated
 */
public class AuditRecImpl extends MinimalEObjectImpl.Container implements AuditRec {
	/**
	 * The default value of the '{@link #getId() <em>Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getId()
	 * @generated
	 * @ordered
	 */
	protected static final int ID_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getId() <em>Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getId()
	 * @generated
	 * @ordered
	 */
	protected int id = ID_EDEFAULT;

	/**
	 * This is true if the Id attribute has been set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	protected boolean idESet;

	/**
	 * The default value of the '{@link #getType() <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getType()
	 * @generated
	 * @ordered
	 */
	protected static final String TYPE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getType() <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getType()
	 * @generated
	 * @ordered
	 */
	protected String type = TYPE_EDEFAULT;

	/**
	 * The default value of the '{@link #getObjectId() <em>Object Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getObjectId()
	 * @generated
	 * @ordered
	 */
	protected static final int OBJECT_ID_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getObjectId() <em>Object Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getObjectId()
	 * @generated
	 * @ordered
	 */
	protected int objectId = OBJECT_ID_EDEFAULT;

	/**
	 * The default value of the '{@link #getObjectType() <em>Object Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getObjectType()
	 * @generated
	 * @ordered
	 */
	protected static final String OBJECT_TYPE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getObjectType() <em>Object Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getObjectType()
	 * @generated
	 * @ordered
	 */
	protected String objectType = OBJECT_TYPE_EDEFAULT;

	/**
	 * The default value of the '{@link #getCreateDate() <em>Create Date</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCreateDate()
	 * @generated
	 * @ordered
	 */
	protected static final Date CREATE_DATE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getCreateDate() <em>Create Date</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCreateDate()
	 * @generated
	 * @ordered
	 */
	protected Date createDate = CREATE_DATE_EDEFAULT;

	/**
	 * The default value of the '{@link #getCreateBy() <em>Create By</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCreateBy()
	 * @generated
	 * @ordered
	 */
	protected static final String CREATE_BY_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getCreateBy() <em>Create By</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCreateBy()
	 * @generated
	 * @ordered
	 */
	protected String createBy = CREATE_BY_EDEFAULT;

	/**
	 * The default value of the '{@link #getAction() <em>Action</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAction()
	 * @generated
	 * @ordered
	 */
	protected static final String ACTION_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getAction() <em>Action</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAction()
	 * @generated
	 * @ordered
	 */
	protected String action = ACTION_EDEFAULT;

	/**
	 * The default value of the '{@link #getDetails() <em>Details</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDetails()
	 * @generated
	 * @ordered
	 */
	protected static final String DETAILS_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getDetails() <em>Details</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDetails()
	 * @generated
	 * @ordered
	 */
	protected String details = DETAILS_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected AuditRecImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return DigitizePackage.Literals.AUDIT_REC;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getId() {
		return id;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isSetId() {
		return idESet;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getType() {
		return type;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setType(String newType) {
		String oldType = type;
		type = newType;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, DigitizePackage.AUDIT_REC__TYPE, oldType, type));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getObjectId() {
		return objectId;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setObjectId(int newObjectId) {
		int oldObjectId = objectId;
		objectId = newObjectId;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, DigitizePackage.AUDIT_REC__OBJECT_ID, oldObjectId, objectId));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getObjectType() {
		return objectType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setObjectType(String newObjectType) {
		String oldObjectType = objectType;
		objectType = newObjectType;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, DigitizePackage.AUDIT_REC__OBJECT_TYPE, oldObjectType, objectType));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Date getCreateDate() {
		return createDate;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setCreateDate(Date newCreateDate) {
		Date oldCreateDate = createDate;
		createDate = newCreateDate;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, DigitizePackage.AUDIT_REC__CREATE_DATE, oldCreateDate, createDate));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getCreateBy() {
		return createBy;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setCreateBy(String newCreateBy) {
		String oldCreateBy = createBy;
		createBy = newCreateBy;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, DigitizePackage.AUDIT_REC__CREATE_BY, oldCreateBy, createBy));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getAction() {
		return action;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAction(String newAction) {
		String oldAction = action;
		action = newAction;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, DigitizePackage.AUDIT_REC__ACTION, oldAction, action));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getDetails() {
		return details;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setDetails(String newDetails) {
		String oldDetails = details;
		details = newDetails;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, DigitizePackage.AUDIT_REC__DETAILS, oldDetails, details));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case DigitizePackage.AUDIT_REC__ID:
				return new Integer(getId());
			case DigitizePackage.AUDIT_REC__TYPE:
				return getType();
			case DigitizePackage.AUDIT_REC__OBJECT_ID:
				return new Integer(getObjectId());
			case DigitizePackage.AUDIT_REC__OBJECT_TYPE:
				return getObjectType();
			case DigitizePackage.AUDIT_REC__CREATE_DATE:
				return getCreateDate();
			case DigitizePackage.AUDIT_REC__CREATE_BY:
				return getCreateBy();
			case DigitizePackage.AUDIT_REC__ACTION:
				return getAction();
			case DigitizePackage.AUDIT_REC__DETAILS:
				return getDetails();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case DigitizePackage.AUDIT_REC__TYPE:
				setType((String)newValue);
				return;
			case DigitizePackage.AUDIT_REC__OBJECT_ID:
				setObjectId(((Integer)newValue).intValue());
				return;
			case DigitizePackage.AUDIT_REC__OBJECT_TYPE:
				setObjectType((String)newValue);
				return;
			case DigitizePackage.AUDIT_REC__CREATE_DATE:
				setCreateDate((Date)newValue);
				return;
			case DigitizePackage.AUDIT_REC__CREATE_BY:
				setCreateBy((String)newValue);
				return;
			case DigitizePackage.AUDIT_REC__ACTION:
				setAction((String)newValue);
				return;
			case DigitizePackage.AUDIT_REC__DETAILS:
				setDetails((String)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eUnset(int featureID) {
		switch (featureID) {
			case DigitizePackage.AUDIT_REC__TYPE:
				setType(TYPE_EDEFAULT);
				return;
			case DigitizePackage.AUDIT_REC__OBJECT_ID:
				setObjectId(OBJECT_ID_EDEFAULT);
				return;
			case DigitizePackage.AUDIT_REC__OBJECT_TYPE:
				setObjectType(OBJECT_TYPE_EDEFAULT);
				return;
			case DigitizePackage.AUDIT_REC__CREATE_DATE:
				setCreateDate(CREATE_DATE_EDEFAULT);
				return;
			case DigitizePackage.AUDIT_REC__CREATE_BY:
				setCreateBy(CREATE_BY_EDEFAULT);
				return;
			case DigitizePackage.AUDIT_REC__ACTION:
				setAction(ACTION_EDEFAULT);
				return;
			case DigitizePackage.AUDIT_REC__DETAILS:
				setDetails(DETAILS_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case DigitizePackage.AUDIT_REC__ID:
				return isSetId();
			case DigitizePackage.AUDIT_REC__TYPE:
				return TYPE_EDEFAULT == null ? type != null : !TYPE_EDEFAULT.equals(type);
			case DigitizePackage.AUDIT_REC__OBJECT_ID:
				return objectId != OBJECT_ID_EDEFAULT;
			case DigitizePackage.AUDIT_REC__OBJECT_TYPE:
				return OBJECT_TYPE_EDEFAULT == null ? objectType != null : !OBJECT_TYPE_EDEFAULT.equals(objectType);
			case DigitizePackage.AUDIT_REC__CREATE_DATE:
				return CREATE_DATE_EDEFAULT == null ? createDate != null : !CREATE_DATE_EDEFAULT.equals(createDate);
			case DigitizePackage.AUDIT_REC__CREATE_BY:
				return CREATE_BY_EDEFAULT == null ? createBy != null : !CREATE_BY_EDEFAULT.equals(createBy);
			case DigitizePackage.AUDIT_REC__ACTION:
				return ACTION_EDEFAULT == null ? action != null : !ACTION_EDEFAULT.equals(action);
			case DigitizePackage.AUDIT_REC__DETAILS:
				return DETAILS_EDEFAULT == null ? details != null : !DETAILS_EDEFAULT.equals(details);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (id: ");
		if (idESet) result.append(id); else result.append("<unset>");
		result.append(", type: ");
		result.append(type);
		result.append(", objectId: ");
		result.append(objectId);
		result.append(", objectType: ");
		result.append(objectType);
		result.append(", createDate: ");
		result.append(createDate);
		result.append(", createBy: ");
		result.append(createBy);
		result.append(", action: ");
		result.append(action);
		result.append(", details: ");
		result.append(details);
		result.append(')');
		return result.toString();
	}

} //AuditRecImpl
