/**
 */
package au.gov.dva.digitize;

import java.util.Date;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Document</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link au.gov.dva.digitize.Document#getId <em>Id</em>}</li>
 *   <li>{@link au.gov.dva.digitize.Document#getProcStatus <em>Proc Status</em>}</li>
 *   <li>{@link au.gov.dva.digitize.Document#getReadStatus <em>Read Status</em>}</li>
 *   <li>{@link au.gov.dva.digitize.Document#getTitle <em>Title</em>}</li>
 *   <li>{@link au.gov.dva.digitize.Document#getTherL1 <em>Ther L1</em>}</li>
 *   <li>{@link au.gov.dva.digitize.Document#getTherL2 <em>Ther L2</em>}</li>
 *   <li>{@link au.gov.dva.digitize.Document#getTherL3 <em>Ther L3</em>}</li>
 *   <li>{@link au.gov.dva.digitize.Document#getExtRef <em>Ext Ref</em>}</li>
 *   <li>{@link au.gov.dva.digitize.Document#getBagId <em>Bag Id</em>}</li>
 *   <li>{@link au.gov.dva.digitize.Document#getEnvelopeId <em>Envelope Id</em>}</li>
 *   <li>{@link au.gov.dva.digitize.Document#getScanId <em>Scan Id</em>}</li>
 *   <li>{@link au.gov.dva.digitize.Document#getScanName <em>Scan Name</em>}</li>
 *   <li>{@link au.gov.dva.digitize.Document#getScanDate <em>Scan Date</em>}</li>
 *   <li>{@link au.gov.dva.digitize.Document#getArchiveBoxNum <em>Archive Box Num</em>}</li>
 *   <li>{@link au.gov.dva.digitize.Document#getAuditRecords <em>Audit Records</em>}</li>
 *   <li>{@link au.gov.dva.digitize.Document#getFileblob <em>Fileblob</em>}</li>
 *   <li>{@link au.gov.dva.digitize.Document#getContainer <em>Container</em>}</li>
 *   <li>{@link au.gov.dva.digitize.Document#getACL <em>ACL</em>}</li>
 * </ul>
 *
 * @see au.gov.dva.digitize.meta.DigitizePackage#getDocument()
 * @model
 * @generated
 */
public interface Document extends EObject {
	/**
	 * Returns the value of the '<em><b>Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Id</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Id</em>' attribute.
	 * @see #isSetId()
	 * @see au.gov.dva.digitize.meta.DigitizePackage#getDocument_Id()
	 * @model unsettable="true" id="true" required="true" changeable="false" ordered="false"
	 * @generated
	 */
	int getId();

	/**
	 * Returns whether the value of the '{@link au.gov.dva.digitize.Document#getId <em>Id</em>}' attribute is set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return whether the value of the '<em>Id</em>' attribute is set.
	 * @see #getId()
	 * @generated
	 */
	boolean isSetId();

	/**
	 * Returns the value of the '<em><b>Proc Status</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Proc Status</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Proc Status</em>' attribute.
	 * @see #setProcStatus(String)
	 * @see au.gov.dva.digitize.meta.DigitizePackage#getDocument_ProcStatus()
	 * @model required="true"
	 * @generated
	 */
	String getProcStatus();

	/**
	 * Sets the value of the '{@link au.gov.dva.digitize.Document#getProcStatus <em>Proc Status</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Proc Status</em>' attribute.
	 * @see #getProcStatus()
	 * @generated
	 */
	void setProcStatus(String value);

	/**
	 * Returns the value of the '<em><b>Read Status</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Read Status</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Read Status</em>' attribute.
	 * @see #setReadStatus(String)
	 * @see au.gov.dva.digitize.meta.DigitizePackage#getDocument_ReadStatus()
	 * @model unique="false" required="true" ordered="false"
	 * @generated
	 */
	String getReadStatus();

	/**
	 * Sets the value of the '{@link au.gov.dva.digitize.Document#getReadStatus <em>Read Status</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Read Status</em>' attribute.
	 * @see #getReadStatus()
	 * @generated
	 */
	void setReadStatus(String value);

	/**
	 * Returns the value of the '<em><b>Title</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Title</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Title</em>' attribute.
	 * @see #setTitle(String)
	 * @see au.gov.dva.digitize.meta.DigitizePackage#getDocument_Title()
	 * @model required="true"
	 * @generated
	 */
	String getTitle();

	/**
	 * Sets the value of the '{@link au.gov.dva.digitize.Document#getTitle <em>Title</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Title</em>' attribute.
	 * @see #getTitle()
	 * @generated
	 */
	void setTitle(String value);

	/**
	 * Returns the value of the '<em><b>Ther L1</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Ther L1</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Ther L1</em>' attribute.
	 * @see #setTherL1(String)
	 * @see au.gov.dva.digitize.meta.DigitizePackage#getDocument_TherL1()
	 * @model unique="false" required="true" ordered="false"
	 * @generated
	 */
	String getTherL1();

	/**
	 * Sets the value of the '{@link au.gov.dva.digitize.Document#getTherL1 <em>Ther L1</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Ther L1</em>' attribute.
	 * @see #getTherL1()
	 * @generated
	 */
	void setTherL1(String value);

	/**
	 * Returns the value of the '<em><b>Ther L2</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Ther L2</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Ther L2</em>' attribute.
	 * @see #setTherL2(String)
	 * @see au.gov.dva.digitize.meta.DigitizePackage#getDocument_TherL2()
	 * @model unique="false" required="true" ordered="false"
	 * @generated
	 */
	String getTherL2();

	/**
	 * Sets the value of the '{@link au.gov.dva.digitize.Document#getTherL2 <em>Ther L2</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Ther L2</em>' attribute.
	 * @see #getTherL2()
	 * @generated
	 */
	void setTherL2(String value);

	/**
	 * Returns the value of the '<em><b>Ther L3</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Ther L3</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Ther L3</em>' attribute.
	 * @see #setTherL3(String)
	 * @see au.gov.dva.digitize.meta.DigitizePackage#getDocument_TherL3()
	 * @model unique="false" required="true" ordered="false"
	 * @generated
	 */
	String getTherL3();

	/**
	 * Sets the value of the '{@link au.gov.dva.digitize.Document#getTherL3 <em>Ther L3</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Ther L3</em>' attribute.
	 * @see #getTherL3()
	 * @generated
	 */
	void setTherL3(String value);

	/**
	 * Returns the value of the '<em><b>Ext Ref</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Ext Ref</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Ext Ref</em>' attribute.
	 * @see #setExtRef(String)
	 * @see au.gov.dva.digitize.meta.DigitizePackage#getDocument_ExtRef()
	 * @model unique="false" required="true" ordered="false"
	 * @generated
	 */
	String getExtRef();

	/**
	 * Sets the value of the '{@link au.gov.dva.digitize.Document#getExtRef <em>Ext Ref</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Ext Ref</em>' attribute.
	 * @see #getExtRef()
	 * @generated
	 */
	void setExtRef(String value);

	/**
	 * Returns the value of the '<em><b>Bag Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Bag Id</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Bag Id</em>' attribute.
	 * @see #setBagId(String)
	 * @see au.gov.dva.digitize.meta.DigitizePackage#getDocument_BagId()
	 * @model required="true"
	 * @generated
	 */
	String getBagId();

	/**
	 * Sets the value of the '{@link au.gov.dva.digitize.Document#getBagId <em>Bag Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Bag Id</em>' attribute.
	 * @see #getBagId()
	 * @generated
	 */
	void setBagId(String value);

	/**
	 * Returns the value of the '<em><b>Envelope Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Envelope Id</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Envelope Id</em>' attribute.
	 * @see #setEnvelopeId(String)
	 * @see au.gov.dva.digitize.meta.DigitizePackage#getDocument_EnvelopeId()
	 * @model required="true"
	 * @generated
	 */
	String getEnvelopeId();

	/**
	 * Sets the value of the '{@link au.gov.dva.digitize.Document#getEnvelopeId <em>Envelope Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Envelope Id</em>' attribute.
	 * @see #getEnvelopeId()
	 * @generated
	 */
	void setEnvelopeId(String value);

	/**
	 * Returns the value of the '<em><b>Scan Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Scan Id</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Scan Id</em>' attribute.
	 * @see #setScanId(String)
	 * @see au.gov.dva.digitize.meta.DigitizePackage#getDocument_ScanId()
	 * @model required="true"
	 * @generated
	 */
	String getScanId();

	/**
	 * Sets the value of the '{@link au.gov.dva.digitize.Document#getScanId <em>Scan Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Scan Id</em>' attribute.
	 * @see #getScanId()
	 * @generated
	 */
	void setScanId(String value);

	/**
	 * Returns the value of the '<em><b>Scan Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Scan Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Scan Name</em>' attribute.
	 * @see #setScanName(String)
	 * @see au.gov.dva.digitize.meta.DigitizePackage#getDocument_ScanName()
	 * @model required="true"
	 * @generated
	 */
	String getScanName();

	/**
	 * Sets the value of the '{@link au.gov.dva.digitize.Document#getScanName <em>Scan Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Scan Name</em>' attribute.
	 * @see #getScanName()
	 * @generated
	 */
	void setScanName(String value);

	/**
	 * Returns the value of the '<em><b>Scan Date</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Scan Date</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Scan Date</em>' attribute.
	 * @see #setScanDate(Date)
	 * @see au.gov.dva.digitize.meta.DigitizePackage#getDocument_ScanDate()
	 * @model required="true"
	 * @generated
	 */
	Date getScanDate();

	/**
	 * Sets the value of the '{@link au.gov.dva.digitize.Document#getScanDate <em>Scan Date</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Scan Date</em>' attribute.
	 * @see #getScanDate()
	 * @generated
	 */
	void setScanDate(Date value);

	/**
	 * Returns the value of the '<em><b>Archive Box Num</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Archive Box Num</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Archive Box Num</em>' attribute.
	 * @see #setArchiveBoxNum(String)
	 * @see au.gov.dva.digitize.meta.DigitizePackage#getDocument_ArchiveBoxNum()
	 * @model required="true"
	 * @generated
	 */
	String getArchiveBoxNum();

	/**
	 * Sets the value of the '{@link au.gov.dva.digitize.Document#getArchiveBoxNum <em>Archive Box Num</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Archive Box Num</em>' attribute.
	 * @see #getArchiveBoxNum()
	 * @generated
	 */
	void setArchiveBoxNum(String value);

	/**
	 * Returns the value of the '<em><b>Audit Records</b></em>' reference list.
	 * The list contents are of type {@link au.gov.dva.digitize.AuditRec}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Audit Records</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Audit Records</em>' reference list.
	 * @see au.gov.dva.digitize.meta.DigitizePackage#getDocument_AuditRecords()
	 * @model type="au.gov.dva.digitize.AuditRec" keys="objectId"
	 * @generated
	 */
	EList getAuditRecords();

	/**
	 * Returns the value of the '<em><b>Fileblob</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Fileblob</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Fileblob</em>' reference.
	 * @see #setFileblob(FileBlob)
	 * @see au.gov.dva.digitize.meta.DigitizePackage#getDocument_Fileblob()
	 * @model keys="docId" required="true"
	 * @generated
	 */
	FileBlob getFileblob();

	/**
	 * Sets the value of the '{@link au.gov.dva.digitize.Document#getFileblob <em>Fileblob</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Fileblob</em>' reference.
	 * @see #getFileblob()
	 * @generated
	 */
	void setFileblob(FileBlob value);

	/**
	 * Returns the value of the '<em><b>Container</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Container</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Container</em>' reference.
	 * @see #setContainer(ContainedDoc)
	 * @see au.gov.dva.digitize.meta.DigitizePackage#getDocument_Container()
	 * @model keys="docId" required="true"
	 * @generated
	 */
	ContainedDoc getContainer();

	/**
	 * Sets the value of the '{@link au.gov.dva.digitize.Document#getContainer <em>Container</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Container</em>' reference.
	 * @see #getContainer()
	 * @generated
	 */
	void setContainer(ContainedDoc value);

	/**
	 * Returns the value of the '<em><b>ACL</b></em>' reference list.
	 * The list contents are of type {@link au.gov.dva.digitize.SecAccess}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>ACL</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>ACL</em>' reference list.
	 * @see au.gov.dva.digitize.meta.DigitizePackage#getDocument_ACL()
	 * @model type="au.gov.dva.digitize.SecAccess" keys="objectId"
	 * @generated
	 */
	EList getACL();

} // Document
