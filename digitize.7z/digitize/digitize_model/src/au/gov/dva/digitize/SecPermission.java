/**
 */
package au.gov.dva.digitize;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Sec Permission</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link au.gov.dva.digitize.SecPermission#getId <em>Id</em>}</li>
 *   <li>{@link au.gov.dva.digitize.SecPermission#getLabel <em>Label</em>}</li>
 *   <li>{@link au.gov.dva.digitize.SecPermission#getObjectType <em>Object Type</em>}</li>
 *   <li>{@link au.gov.dva.digitize.SecPermission#getACL <em>ACL</em>}</li>
 * </ul>
 *
 * @see au.gov.dva.digitize.meta.DigitizePackage#getSecPermission()
 * @model
 * @generated
 */
public interface SecPermission extends EObject {
	/**
	 * Returns the value of the '<em><b>Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Id</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Id</em>' attribute.
	 * @see #isSetId()
	 * @see au.gov.dva.digitize.meta.DigitizePackage#getSecPermission_Id()
	 * @model unsettable="true" id="true" required="true" changeable="false" ordered="false"
	 * @generated
	 */
	int getId();

	/**
	 * Returns whether the value of the '{@link au.gov.dva.digitize.SecPermission#getId <em>Id</em>}' attribute is set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return whether the value of the '<em>Id</em>' attribute is set.
	 * @see #getId()
	 * @generated
	 */
	boolean isSetId();

	/**
	 * Returns the value of the '<em><b>Label</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Label</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Label</em>' attribute.
	 * @see #setLabel(String)
	 * @see au.gov.dva.digitize.meta.DigitizePackage#getSecPermission_Label()
	 * @model required="true"
	 * @generated
	 */
	String getLabel();

	/**
	 * Sets the value of the '{@link au.gov.dva.digitize.SecPermission#getLabel <em>Label</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Label</em>' attribute.
	 * @see #getLabel()
	 * @generated
	 */
	void setLabel(String value);

	/**
	 * Returns the value of the '<em><b>Object Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Object Type</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Object Type</em>' attribute.
	 * @see #setObjectType(String)
	 * @see au.gov.dva.digitize.meta.DigitizePackage#getSecPermission_ObjectType()
	 * @model required="true"
	 * @generated
	 */
	String getObjectType();

	/**
	 * Sets the value of the '{@link au.gov.dva.digitize.SecPermission#getObjectType <em>Object Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Object Type</em>' attribute.
	 * @see #getObjectType()
	 * @generated
	 */
	void setObjectType(String value);

	/**
	 * Returns the value of the '<em><b>ACL</b></em>' reference list.
	 * The list contents are of type {@link au.gov.dva.digitize.SecAccess}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>ACL</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>ACL</em>' reference list.
	 * @see au.gov.dva.digitize.meta.DigitizePackage#getSecPermission_ACL()
	 * @model type="au.gov.dva.digitize.SecAccess" keys="permissionId"
	 * @generated
	 */
	EList getACL();

} // SecPermission
