/**
 */
package au.gov.dva.digitize;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Container</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link au.gov.dva.digitize.Container#getId <em>Id</em>}</li>
 *   <li>{@link au.gov.dva.digitize.Container#getParentId <em>Parent Id</em>}</li>
 *   <li>{@link au.gov.dva.digitize.Container#getType <em>Type</em>}</li>
 *   <li>{@link au.gov.dva.digitize.Container#getLabel <em>Label</em>}</li>
 *   <li>{@link au.gov.dva.digitize.Container#getExtRef <em>Ext Ref</em>}</li>
 *   <li>{@link au.gov.dva.digitize.Container#getDocuments <em>Documents</em>}</li>
 *   <li>{@link au.gov.dva.digitize.Container#getACL <em>ACL</em>}</li>
 *   <li>{@link au.gov.dva.digitize.Container#getParentContainer <em>Parent Container</em>}</li>
 * </ul>
 *
 * @see au.gov.dva.digitize.meta.DigitizePackage#getContainer()
 * @model
 * @generated
 */
public interface Container extends EObject {
	/**
	 * Returns the value of the '<em><b>Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Id</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Id</em>' attribute.
	 * @see #isSetId()
	 * @see au.gov.dva.digitize.meta.DigitizePackage#getContainer_Id()
	 * @model unsettable="true" id="true" required="true" changeable="false" ordered="false"
	 * @generated
	 */
	int getId();

	/**
	 * Returns whether the value of the '{@link au.gov.dva.digitize.Container#getId <em>Id</em>}' attribute is set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return whether the value of the '<em>Id</em>' attribute is set.
	 * @see #getId()
	 * @generated
	 */
	boolean isSetId();

	/**
	 * Returns the value of the '<em><b>Parent Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Parent Id</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Parent Id</em>' attribute.
	 * @see #setParentId(int)
	 * @see au.gov.dva.digitize.meta.DigitizePackage#getContainer_ParentId()
	 * @model unique="false" required="true" ordered="false"
	 * @generated
	 */
	int getParentId();

	/**
	 * Sets the value of the '{@link au.gov.dva.digitize.Container#getParentId <em>Parent Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Parent Id</em>' attribute.
	 * @see #getParentId()
	 * @generated
	 */
	void setParentId(int value);

	/**
	 * Returns the value of the '<em><b>Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Type</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Type</em>' attribute.
	 * @see #setType(String)
	 * @see au.gov.dva.digitize.meta.DigitizePackage#getContainer_Type()
	 * @model unique="false" required="true" ordered="false"
	 * @generated
	 */
	String getType();

	/**
	 * Sets the value of the '{@link au.gov.dva.digitize.Container#getType <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Type</em>' attribute.
	 * @see #getType()
	 * @generated
	 */
	void setType(String value);

	/**
	 * Returns the value of the '<em><b>Label</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Label</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Label</em>' attribute.
	 * @see #setLabel(String)
	 * @see au.gov.dva.digitize.meta.DigitizePackage#getContainer_Label()
	 * @model unique="false" required="true" ordered="false"
	 * @generated
	 */
	String getLabel();

	/**
	 * Sets the value of the '{@link au.gov.dva.digitize.Container#getLabel <em>Label</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Label</em>' attribute.
	 * @see #getLabel()
	 * @generated
	 */
	void setLabel(String value);

	/**
	 * Returns the value of the '<em><b>Ext Ref</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Ext Ref</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Ext Ref</em>' attribute.
	 * @see #setExtRef(String)
	 * @see au.gov.dva.digitize.meta.DigitizePackage#getContainer_ExtRef()
	 * @model unique="false" required="true" ordered="false"
	 * @generated
	 */
	String getExtRef();

	/**
	 * Sets the value of the '{@link au.gov.dva.digitize.Container#getExtRef <em>Ext Ref</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Ext Ref</em>' attribute.
	 * @see #getExtRef()
	 * @generated
	 */
	void setExtRef(String value);

	/**
	 * Returns the value of the '<em><b>Documents</b></em>' reference list.
	 * The list contents are of type {@link au.gov.dva.digitize.ContainedDoc}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Documents</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Documents</em>' reference list.
	 * @see au.gov.dva.digitize.meta.DigitizePackage#getContainer_Documents()
	 * @model type="au.gov.dva.digitize.ContainedDoc" keys="containerId"
	 * @generated
	 */
	EList getDocuments();

	/**
	 * Returns the value of the '<em><b>ACL</b></em>' reference list.
	 * The list contents are of type {@link au.gov.dva.digitize.SecAccess}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>ACL</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>ACL</em>' reference list.
	 * @see au.gov.dva.digitize.meta.DigitizePackage#getContainer_ACL()
	 * @model type="au.gov.dva.digitize.SecAccess" keys="objectId"
	 * @generated
	 */
	EList getACL();

	/**
	 * Returns the value of the '<em><b>Parent Container</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Parent Container</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Parent Container</em>' reference.
	 * @see #setParentContainer(Container)
	 * @see au.gov.dva.digitize.meta.DigitizePackage#getContainer_ParentContainer()
	 * @model keys="parentId"
	 * @generated
	 */
	Container getParentContainer();

	/**
	 * Sets the value of the '{@link au.gov.dva.digitize.Container#getParentContainer <em>Parent Container</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Parent Container</em>' reference.
	 * @see #getParentContainer()
	 * @generated
	 */
	void setParentContainer(Container value);

} // Container
