/**
 */
package au.gov.dva.digitize.impl;

import au.gov.dva.digitize.*;

import au.gov.dva.digitize.meta.DigitizeFactory;
import au.gov.dva.digitize.meta.DigitizePackage;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class DigitizeFactoryImpl extends EFactoryImpl implements DigitizeFactory {
	/**
	 * Creates the default factory implementation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static DigitizeFactory init() {
		try {
			DigitizeFactory theDigitizeFactory = (DigitizeFactory)EPackage.Registry.INSTANCE.getEFactory(DigitizePackage.eNS_URI);
			if (theDigitizeFactory != null) {
				return theDigitizeFactory;
			}
		}
		catch (Exception exception) {
			EcorePlugin.INSTANCE.log(exception);
		}
		return new DigitizeFactoryImpl();
	}

	/**
	 * Creates an instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DigitizeFactoryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
			case DigitizePackage.DOCUMENT: return createDocument();
			case DigitizePackage.CONTAINER: return createContainer();
			case DigitizePackage.CONTAINED_DOC: return createContainedDoc();
			case DigitizePackage.FILE_BLOB: return createFileBlob();
			case DigitizePackage.AUDIT_REC: return createAuditRec();
			case DigitizePackage.SEC_ACCESS: return createSecAccess();
			case DigitizePackage.SEC_SUBJECT: return createSecSubject();
			case DigitizePackage.SEC_PERMISSION: return createSecPermission();
			default:
				throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Document createDocument() {
		DocumentImpl document = new DocumentImpl();
		return document;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public au.gov.dva.digitize.Container createContainer() {
		ContainerImpl container = new ContainerImpl();
		return container;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ContainedDoc createContainedDoc() {
		ContainedDocImpl containedDoc = new ContainedDocImpl();
		return containedDoc;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public FileBlob createFileBlob() {
		FileBlobImpl fileBlob = new FileBlobImpl();
		return fileBlob;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public AuditRec createAuditRec() {
		AuditRecImpl auditRec = new AuditRecImpl();
		return auditRec;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SecAccess createSecAccess() {
		SecAccessImpl secAccess = new SecAccessImpl();
		return secAccess;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SecSubject createSecSubject() {
		SecSubjectImpl secSubject = new SecSubjectImpl();
		return secSubject;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SecPermission createSecPermission() {
		SecPermissionImpl secPermission = new SecPermissionImpl();
		return secPermission;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DigitizePackage getDigitizePackage() {
		return (DigitizePackage)getEPackage();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @deprecated
	 * @generated
	 */
	public static DigitizePackage getPackage() {
		return DigitizePackage.eINSTANCE;
	}

} //DigitizeFactoryImpl
