package au.gov.dva.digitize.service;

import java.security.Principal;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import au.gov.dva.digitize.dao.DocumentPaginationRepository;
import au.gov.dva.digitize.dao.DocumentRepository;
import au.gov.dva.digitize.service.model.Document;
import au.gov.dva.digitize.service.model.MailProcessingStatus;
import au.gov.dva.digitize.service.model.ReadStatus;
@Service
public class DocumentService {
	
	protected DocumentRepository documentRepository;

	
	
	public DocumentRepository getDocumentRepository() {
		return documentRepository;
	}
	@Autowired 
	public void setDocumentRepository(DocumentRepository documentRepository) {
		this.documentRepository = documentRepository;
	}
	
	protected DocumentPaginationRepository documentPaginationRepository;
	
	
	public DocumentPaginationRepository getDocumentPaginationRepository() {
		return documentPaginationRepository;
	}
	@Autowired
	public void setDocumentPaginationRepository(DocumentPaginationRepository documentPaginationRepository) {
		this.documentPaginationRepository = documentPaginationRepository;
	}
	public List<Document> getDocumentsByEnvelopeId(Integer envelId){
		
		List<au.gov.dva.digitize.jpa.Document> documentsByEnvelope =  documentRepository.findByEnvelopeId(envelId.toString());
		List<Document> results = new ArrayList<Document>();
		for (au.gov.dva.digitize.jpa.Document document : documentsByEnvelope) {
			Document documentVO = new Document ();
			documentVO.setBagId(document.getBagId());
			documentVO.setDocId(document.getId());
			documentVO.setDocumentname(document.getScanId());
			documentVO.setDocumentTitle(document.getTitle());
			boolean readStatus = document.getReadSta().equalsIgnoreCase(ReadStatus.READ.name())?true:false;
			documentVO.setReadStatus(readStatus);
			boolean trimStatus = document.getReadSta().equalsIgnoreCase(MailProcessingStatus.TRIM_PENDING.name())?true:false;
			documentVO.setPendingInTrim(trimStatus);
			documentVO.setLoadDate(document.getScanDate().toInstant().atZone(ZoneId.systemDefault()).toLocalDate());
			results.add(documentVO);
			
		}
		return results;
	}
	
	public Document getDocumentById(Integer docId ) {
		
		au.gov.dva.digitize.jpa.Document document = documentRepository.findDocumentById(docId);
		Document documentVO = new Document ();
		documentVO.setBagId(document.getBagId());
		documentVO.setDocId(document.getId());
		documentVO.setDocumentname(document.getScanId());
		documentVO.setDocumentTitle(document.getTitle());
		boolean readStatus = document.getReadSta().equalsIgnoreCase(ReadStatus.READ.name())?true:false;
		documentVO.setReadStatus(readStatus);
		boolean trimStatus = document.getReadSta().equalsIgnoreCase(MailProcessingStatus.TRIM_PENDING.name())?true:false;
		documentVO.setPendingInTrim(trimStatus);
		documentVO.setLoadDate(document.getScanDate().toInstant().atZone(ZoneId.systemDefault()).toLocalDate());
		documentVO.setFileBlob(document.getFileBlob().getFblob());
		return documentVO;
	}

	/**
	 * 
	 * @param lastDocId
	 * @param selectedMailboxId
	 * @param Processingtatus
	 * @return
	 */
	public List<Document> getDocumentsByPage(Integer lastDocId, Integer selectedMailboxId , String Processingtatus, PageRequest pageRequest){
		
		List<au.gov.dva.digitize.jpa.Document> documentsByPage = documentPaginationRepository.findDocumentsByPageAndStausAndMailBox(lastDocId,selectedMailboxId,
				Processingtatus,pageRequest);
		
		List <Document> results = new ArrayList<Document>();
		for (au.gov.dva.digitize.jpa.Document document : documentsByPage) {
			Document documentVO = new Document ();
			documentVO.setBagId(document.getBagId());
			documentVO.setDocId(document.getId());
			documentVO.setDocumentname(document.getScanId());
			documentVO.setDocumentTitle(document.getTitle());
			boolean readStatus = document.getReadSta().equalsIgnoreCase(ReadStatus.READ.name())?true:false;
			documentVO.setReadStatus(readStatus);
			boolean trimStatus = document.getReadSta().equalsIgnoreCase(MailProcessingStatus.TRIM_PENDING.name())?true:false;
			documentVO.setPendingInTrim(trimStatus);
			documentVO.setLoadDate(document.getScanDate().toInstant().atZone(ZoneId.systemDefault()).toLocalDate());
			results.add(documentVO);
		}
		return results;
	}
}
