package au.gov.dva.digitize.service.model;

public enum ReadStatus {
	
	READ("READ"),
	UN_READ("UN_READ");
	
	private String code;
	
	ReadStatus(String statusCode) {
		this.code = statusCode;
	}
	
	public String getCode()	{
		return code;
	}
	
	public static ReadStatus toEnum(String statusCode){
		
		for(ReadStatus value: ReadStatus.values()){
			if(value.getCode().equals(statusCode))
				return value;
		}
		return null;
	}
}
