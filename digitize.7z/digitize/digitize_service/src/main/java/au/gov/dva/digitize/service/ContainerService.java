package au.gov.dva.digitize.service;


import java.security.Principal;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import au.gov.dva.digitize.dao.ContainerRepository;
import au.gov.dva.digitize.jpa.Container;
import au.gov.dva.digitize.jpa.custom.ContainerWithCount;
import au.gov.dva.digitize.service.model.Document;
import au.gov.dva.digitize.service.model.MailBox;
import au.gov.dva.digitize.service.model.MailProcessingStatus;
import au.gov.dva.digitize.service.model.ReadStatus;
/**
 * This simple serivce class intent to provide all Person related infomation 
 * management. It access backend data access layer and provide other logical functions.
 * It should return an intermediate business model object and mapping back end forth between
 * backend model and business model. However this is a simple app with read only let cut the 
 * middleman off.
 * 
 * 
 * @author 		Haibang Mai
 * @version    1.0
 * 
 */

@Service
public class ContainerService
{
	protected ContainerRepository containerRepository;
	
	

	public ContainerRepository getRepository()
	{
		return containerRepository;
	}
	
	@Autowired 
	public void setRepository(ContainerRepository repository)
	{
		this.containerRepository = repository;
	}
	
	
	/**
	 * This method query the Person repository all the person and return a list
	 * of person available. 
	 * 
	 * @return      List of Person from backend, if nothing found return empty list
	 * 
	 */

	public List<MailBox> getUserAccessibleContainers(Principal user)
	{	
/*		if(user==null)
			return new ArrayList<Container>();*/
		
		List<Container> containers=containerRepository.findByRoleAndPermission("CLAIM_OFFICER", "VIEW");
		List<ContainerWithCount> cont = containerRepository.findMailBoxesWithCount("CLAIM_OFFICER", "VIEW");
		List<MailBox> results = new ArrayList<MailBox>();
		for (Container container : containers) {
			MailBox mailBox = new MailBox();
			mailBox.setName(container.getLabel());
			mailBox.setId(container.getId());
			mailBox.setCount(0);
			if(container.getDocuments()!=null && !container.getDocuments().isEmpty()) {
				List<au.gov.dva.digitize.jpa.Document> documentsInContainer = container.getDocuments();
				int documentCount = 0;
				for (au.gov.dva.digitize.jpa.Document document : documentsInContainer) {
					if(document.getProcSta().equalsIgnoreCase(MailProcessingStatus.UNPROCESSED.name())) {
						documentCount = documentCount +1;
					}
				}
				mailBox.setCount(documentCount);
			}
			results.add(mailBox);
		}
		return results;
	}
	
	/**
	 * 
	 * @return
	 */
	public List<Document> getDocumentsByMailBoxId(Principal user, Integer selectedMailboxId){
		
		List<Container> containers = containerRepository.findByRoleAndPermission("CLAIM_OFFICER", "VIEW");
		List<Document> results = new ArrayList<Document>();
		Container selectedMailBox = null;
		for (Container container : containers) {
			if(selectedMailboxId == container.getId()) {
				selectedMailBox = container;
			}
		}
		List<au.gov.dva.digitize.jpa.Document> documentsInContainer = selectedMailBox.getDocuments();
		for (au.gov.dva.digitize.jpa.Document document : documentsInContainer) {
			if(!document.getProcSta().equalsIgnoreCase(MailProcessingStatus.TRIM_COMPLETE.name())) {
				Document documentVO = new Document ();
				documentVO.setBagId(document.getBagId());
				documentVO.setDocId(document.getId());
				documentVO.setDocumentname(document.getScanId());
				documentVO.setDocumentTitle(document.getTitle());
				boolean readStatus = document.getReadSta().equalsIgnoreCase(ReadStatus.READ.name())?true:false;
				documentVO.setReadStatus(readStatus);
				boolean trimStatus = document.getReadSta().equalsIgnoreCase(MailProcessingStatus.TRIM_PENDING.name())?true:false;
				documentVO.setPendingInTrim(trimStatus);
				documentVO.setLoadDate(document.getScanDate().toInstant().atZone(ZoneId.systemDefault()).toLocalDate());
				results.add(documentVO);
			}
		}
		return results;
	}
	 
	/**
	 * 
	 * @param user
	 * @param selectedMailboxId
	 * @return
	 */
	public List<Document> getDocumentsByPage(Principal user, Integer selectedMailboxId, Integer lastDocumentId,Pageable pageable){
		return null;
	}

}
