package au.gov.dva.digitize.service.error;

public class ValidationErrors {
	
	private String fieldName;
	private String code;
	private String message; /*Error message for the rule being violated*/
	private String attemptedValue; /*What value was rejected*/
	public String getFieldName() {
		return fieldName;
	}
	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getAttemptedValue() {
		return attemptedValue;
	}
	public void setAttemptedValue(String attemptedValue) {
		this.attemptedValue = attemptedValue;
	}

}
