package au.gov.dva.digitize.service.model;

public enum ContainerType 
{
	MAIL_ROOM("MAIL_ROOM"),
	TRIM_MAIL_BOX("MAIL_BOX"),
	WORK_GROUP("WORK_GROUP");
	
	private String code=null;
	
	private ContainerType(String code)
	{
		this.code=code;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}
	
}
