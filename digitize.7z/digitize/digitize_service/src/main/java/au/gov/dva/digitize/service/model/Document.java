package au.gov.dva.digitize.service.model;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class Document {

	private boolean processingStatus;
	private boolean alreadyRead;
	private String documentTitle;
	private String documentname;
	private String thesaurusLevel1;
	private String thesaurusLevel2;
	private String thesaurusLevel3;
	private String bagId;
	private int docId;
	private byte[] fileBlob;
	private String fileType;
	private boolean pendingInTrim;
	private LocalDate loadDate;
	private int lastDocIdInPage;
	private int startDocIdInPage;
	
	public int getStartDocIdInPage() {
		return startDocIdInPage;
	}
	public void setStartDocIdInPage(int startDocIdInPage) {
		this.startDocIdInPage = startDocIdInPage;
	}
	public boolean isAlreadyRead() {
		return alreadyRead;
	}
	public int getLastDocIdInPage() {
		return lastDocIdInPage;
	}
	public void setAlreadyRead(boolean alreadyRead) {
		this.alreadyRead = alreadyRead;
	}
	public void setLastDocIdInPage(int lastDocIdInPage) {
		this.lastDocIdInPage = lastDocIdInPage;
	}
	public boolean isProcessingStatus() {
		return processingStatus;
	}
	public void setProcessingStatus(boolean processingStatus) {
		this.processingStatus = processingStatus;
	}
	public boolean getReadStatus() {
		return alreadyRead;
	}
	public void setReadStatus(boolean readStatus) {
		this.alreadyRead = readStatus;
	}
	public String getTitle() {
		return documentTitle;
	}
	public void setTitle(String title) {
		this.documentTitle = title;
	}
	public String getThesaurusLevel1() {
		return thesaurusLevel1;
	}
	public void setThesaurusLevel1(String thesaurusLevel1) {
		this.thesaurusLevel1 = thesaurusLevel1;
	}
	public String getThesaurusLevel2() {
		return thesaurusLevel2;
	}
	public void setThesaurusLevel2(String thesaurusLevel2) {
		this.thesaurusLevel2 = thesaurusLevel2;
	}
	public String getThesaurusLevel3() {
		return thesaurusLevel3;
	}
	public void setThesaurusLevel3(String thesaurusLevel3) {
		this.thesaurusLevel3 = thesaurusLevel3;
	}
	public String getBagId() {
		return bagId;
	}
	public void setBagId(String bagId) {
		this.bagId = bagId;
	}
	public int getDocId() {
		return docId;
	}
	public void setDocId(int docId) {
		this.docId = docId;
	}
	public byte[] getFileBlob() {
		return fileBlob;
	}
	public void setFileBlob(byte[] fileBlob) {
		this.fileBlob = fileBlob;
	}
	public String getFileType() {
		return fileType;
	}
	public void setFileType(String fileType) {
		this.fileType = fileType;
	}
	public String getDocumentTitle() {
		return documentTitle;
	}
	public String getDocumentname() {
		return documentname;
	}
	public void setDocumentTitle(String documentTitle) {
		this.documentTitle = documentTitle;
	}
	public void setDocumentname(String documentname) {
		this.documentname = documentname;
	}
	public boolean isPendingInTrim() {
		return pendingInTrim;
	}
	public void setPendingInTrim(boolean pendingInTrim) {
		this.pendingInTrim = pendingInTrim;
	}
	public String getLoadDate() {
		return loadDate.format(DateTimeFormatter.BASIC_ISO_DATE);
	}
	public void setLoadDate(LocalDate loadDate) {
		this.loadDate = loadDate;
	}
}
