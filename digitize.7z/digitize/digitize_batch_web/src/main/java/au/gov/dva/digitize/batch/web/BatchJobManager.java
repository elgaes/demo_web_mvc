package au.gov.dva.digitize.batch.web;

import java.io.IOException;
import java.util.Properties;

import javax.batch.operations.JobOperator;
import javax.batch.runtime.BatchRuntime;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class BatchJobManager
 */
@WebServlet("/jobstart")
public class BatchJobManager extends HttpServlet 
{
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public BatchJobManager() 
    {

    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		JobOperator op=BatchRuntime.getJobOperator();
		Properties params=new Properties();
		long jobId=op.start("LoadMailData",params);
		System.out.println("Start job LoadMailData"+jobId);
	}

}
