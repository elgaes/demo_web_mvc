package au.gov.dva.digitize.jpa;

import java.io.Serializable;
import javax.persistence.*;
import java.util.List;


/**
 * The persistent class for the CONTAINER database table.
 * 
 */
@Entity
@NamedQueries({
		@NamedQuery(name="Container.findByRoleAndPermission", 
			query="SELECT c FROM Container c"
					+ " WHERE c.id IN  ( "
						+ "SELECT a.id.objId "
						+ "FROM SecAccess a, SecSubject s, SecPermission p "
						+ "WHERE a.id.permId=p.id AND a.id.subjId=s.id AND s.label = :role AND p.label = :permission AND a.id.objType='MAIL_ROOM')"),
		@NamedQuery(name="Container.findByMailBox",
			query="SELECT c FROM Container c WHERE c.extRef=:mailBoxId")
		})		
public class Container implements Serializable {
	private static final long serialVersionUID = 1L;
	private int id;
	private String extRef;
	private String label;
	private String type;
	private List<Document> documents;
	private Container parentContainer;
	private List<Container> subContainers;

	public Container() {
	}


	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}


	@Column(name="EXT_REF")
	public String getExtRef() {
		return this.extRef;
	}

	public void setExtRef(String extRef) {
		this.extRef = extRef;
	}


	public String getLabel() {
		return this.label;
	}

	public void setLabel(String label) {
		this.label = label;
	}


	public String getType() {
		return this.type;
	}

	public void setType(String type) {
		this.type = type;
	}


	//bi-directional many-to-many association to Document
	@ManyToMany(mappedBy="containers")
	public List<Document> getDocuments() {
		return this.documents;
	}

	public void setDocuments(List<Document> documents) {
		this.documents = documents;
	}


	//bi-directional many-to-one association to Container
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="PARENT_ID")
	public Container getParentContainer() {
		return this.parentContainer;
	}

	public void setParentContainer(Container parentContainer) {
		this.parentContainer = parentContainer;
	}


	//bi-directional many-to-one association to Container
	@OneToMany(mappedBy="parentContainer")
	public List<Container> getSubContainers() {
		return this.subContainers;
	}

	public void setSubContainers(List<Container> subContainers) {
		this.subContainers = subContainers;
	}

	public Container addSubContainer(Container subContainer) {
		getSubContainers().add(subContainer);
		subContainer.setParentContainer(this);

		return subContainer;
	}

	public Container removeSubContainer(Container subContainer) {
		getSubContainers().remove(subContainer);
		subContainer.setParentContainer(null);

		return subContainer;
	}

}