package au.gov.dva.digitize.jpa;

import java.io.Serializable;
import javax.persistence.*;
import java.util.List;


/**
 * The persistent class for the SEC_SUBJECT database table.
 * 
 */
@Entity
@Table(name="SEC_SUBJECT")
@NamedQuery(name="SecSubject.findAll", query="SELECT s FROM SecSubject s")
public class SecSubject implements Serializable {
	private static final long serialVersionUID = 1L;
	private int id;
	private String extId;
	private String extName;
	private String label;
	private List<SecAccess> secAccesses;

	public SecSubject() {
	}


	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}


	@Column(name="EXT_ID")
	public String getExtId() {
		return this.extId;
	}

	public void setExtId(String extId) {
		this.extId = extId;
	}


	@Column(name="EXT_NAME")
	public String getExtName() {
		return this.extName;
	}

	public void setExtName(String extName) {
		this.extName = extName;
	}


	public String getLabel() {
		return this.label;
	}

	public void setLabel(String label) {
		this.label = label;
	}


	//bi-directional many-to-one association to SecAccess
	@OneToMany(mappedBy="secSubject")
	public List<SecAccess> getSecAccesses() {
		return this.secAccesses;
	}

	public void setSecAccesses(List<SecAccess> secAccesses) {
		this.secAccesses = secAccesses;
	}

	public SecAccess addSecAccess(SecAccess secAccess) {
		getSecAccesses().add(secAccess);
		secAccess.setSecSubject(this);

		return secAccess;
	}

	public SecAccess removeSecAccess(SecAccess secAccess) {
		getSecAccesses().remove(secAccess);
		secAccess.setSecSubject(null);

		return secAccess;
	}

}