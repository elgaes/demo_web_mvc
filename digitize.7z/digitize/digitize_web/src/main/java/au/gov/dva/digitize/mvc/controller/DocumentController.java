package au.gov.dva.digitize.mvc.controller;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.apache.tomcat.util.http.fileupload.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import au.gov.dva.digitize.config.AppConstants;
import au.gov.dva.digitize.jpa.mock.DocumentMock;
import au.gov.dva.digitize.jpa.mock.EnvelopeMock;
import au.gov.dva.digitize.jpa.mock.MailBoxMock;
import au.gov.dva.digitize.service.ContainerService;
import au.gov.dva.digitize.service.DocumentService;
import au.gov.dva.digitize.service.error.GenericError;
import au.gov.dva.digitize.service.model.Document;
import au.gov.dva.digitize.service.model.MailBox;
import au.gov.dva.digitize.service.model.MailProcessingStatus;

/**
 * 
 * @author znairm
 *
 * @param <T>
 */
@Controller
@RequestMapping("service/views/document/*")
public class DocumentController<T> extends AbstractController{

	@Autowired
	ContainerService containerService;
	
	@Autowired
	DocumentService documentService;
	
	private boolean mockResponse = false;
	
	/**
	 * 
	 * @param mailBoxId
	 * @param httpRequest
	 * @return
	 */
	@ResponseBody
	@RequestMapping(path="getAllDocumentsByMailBoxId", produces="application/json")
	public List<?> getAllDocumentsByMailBoxId(@RequestParam(value="mailBoxId", required=false) Integer mailBoxId,@RequestParam(value="documentId", required=false) Integer documentId,HttpServletRequest httpRequest){
		
		if(mockResponse) {
			List<DocumentMock> documents = new ArrayList<DocumentMock>();
			DocumentMock documentMock = new DocumentMock();
			documentMock.setDocumentId(new Integer(57));
			documentMock.setDocumentName("DOC-1898453");
			LocalDate localDate = LocalDate.now();
			documentMock.setLoadDate(localDate);
			documentMock.setTitle("IncomeSupport claim");
			documentMock.setIsPendingToBeInTrim(false);
			documentMock.setIsUnread(false);
			documents.add(documentMock);
			DocumentMock documentMock1 = new DocumentMock();
			documentMock1.setDocumentId(new Integer(58));
			documentMock1.setDocumentName("DOC-25546656'");
			LocalDate localDate1 = LocalDate.now().minusDays(3);
			documentMock1.setLoadDate(localDate1);
			documentMock1.setTitle("'Income support asset statement");
			documentMock1.setIsPendingToBeInTrim(true);
			documentMock1.setIsUnread(true);
			documents.add(documentMock1);
			return documents;
		}
		
		// if documentId is null, fetch first 200 
		return containerService.getDocumentsByMailBoxId(httpRequest.getUserPrincipal(),mailBoxId);
	}
	
	
	/**
	 * 
	 * @param mailBoxId
	 * @param httpRequest
	 * @return
	 */
	@ResponseBody
	@RequestMapping(path="getAllDocumentsByMailBoxIdAndPage", produces="application/json")
	public List<?> getAllDocumentsByMailBoxIdAndPage(@RequestParam(value="mailBoxId", required=true) Integer mailBoxId,@RequestParam(value="documentId", required=false) Integer documentId,HttpServletRequest httpRequest){
		if(mockResponse) {
			List<DocumentMock> documents = new ArrayList<DocumentMock>();
			DocumentMock documentMock = new DocumentMock();
			documentMock.setDocumentId(new Integer(57));
			documentMock.setDocumentName("DOC-1898453");
			LocalDate localDate = LocalDate.now();
			documentMock.setLoadDate(localDate);
			documentMock.setTitle("IncomeSupport claim");
			documentMock.setIsPendingToBeInTrim(false);
			documentMock.setIsUnread(false);
			documents.add(documentMock);
			DocumentMock documentMock1 = new DocumentMock();
			documentMock1.setDocumentId(new Integer(58));
			documentMock1.setDocumentName("DOC-25546656'");
			LocalDate localDate1 = LocalDate.now().minusDays(3);
			documentMock1.setLoadDate(localDate1);
			documentMock1.setTitle("'Income support asset statement");
			documentMock1.setIsPendingToBeInTrim(true);
			documentMock1.setIsUnread(true);
			documents.add(documentMock1);
			return documents;
		}
		return documentService.getDocumentsByPage(documentId,mailBoxId, MailProcessingStatus.UNPROCESSED.name(), new PageRequest(0, 200));
	}
	
	
	/**
	 * 
	 * @param envelopeId
	 * @param httpRequest
	 * @return
	 */
	@ResponseBody
	@RequestMapping(path="getAllDocumentsByEnvelopeId", produces="application/json")
	public List<?> getAllDocumentsByEnvelopeId(@RequestParam(value="envelopeId", required=false) Integer envelopeId,HttpServletRequest httpRequest){
		
		if(mockResponse) {
			List<EnvelopeMock> envelopes = new ArrayList<EnvelopeMock>();
			EnvelopeMock envelopeMock = new EnvelopeMock();
			envelopeMock.setPendingToBeInTrim(true);
			envelopeMock.setActioned(false);
			envelopeMock.setUnread(false);
			envelopeMock.setExternalRedirected(false);
			envelopeMock.setInternalRedirected(false);
			envelopeMock.setId(1157);
			envelopeMock.setDocumentName("DOC-1245262353");
			envelopeMock.setMailBox("PIR");
			envelopes.add(envelopeMock);
			
			EnvelopeMock envelopeMock1 = new EnvelopeMock();
			envelopeMock1.setPendingToBeInTrim(false);
			envelopeMock1.setActioned(true);
			envelopeMock1.setUnread(false);
			envelopeMock1.setExternalRedirected(false);
			envelopeMock1.setInternalRedirected(false);
			envelopeMock1.setId(117);
			envelopeMock1.setDocumentName("DOC-275324");
			envelopeMock1.setMailBox("DIR");
			envelopes.add(envelopeMock1);
			
			EnvelopeMock envelopeMock2 = new EnvelopeMock();
			envelopeMock2.setPendingToBeInTrim(false);
			envelopeMock2.setActioned(false);
			envelopeMock2.setUnread(true);
			envelopeMock2.setExternalRedirected(false);
			envelopeMock2.setInternalRedirected(false);
			envelopeMock2.setId(117);
			envelopeMock2.setDocumentName("DOC-478568657");
			envelopeMock2.setMailBox("DIR");
			envelopes.add(envelopeMock2);
			
			EnvelopeMock envelopeMock3 = new EnvelopeMock();
			envelopeMock3.setPendingToBeInTrim(false);
			envelopeMock3.setActioned(false);
			envelopeMock3.setUnread(false);
			envelopeMock3.setExternalRedirected(true);
			envelopeMock3.setInternalRedirected(false);
			envelopeMock3.setId(1167);
			envelopeMock3.setDocumentName("DOC-275324");
			envelopeMock3.setMailBox("Claims");
			envelopes.add(envelopeMock3);
			
			EnvelopeMock envelopeMock4 = new EnvelopeMock();
			envelopeMock4.setPendingToBeInTrim(false);
			envelopeMock4.setActioned(false);
			envelopeMock4.setUnread(false);
			envelopeMock4.setExternalRedirected(false);
			envelopeMock4.setInternalRedirected(true);
			envelopeMock4.setId(1167);
			envelopeMock4.setDocumentName("DOC-275324");
			envelopeMock4.setMailBox("Payments");
			envelopes.add(envelopeMock4);
			
			return envelopes;
		}
		
		return documentService.getDocumentsByEnvelopeId(envelopeId);
	}
	
	/**
	 * 
	 * @param response
	 * @param documentId
	 * @throws IOException 
	 */
	
	@RequestMapping(value="Document", method=RequestMethod.GET)
	public void getDocumentById(HttpServletResponse response, @RequestParam(value="documentId", required=false) Integer documentId) {
		
		if (mockResponse) {
			File file= new File("H:\\scan\\20161108_00000026_D800_Tier2_0003.pdf");
			try {
				InputStream targetStream = new FileInputStream(file);
				IOUtils.copy(targetStream, response.getOutputStream());
				response.setContentType("application/pdf");
				response.addHeader("Content-disposition", "inline");
				response.flushBuffer();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}else {
			
			Document document = documentService.getDocumentById(documentId);
			byte [] contents = document.getFileBlob();
			ByteArrayInputStream in = new ByteArrayInputStream(contents);
			try {
				IOUtils.copy(in,response.getOutputStream());
			} catch (IOException e) {
				try {
					response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,"Error while reading file");
				} catch (IOException e1) {
					logger.error(e1.getMessage());
				}
			}
		}
		
	}
	
	/**
	 * 
	 * @param userId
	 * @param httpRequest
	 * @return
	 */
	@ResponseBody
	@RequestMapping(path="listAllMailBoxes", produces="application/json")
	public Object getMailboxesAndUnProcessedDocumentCountByUser(@RequestParam(value="userId", required=false) String userId, HttpServletRequest httpRequest){
		
		logger.info("getAllMailboxesByUser :: Entry");
		@SuppressWarnings ("unchecked")
		List<String> groups = (ArrayList<String>)httpRequest.getSession().getAttribute("user_groups");
		// if Claim
		if(!StringUtils.isNumeric(userId)){
			List<GenericError> list = new ArrayList<GenericError>();
			GenericError genericError = new GenericError();
			genericError.setCode(AppConstants.ERRORCODE_102);
			genericError.setMessage(AppConstants.ERRORCODE_102_MESSAGE);
			list.add(genericError);
			return genericError;
		}
		if(mockResponse) {
			List<MailBoxMock> mailBoxes = new ArrayList<MailBoxMock>();
	 		MailBoxMock mailBoxMock = new MailBoxMock();
			mailBoxMock.setCount(10);
			mailBoxMock.setId(123);
			mailBoxMock.setName("Claim");
			mailBoxes.add(mailBoxMock);
			MailBoxMock mailBoxMock1 = new MailBoxMock();
			mailBoxMock1.setCount(10);
			mailBoxMock1.setId(1234);
			mailBoxMock1.setName("PIR");
			mailBoxes.add(mailBoxMock1);
			return mailBoxes;
		}
		
		List<MailBox> accessibleMailBoxes = containerService.getUserAccessibleContainers(httpRequest.getUserPrincipal());
		logger.info("getAllMailboxesByUser :: Exit");
		return accessibleMailBoxes;
	}
	
}
