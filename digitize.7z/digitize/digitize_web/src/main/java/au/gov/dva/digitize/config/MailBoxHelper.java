package au.gov.dva.digitize.config;

import java.security.Principal;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
/*import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;

import waffle.servlet.WindowsPrincipal;
import waffle.spring.WindowsAuthenticationToken;
import waffle.windows.auth.WindowsAccount;*/
/**
 * 
 * @author znairm
 *
 */
public class MailBoxHelper {
	
	protected static Logger logger = null;
	public MailBoxHelper() {
		logger=LoggerFactory.getLogger(this.getClass());
	}
	
	public static List<String> setUserGroups(HttpServletRequest httpRequest) {
	
		Principal principal = httpRequest.getUserPrincipal(); 
		List<String> groups = new ArrayList<String>();
		/*if (principal instanceof WindowsPrincipal) {
			WindowsPrincipal windowsPrincipal = (WindowsPrincipal) principal;
			for(WindowsAccount account : windowsPrincipal.getGroups().values()) {    			
				groups.add(account.getFqn());
				logger.info(account.getFqn());
			}  
		}*/
		httpRequest.getSession().setAttribute("user_groups", groups);
		
		Principal principal1 = httpRequest.getUserPrincipal();
		/*if (principal instanceof WindowsAuthenticationToken) {
			WindowsAuthenticationToken authenticationToken = (WindowsAuthenticationToken)principal;
			SimpleGrantedAuthority authority = new SimpleGrantedAuthority("ROLE_MAILROOM");
			authenticationToken.getAuthorities();
		}*/
		return groups;
	}

}
