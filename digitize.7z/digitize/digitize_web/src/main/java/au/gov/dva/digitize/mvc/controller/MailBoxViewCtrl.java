package au.gov.dva.digitize.mvc.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import au.gov.dva.digitize.config.AppConstants;
import au.gov.dva.digitize.service.ContainerService;

/**
 * This simple controller class will handle all request to MailBox record 
 * management. It s light in functionality at the moment since most of 
 * data access delegated to the ContainerService class
 * 
 * 
 * @author 		Haibang Mai
 * @version    1.0
 * 
 */
@Controller
@RequestMapping("/views/mailbox/*")
public class MailBoxViewCtrl extends AbstractController
{
	@Autowired
	private ContainerService containerService;

	@GetMapping("mymailbox")
	public String listMyMailbox(Model model, HttpServletRequest request)
	{
		
		model.addAttribute("mailboxList", containerService.getUserAccessibleContainers(request.getUserPrincipal()));
		
		return AppConstants.TEMPLATE_MY_MAILBOXES;
		
	}

}
