package au.gov.dva.digitize.document.test;

import java.io.File;

import javax.xml.bind.JAXB;

import au.gov.dva.digitize.document.jaxb.MailFileMeta;

public class MailMetaReader {

	public static void main(String[] args) 
	{
		try {
			MailFileMeta mail=JAXB.unmarshal(new File(args[0]+"/ReceivedMailMeta.xml"), MailFileMeta.class);
			print(mail);
		}catch(Throwable e) {
			System.err.println("ERROR: "+e.toString());
		}
	}
	public static void print(MailFileMeta mail)
	{
		System.out.println("doc_id="+mail.getMailDocumentID()+"; env_id="+mail.getEnvelopeID()+"; bag_id="+mail.getBagID()+"; filename="+mail.getFileName()+"; trim_ref="+mail.getTrimReference());
	}
}
