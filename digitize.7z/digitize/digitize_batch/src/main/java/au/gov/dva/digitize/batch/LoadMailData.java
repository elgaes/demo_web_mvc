package au.gov.dva.digitize.batch;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FilenameFilter;
import java.io.IOException;
import java.net.URL;
import java.nio.channels.FileChannel;
import java.nio.channels.FileLock;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardOpenOption;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.xml.XMLConstants;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.Unmarshaller;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;

import au.gov.dva.digitize.document.jaxb.MailFileMeta;
import au.gov.dva.digitize.document.jaxb.ObjectFactory;
import au.gov.dva.digitize.jpa.AuditRec;
import au.gov.dva.digitize.jpa.Container;
import au.gov.dva.digitize.jpa.Document;
import au.gov.dva.digitize.jpa.FileBlob;
import javax.batch.api.AbstractBatchlet;
import javax.batch.api.BatchProperty;
import javax.inject.Inject;

public class LoadMailData  extends AbstractBatchlet 
{
    @Inject
    @BatchProperty(name = "runAt")
	protected Date runAt;
	protected String mailDropDir="/mail_drop";
	protected String unprocessMailDir=mailDropDir+"/unprocess";
	protected String processedMailDir=mailDropDir+"/completed";
	
	@PersistenceContext(unitName="digitizePU")
	protected EntityManager entityMgr;
	
    /**
     * @see AbstractBatchlet#AbstractBatchlet()
     */
    public LoadMailData() 
    {
        super();
    }

	/**
     * @see AbstractBatchlet#process()
     */
    public String process() 
    {
    	Path mailDropFolder=new File(mailDropDir).toPath();    	
    	Path unprocessFolder=new File(unprocessMailDir).toPath();
    	Path processedFolder=new File(processedMailDir).toPath();
    	if(!Files.exists(mailDropFolder))
    		return "ERROR: Mail drop directory "+mailDropFolder+ " not exist";
    

    	Unmarshaller unmarshaller=null ;
    	try {
        	Files.createDirectories(unprocessFolder);
        	Files.createDirectories(processedFolder);

    		SchemaFactory sf = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
    		URL xsdUrl=this.getClass().getResource("/META-INF/xsd/MailhouseInterface.xsd");
    		Schema schema = sf.newSchema(xsdUrl);      
            JAXBContext jc = JAXBContext.newInstance(ObjectFactory.class);         
            unmarshaller = jc.createUnmarshaller();        
            unmarshaller.setSchema(schema);        
            //unmarshaller.setEventHandler(new MyValidationEventHandler());         		
    	}catch(Throwable e) {
    		return "ERROR: "+e.toString();
    	}

    	File fileList[]=mailDropFolder.toFile().listFiles(new FilenameFilter() {
			public boolean accept(File dir, String name) 
			{
				return name.toLowerCase().trim().endsWith(".xml");
			}});
    	
    	File pdfFile=null;
    	
    	for(File xmlFile: fileList)
    	{
    		String filename=xmlFile.getName();

			pdfFile=new File(xmlFile.getParentFile(),filename.substring(0, filename.lastIndexOf('.'))+".pdf");
			if(pdfFile.exists())
			{	
    			try {
    				//Obtain exclusive lock on both pdf and xml file pair
    				FileChannel ch1=FileChannel.open(xmlFile.toPath(),StandardOpenOption.WRITE);
    				FileChannel ch2=FileChannel.open(pdfFile.toPath(),StandardOpenOption.WRITE);
    				FileLock lock1=ch1.tryLock();
    				FileLock lock2=ch2.tryLock();
    				if((lock1!=null)&&(lock2!=null))
    				{
    					lock1.release();
    					lock2.release();
    					//Only process files if exclusive file lock obtained otherwise leave this file pair for next scheduled run	due 
    					//to external process might be accessing and locked the files 
	    				processXmlMetaFile(xmlFile, pdfFile,unmarshaller);    	    				
	    				//successfull processed mail file pair will be moved to Completed folder
	    				Files.move(xmlFile.toPath(),processedFolder.resolve(xmlFile.getName()),StandardCopyOption.ATOMIC_MOVE);
	    				Files.move(pdfFile.toPath(),processedFolder.resolve(pdfFile.getName()),StandardCopyOption.ATOMIC_MOVE);
    				}
    			}catch(Throwable e) {
    				System.err.println("ERROR: "+e.toString());
    			}
			}else {
				//unpair mail files will be moved to unprocess folder
    			try {
    				Files.move(xmlFile.toPath(),unprocessFolder.resolve(xmlFile.getName()),StandardCopyOption.ATOMIC_MOVE);
    				//moveFile(xmlFile,new File(unprocessFolder, xmlFile.getName()));
    			}catch(Throwable e) {
    				
    			}
			}

    	}
		return null;
    }
    
    protected List<Container> getMailBox(String mailBoxId)
    {
    	Query sql=this.entityMgr.createNamedQuery("Container.findByMailBox", Container.class);
    	sql.setParameter("mailBoxId", mailBoxId);    	
    	return sql.getResultList();
    }
    protected void processXmlMetaFile(File xmlFile, File scanFile, Unmarshaller jaxbUnmarshaller) throws Exception
    {
    		if(entityMgr.getTransaction()!=null)
    			entityMgr.getTransaction().begin();
    		
    		JAXBElement obj=(JAXBElement)jaxbUnmarshaller.unmarshal(xmlFile);    		
	    	MailFileMeta mailMeta=(MailFileMeta)obj.getValue();
	    	Document document=toEntityDocument(mailMeta);
	    	
	    	FileBlob pdf=new FileBlob();
	    	pdf.setFblob(toBlobBytes(scanFile));
	    	pdf.setFtype("PDF");
	    	//Attach blob
	    	document.setFileBlob(pdf);
	    	entityMgr.persist(document);

	    	AuditRec audit=new AuditRec();
	    	audit.setCrtDate(new Timestamp(System.currentTimeMillis()));
	    	audit.setAction("CREATE");
	    	audit.setObjId(document.getId());
	    	entityMgr.persist(audit);		    	
	    	if(entityMgr.getTransaction()!=null)
	    		entityMgr.getTransaction().commit();
    }
    
    protected  Document toEntityDocument(MailFileMeta mailMeta)
    {
    	Document doc = new Document();
    	doc.setBagId(mailMeta.getBagID());
    	doc.setEnvelId(mailMeta.getEnvelopeID());
    	doc.setArchBox(mailMeta.getArchiveBoxNumber());
    	doc.setExtRef(mailMeta.getTrimReference());
    	doc.setScanName(mailMeta.getFileName());
    	doc.setTitle(mailMeta.getFileName());
    	doc.setScanDate(toDate(mailMeta.getDateTimeScanned()));
    	doc.setScanId(mailMeta.getMailDocumentID());
    	doc.setReadSta("UNREAD");
    	doc.setProcSta("UNPROC"); 
    	doc.setTherL1(mailMeta.getThesaurusL1());
    	doc.setTherL2(mailMeta.getThesaurusL2());
    	doc.setTherL3(mailMeta.getThesaurusL3());    	
    	doc.setContainers(this.getMailBox(mailMeta.getMailboxId()));
    	
    	return doc;
    }
    protected byte[] toBlobBytes(File pdf) throws IOException
    {
    	BufferedInputStream inStream=new BufferedInputStream(new FileInputStream(pdf));
    	ByteArrayOutputStream outStream=new ByteArrayOutputStream();
    	int n=-1;
    	byte[] xBuff=new byte[1024*25];
    	while((n=inStream.read(xBuff, 0, xBuff.length)) > 0)
    		outStream.write(xBuff, 0, n);
    	outStream.flush();
    	byte[] buff= outStream.toByteArray();
    	inStream.close();
    	outStream.close();
    	return buff;
    }
    protected Date toDate(XMLGregorianCalendar xmlDate)
    {
    	return new Date(xmlDate.getYear(),xmlDate.getMonth(),xmlDate.getDay());
    }
    
	//@Override
	public void stop() throws Exception 
	{
		//super.stop();
	}

	public static void main(String[] args)
	{
		LoadMailData loader=new LoadMailData ();
		loader.process();
	}
	public void print(MailFileMeta mail)
	{
		System.out.println("doc_id="+mail.getMailDocumentID()+"; env_id="+mail.getEnvelopeID()+"; bag_id="+mail.getBagID()+"; filename="+mail.getFileName()+"; trim_ref="+mail.getTrimReference());
	}	
}
